/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 293
(__unused_webpack_module, exports) {


// Cash flow calculation logic (replicated from lib/investment.ts)
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.computeCashFlow = computeCashFlow;
exports.getRentForBedrooms = getRentForBedrooms;
function clamp(n, min, max) {
    return Math.min(max, Math.max(min, n));
}
function monthlyRateFromAnnualPct(annualPct) {
    return (annualPct / 100) / 12;
}
function paymentFactorPerDollarLoan(rm, n) {
    // payment = L * factor
    if (n <= 0)
        return NaN;
    if (Math.abs(rm) < 1e-12)
        return 1 / n;
    const pow = Math.pow(1 + rm, n);
    return (rm * pow) / (pow - 1);
}
/**
 * Calculate monthly cash flow given a purchase price and all other parameters.
 *
 * Cash flow = Rent - (Mortgage Payment + Taxes + Insurance + HOA)
 *
 * Returns null if the inputs are invalid.
 */
function computeCashFlow(input) {
    const notes = [];
    const P = Number(input.purchasePrice);
    const R = Number(input.rentMonthly);
    const I = Number(input.insuranceMonthly);
    const H = Number(input.hoaMonthly);
    const PM = Number(input.propertyManagementMonthly ?? 0);
    const taxAnnualPct = Number(input.propertyTaxRateAnnualPct);
    const rateAnnualPct = Number(input.interestRateAnnualPct);
    const bedrooms = clamp(Math.round(input.bedrooms), 0, 8);
    if (!Number.isFinite(P) || P <= 0)
        return null;
    if (!Number.isFinite(R) || R <= 0)
        return null;
    if (!Number.isFinite(I) || I < 0)
        return null;
    if (!Number.isFinite(H) || H < 0)
        return null;
    if (!Number.isFinite(PM) || PM < 0)
        return null;
    if (!Number.isFinite(taxAnnualPct) || taxAnnualPct < 0)
        return null;
    if (!Number.isFinite(rateAnnualPct) || rateAnnualPct < 0)
        return null;
    const n = input.termMonths ?? 360;
    const t = (taxAnnualPct / 100) / 12; // monthly tax per dollar of price
    const rm = monthlyRateFromAnnualPct(rateAnnualPct);
    const factor = paymentFactorPerDollarLoan(rm, n);
    if (!Number.isFinite(factor) || factor <= 0)
        return null;
    // Calculate loan amount based on down payment
    let L;
    if (input.downPayment.mode === 'percent') {
        const d = Number(input.downPayment.percent) / 100;
        if (!Number.isFinite(d) || d <= 0 || d >= 1)
            return null;
        L = (1 - d) * P;
    }
    else {
        const D = Number(input.downPayment.amount);
        if (!Number.isFinite(D) || D <= 0 || D >= P)
            return null;
        L = P - D;
    }
    if (L <= 0)
        return null;
    // Calculate monthly payments
    const monthlyMortgagePayment = factor * L;
    const monthlyTaxes = t * P;
    const monthlyExpenses = I + H + monthlyTaxes + PM;
    const netBeforeDebt = R - monthlyExpenses;
    // Calculate custom line items
    let customExpensesMonthly = 0;
    if (input.customLineItems && input.customLineItems.length > 0) {
        for (const item of input.customLineItems) {
            if (item.method === 'amount') {
                customExpensesMonthly += item.value;
            }
            else if (item.method === 'percent' && item.percentOf) {
                const baseValue = item.percentOf === 'purchasePrice' ? P :
                    item.percentOf === 'rent' ? R :
                        item.percentOf === 'downPayment' ? (P - L) :
                            0;
                customExpensesMonthly += baseValue * (item.value / 100);
            }
        }
    }
    const monthlyCashFlow = netBeforeDebt - monthlyMortgagePayment - customExpensesMonthly;
    if (bedrooms > 4)
        notes.push('Using HUD 5+ bedroom rent scaling (+15% per bedroom above 4BR).');
    return {
        monthlyCashFlow,
        loanAmount: L,
        monthlyMortgagePayment,
        monthlyTaxes,
        monthlyExpenses,
        netBeforeDebt,
        notes,
    };
}
/**
 * Get rent for a specific number of bedrooms from FMR data.
 * @param rentSource - 'effective' = min(FMR, market), 'fmr' = HUD FMR only. Default 'effective'.
 */
function getRentForBedrooms(data, bedrooms, rentSource = 'effective') {
    const b = Math.max(0, Math.min(8, Math.round(bedrooms)));
    const getBr = (d, br) => {
        const eff = d.effectiveRent;
        const raw = br === 0 ? d.bedroom0 : br === 1 ? d.bedroom1 : br === 2 ? d.bedroom2 : br === 3 ? d.bedroom3 : d.bedroom4;
        const effVal = eff ? (br === 0 ? eff.bedroom0 : br === 1 ? eff.bedroom1 : br === 2 ? eff.bedroom2 : br === 3 ? eff.bedroom3 : eff.bedroom4) : null;
        const v = rentSource === 'fmr' ? raw : (effVal ?? raw);
        return v !== null && v !== undefined ? v : null;
    };
    if (data.zipFMRData && data.zipFMRData.length === 1) {
        const zipData = data.zipFMRData[0];
        if (b > 4) {
            const base = getBr(zipData, 4);
            if (base !== null)
                return Math.round(base * Math.pow(1.15, b - 4));
            return null;
        }
        return getBr(zipData, b);
    }
    if (b > 4) {
        const base = getBr(data, 4);
        if (base !== null)
            return Math.round(base * Math.pow(1.15, b - 4));
        return null;
    }
    return getBr(data, b);
}


/***/ },

/***/ 349
(__unused_webpack_module, exports) {


// fmr.fyi badge with brand-left, circle indicator, separator, and NO "Cash Flow" label
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createBadgeElement = createBadgeElement;
function createBadgeElement(props) {
    const badge = document.createElement('div');
    badge.className = 'fmr-badge';
    const badgeZIndex = props.hoaUnavailable ? '10010' : '1000';
    const setModeDataset = (mode) => {
        try {
            badge.dataset.fmrMode = mode;
        }
        catch {
            // ignore
        }
    };
    // Match the reference style (flat, crisp border, small radius, no heavy shadow)
    // Use !important to prevent parent element font-size from affecting badge (detail views often have larger h1 fonts)
    badge.style.cssText = `
    display: inline-flex;
    align-items: center;
    gap: 6px;

    background: #ffffff;
    border: 1px solid rgba(229, 229, 229, 1);
    border-radius: 6px;

    font-size: 12px !important;
    font-weight: 500;
    line-height: 1;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;

    position: relative;
    z-index: ${badgeZIndex};

    box-sizing: border-box;
    width: fit-content;
    max-width: max-content;
    flex: 0 0 auto;
    white-space: nowrap;

    box-shadow: none !important;
    transition: 0.2s cubic-bezier(0.4, 0, 0.2, 1);
  `;
    badge.addEventListener('mouseenter', () => {
        badge.style.borderColor = 'rgba(212, 212, 212, 1)';
        badge.style.background = 'rgba(250, 250, 250, 1)';
    });
    badge.addEventListener('mouseleave', () => {
        badge.style.borderColor = 'rgba(229, 229, 229, 1)';
        badge.style.background = '#ffffff';
    });
    if (props.rentConstrained) {
        badge.title = 'HUD may not pay above going market rates. Effective rent used.';
    }
    else if (props.missingMarketRent) {
        badge.title = 'Market rent data unavailable; showing HUD FMR.';
    }
    // Click behavior
    // Allow clicks when rateLimited (login required) even if nonInteractive
    if (props.nonInteractive && !props.rateLimited) {
        badge.style.cursor = 'default';
        if (props.hoaUnavailable) {
            badge.style.pointerEvents = 'auto';
            badge.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        }
        else {
            badge.style.pointerEvents = 'none';
        }
    }
    else {
        badge.style.cursor = 'pointer';
        badge.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            props.onClick();
        });
    }
    // Content container
    const content = document.createElement('span');
    content.style.cssText = `
    display: inline-flex;
    align-items: center;
    gap: 6px;
  `;
    badge.appendChild(content);
    // Brand (subtle, like reference)
    const brand = document.createElement('span');
    brand.textContent = 'fmr.fyi';
    brand.style.cssText = `
    font-size: 10px !important;
    font-weight: 600;
    color: rgba(115, 115, 115, 1);
    letter-spacing: 0.5px;
    margin-right: 2px;
  `;
    content.appendChild(brand);
    // Dot indicator (subtle border)
    const dot = document.createElement('span');
    dot.style.cssText = `
    width: 7px;
    height: 7px;
    border-radius: 999px;
    background: rgba(163, 163, 163, 1);
    box-shadow: inset 0 0 0 1px rgba(212, 212, 212, 1);
    flex-shrink: 0;
    margin-right: 2px;
  `;
    content.appendChild(dot);
    // Separator
    const sep = document.createElement('span');
    sep.setAttribute('aria-hidden', 'true');
    sep.style.cssText = `
    width: 1px;
    height: 12px;
    background: rgba(229, 229, 229, 1);
    margin: 0 2px;
    flex-shrink: 0;
  `;
    content.appendChild(sep);
    // Value container
    const valueWrap = document.createElement('span');
    valueWrap.style.cssText = `
    display: inline-flex;
    align-items: baseline;
    gap: 4px;
    font-variant-numeric: tabular-nums;
  `;
    content.appendChild(valueWrap);
    function ensureShimmerStyle() {
        if (document.getElementById('fmr-skeleton-style'))
            return;
        const style = document.createElement('style');
        style.id = 'fmr-skeleton-style';
        style.textContent = `
      @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
      }
    `;
        document.head.appendChild(style);
    }
    function buildInfoTooltipIcon() {
        const icon = document.createElement('span');
        icon.className = 'fmr-tip-icon';
        icon.textContent = '?';
        icon.style.cssText = `
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 16px;
      height: 16px;

      border-radius: 6px;
      background: rgba(250, 250, 250, 1);
      border: 1px solid rgba(229, 229, 229, 1);

      color: rgba(115, 115, 115, 1);
      font-size: 11px;
      font-weight: 700;

      cursor: help;
      line-height: 1;
      position: relative;
      flex-shrink: 0;
    `;
        const tip = document.createElement('div');
        tip.textContent =
            'HOA dues aren’t available in list/map view. This assumes $0 HOA. Expand property details to see calculation with HOA.';
        tip.style.cssText = `
      position: absolute;
      bottom: calc(100% + 10px);
      left: 50%;
      transform: translateX(-50%);

      width: 280px;
      padding: 10px 12px;

      background: rgba(10,10,10,0.97);
      color: rgba(255,255,255,0.96);

      font-size: 11.5px;
      line-height: 1.35;
      font-weight: 500;

      border: 1px solid rgba(38,38,38,1);
      border-radius: 10px;

      opacity: 0;
      pointer-events: none;
      transition: opacity 0.12s ease;

      box-shadow: 0 18px 50px rgba(0,0,0,0.30);
      z-index: 10011;
      white-space: normal;
    `;
        icon.addEventListener('mouseenter', () => (tip.style.opacity = '1'));
        icon.addEventListener('mouseleave', () => (tip.style.opacity = '0'));
        icon.appendChild(tip);
        return icon;
    }
    const updateContent = (cashFlow, isLoading = false, insufficientInfo = false, hoaUnavailable = false) => {
        setModeDataset('cashFlow');
        // z-index / pointer-events if tooltip should be shown
        if (hoaUnavailable) {
            badge.style.zIndex = '10010';
            if (props.nonInteractive)
                badge.style.pointerEvents = 'auto';
        }
        else {
            badge.style.zIndex = '1000';
            if (props.nonInteractive)
                badge.style.pointerEvents = 'none';
        }
        valueWrap.textContent = '';
        const existingTip = content.querySelector('.fmr-tip-icon');
        if (existingTip)
            existingTip.remove();
        if (insufficientInfo) {
            dot.style.background = 'rgba(163, 163, 163, 1)';
            const t = document.createElement('span');
            t.textContent = 'Insufficient data';
            t.style.cssText = `
        color: rgba(115, 115, 115, 1);
        font-weight: 600;
        font-size: 12px !important;
      `;
            valueWrap.appendChild(t);
            return;
        }
        if (isLoading) {
            ensureShimmerStyle();
            dot.style.background = 'rgba(163, 163, 163, 1)';
            const skeleton = document.createElement('span');
            skeleton.style.cssText = `
        display: inline-block;
        width: 56px;
        height: 12px;
        border-radius: 4px;
        background: linear-gradient(
          90deg,
          rgba(229,229,229,1) 25%,
          rgba(245,245,245,1) 50%,
          rgba(229,229,229,1) 75%
        );
        background-size: 200% 100%;
        animation: shimmer 1.1s infinite;
      `;
            valueWrap.appendChild(skeleton);
            return;
        }
        if (cashFlow === null) {
            dot.style.background = 'rgba(163, 163, 163, 1)';
            const t = document.createElement('span');
            t.textContent = 'Insufficient data';
            t.style.cssText = `
        color: rgba(115, 115, 115, 1);
        font-weight: 600;
        font-size: 12px !important;
      `;
            valueWrap.appendChild(t);
            return;
        }
        const isPositive = cashFlow >= 0;
        // Keep your existing app accents
        const dotColor = isPositive ? 'rgba(22, 163, 74, 1)' : 'rgba(225, 29, 72, 1)';
        dot.style.background = dotColor;
        const sign = isPositive ? '+' : '-';
        const formatted = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            maximumFractionDigits: 0,
        }).format(Math.abs(cashFlow));
        const value = document.createElement('span');
        value.textContent = `${sign}${formatted}`;
        value.style.cssText = `
      color: ${dotColor};
      font-weight: 700;
      font-size: 13px !important;
    `;
        const per = document.createElement('span');
        per.textContent = '/mo';
        per.style.cssText = `
      color: rgba(163, 163, 163, 1);
      font-size: 11px !important;
      margin-left: 2px;
    `;
        valueWrap.appendChild(value);
        valueWrap.appendChild(per);
        if (hoaUnavailable) {
            content.appendChild(buildInfoTooltipIcon());
        }
    };
    const updateFmrContent = (fmrMonthly, isLoading = false, insufficientInfo = false, hoaUnavailable = false) => {
        setModeDataset('fmr');
        // In FMR-only mode we never show the HOA tooltip, so keep normal z-index.
        badge.style.zIndex = '1000';
        if (props.nonInteractive) {
            // Respect non-interactive setting for Zillow card propagation safety
            badge.style.pointerEvents = hoaUnavailable ? 'auto' : 'none';
        }
        valueWrap.textContent = '';
        const existingTip = content.querySelector('.fmr-tip-icon');
        if (existingTip)
            existingTip.remove();
        if (insufficientInfo) {
            dot.style.background = 'rgba(163, 163, 163, 1)';
            const t = document.createElement('span');
            t.textContent = 'Insufficient data';
            t.style.cssText = `
        color: rgba(115, 115, 115, 1);
        font-weight: 600;
        font-size: 12px !important;
      `;
            valueWrap.appendChild(t);
            return;
        }
        if (isLoading) {
            ensureShimmerStyle();
            dot.style.background = 'rgba(163, 163, 163, 1)';
            const skeleton = document.createElement('span');
            skeleton.style.cssText = `
        display: inline-block;
        width: 56px;
        height: 12px;
        border-radius: 4px;
        background: linear-gradient(
          90deg,
          rgba(229,229,229,1) 25%,
          rgba(245,245,245,1) 50%,
          rgba(229,229,229,1) 75%
        );
        background-size: 200% 100%;
        animation: shimmer 1.1s infinite;
      `;
            valueWrap.appendChild(skeleton);
            return;
        }
        if (fmrMonthly === null) {
            dot.style.background = 'rgba(163, 163, 163, 1)';
            const t = document.createElement('span');
            t.textContent = 'Insufficient data';
            t.style.cssText = `
        color: rgba(115, 115, 115, 1);
        font-weight: 600;
        font-size: 12px !important;
      `;
            valueWrap.appendChild(t);
            return;
        }
        const dotColor = 'rgba(59, 130, 246, 1)'; // blue accent for FMR-only mode
        dot.style.background = dotColor;
        const formatted = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            maximumFractionDigits: 0,
        }).format(Math.abs(fmrMonthly));
        const value = document.createElement('span');
        value.textContent = `${formatted}`;
        value.style.cssText = `
      color: ${dotColor};
      font-weight: 700;
      font-size: 13px !important;
    `;
        const per = document.createElement('span');
        per.textContent = '/mo';
        per.style.cssText = `
      color: rgba(163, 163, 163, 1);
      font-size: 11px !important;
      margin-left: 2px;
    `;
        valueWrap.appendChild(value);
        valueWrap.appendChild(per);
    };
    const updateRateLimitedContent = () => {
        setModeDataset('cashFlow');
        badge.style.zIndex = '1000';
        // Allow clicks when rateLimited (login required) - make it interactive
        badge.style.pointerEvents = 'auto';
        badge.style.cursor = 'pointer';
        valueWrap.textContent = '';
        const existingTip = content.querySelector('.fmr-tip-icon');
        if (existingTip)
            existingTip.remove();
        // Orange/amber indicator for login required
        dot.style.background = 'rgba(251, 146, 60, 1)'; // orange-400
        const t = document.createElement('span');
        t.textContent = 'Login required';
        t.style.cssText = `
      color: rgba(251, 146, 60, 1);
      font-weight: 600;
      font-size: 12px !important;
    `;
        valueWrap.appendChild(t);
    };
    badge.updateContent = updateContent;
    badge.updateFmrContent = updateFmrContent;
    badge.updateRateLimitedContent = updateRateLimitedContent;
    // Initialize based on desired mode and state
    if (props.rateLimited) {
        updateRateLimitedContent();
    }
    else if (props.mode === 'fmr') {
        updateFmrContent(props.fmrMonthly ?? null, props.isLoading, props.insufficientInfo, props.hoaUnavailable);
    }
    else {
        updateContent(props.cashFlow, props.isLoading, props.insufficientInfo, props.hoaUnavailable);
    }
    return badge;
}


/***/ },

/***/ 389
(__unused_webpack_module, exports) {


// Mini results view component that displays the main app's ZIP page in an iframe
// Note: This is not a React component, it creates DOM elements directly
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createMiniViewElement = createMiniViewElement;
function createMiniViewElement(props) {
    const container = document.createElement('div');
    container.className = 'fmr-mini-view';
    // Calculate initial position (centered)
    const initialTop = window.innerHeight / 2;
    const initialLeft = window.innerWidth / 2;
    let currentTop = initialTop;
    let currentLeft = initialLeft;
    let isDragging = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let dragStartLeft = 0;
    let dragStartTop = 0;
    let dragJustEnded = false; // Track if drag just ended to prevent accidental close
    // Style the container
    container.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    width: 90%;
    max-width: 1000px;
    height: 85vh;
    background: white;
    border-radius: 8px;
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
    z-index: 10011;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    user-select: none;
  `;
    // Create header first (needed by drag handlers)
    const header = document.createElement('div');
    header.style.cssText = `
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 20px;
    border-bottom: 1px solid #e5e5e5;
    background: #fafafa;
    cursor: grab;
    user-select: none;
    position: relative;
  `;
    // Create grab handle indicator (dots in 2x3 grid)
    const grabHandle = document.createElement('div');
    grabHandle.style.cssText = `
    display: flex;
    flex-direction: column;
    gap: 4px;
    margin-right: 12px;
    opacity: 0.4;
    pointer-events: none;
  `;
    // Create 2 rows of 3 dots each
    const row1 = document.createElement('div');
    row1.style.cssText = `display: flex; gap: 4px;`;
    const row2 = document.createElement('div');
    row2.style.cssText = `display: flex; gap: 4px;`;
    for (let i = 0; i < 3; i++) {
        const dot1 = document.createElement('div');
        dot1.style.cssText = `width: 4px; height: 4px; background: #737373; border-radius: 50%;`;
        row1.appendChild(dot1);
        const dot2 = document.createElement('div');
        dot2.style.cssText = `width: 4px; height: 4px; background: #737373; border-radius: 50%;`;
        row2.appendChild(dot2);
    }
    grabHandle.appendChild(row1);
    grabHandle.appendChild(row2);
    // Add hover effect to grab handle
    header.addEventListener('mouseenter', () => {
        grabHandle.style.opacity = '0.6';
    });
    header.addEventListener('mouseleave', () => {
        grabHandle.style.opacity = '0.4';
    });
    // Update position function
    const updatePosition = (clientX, clientY) => {
        const deltaX = clientX - dragStartX;
        const deltaY = clientY - dragStartY;
        currentLeft = dragStartLeft + deltaX;
        currentTop = dragStartTop + deltaY;
        // Constrain to viewport bounds
        const rect = container.getBoundingClientRect();
        const maxLeft = window.innerWidth - rect.width;
        const minLeft = 0;
        const maxTop = window.innerHeight - rect.height;
        const minTop = 0;
        currentLeft = Math.max(minLeft, Math.min(maxLeft, currentLeft));
        currentTop = Math.max(minTop, Math.min(maxTop, currentTop));
        container.style.left = `${currentLeft}px`;
        container.style.top = `${currentTop}px`;
    };
    // Drag handlers
    const handleMouseDown = (e) => {
        if (e.target.closest('button')) {
            return; // Don't drag if clicking the close button
        }
        isDragging = true;
        const rect = container.getBoundingClientRect();
        // Store the initial mouse position and container position
        dragStartX = e.clientX;
        dragStartY = e.clientY;
        dragStartLeft = rect.left;
        dragStartTop = rect.top;
        header.style.cursor = 'grabbing';
        // Remove transform and set explicit position
        container.style.transform = 'none';
        container.style.transition = 'none';
        container.style.left = `${rect.left}px`;
        container.style.top = `${rect.top}px`;
        // Hide overlay background and disable iframe interactions during drag
        if (props.overlay) {
            props.overlay.style.background = 'transparent';
            props.overlay.style.pointerEvents = 'none';
        }
        // Prevent iframe from receiving pointer events during drag
        const iframe = container.querySelector('iframe');
        if (iframe) {
            iframe.__fmrOriginalPointerEvents = iframe.style.pointerEvents || '';
            iframe.style.pointerEvents = 'none';
        }
        e.preventDefault();
        e.stopPropagation();
    };
    const handleMouseMove = (e) => {
        if (!isDragging)
            return;
        updatePosition(e.clientX, e.clientY);
    };
    const handleMouseUp = () => {
        if (!isDragging)
            return;
        isDragging = false;
        dragJustEnded = true;
        header.style.cursor = 'grab';
        container.style.transition = '';
        // Show overlay background again and restore iframe interactions
        if (props.overlay) {
            props.overlay.style.background = 'rgba(0, 0, 0, 0.5)';
            // Store flag on overlay so click handler can check it
            props.overlay.__fmrDragJustEnded = true;
            // Delay restoring pointer events and clearing flag to prevent accidental close
            setTimeout(() => {
                if (props.overlay) {
                    props.overlay.style.pointerEvents = 'auto';
                    props.overlay.__fmrDragJustEnded = false;
                }
                dragJustEnded = false;
            }, 150);
        }
        else {
            dragJustEnded = false;
        }
        // Restore iframe pointer events
        const iframe = container.querySelector('iframe');
        if (iframe && iframe.__fmrOriginalPointerEvents !== undefined) {
            iframe.style.pointerEvents = iframe.__fmrOriginalPointerEvents;
            delete iframe.__fmrOriginalPointerEvents;
        }
    };
    // Make header draggable
    header.addEventListener('mousedown', handleMouseDown);
    // Global mouse move/up handlers
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    // Cleanup on close
    const originalOnClose = props.onClose;
    props.onClose = () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        originalOnClose();
    };
    const title = document.createElement('div');
    title.textContent = `ZIP ${props.zipCode} - FMR Analysis`;
    title.style.cssText = `
    font-size: 16px;
    font-weight: 600;
    color: #0a0a0a;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  `;
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '×';
    closeBtn.setAttribute('aria-label', 'Close');
    closeBtn.style.cssText = `
    background: none;
    border: none;
    font-size: 32px;
    line-height: 1;
    color: #737373;
    cursor: pointer;
    padding: 0;
    width: 32px;
    height: 32px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 4px;
    transition: background-color 0.2s;
  `;
    closeBtn.addEventListener('mouseenter', () => {
        closeBtn.style.backgroundColor = '#e5e5e5';
    });
    closeBtn.addEventListener('mouseleave', () => {
        closeBtn.style.backgroundColor = 'transparent';
    });
    closeBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        props.onClose();
    });
    header.appendChild(grabHandle);
    header.appendChild(title);
    header.appendChild(closeBtn);
    // Create iframe with config passed as URL parameter
    const iframe = document.createElement('iframe');
    // Build config object to pass to main app
    // Use detected HOA if available, otherwise use preference default (0)
    const hoaToUse = props.hoaMonthly !== null ? props.hoaMonthly : props.preferences.hoaMonthly;
    const config = {
        downPaymentMode: props.preferences.downPaymentMode,
        downPaymentPercent: props.preferences.downPaymentPercent,
        downPaymentAmount: props.preferences.downPaymentAmount,
        insuranceMonthly: props.preferences.insuranceMonthly,
        hoaMonthly: hoaToUse,
        propertyManagementMode: props.preferences.propertyManagementMode,
        propertyManagementPercent: props.preferences.propertyManagementPercent,
        propertyManagementAmount: props.preferences.propertyManagementAmount,
        overrideTaxRate: props.preferences.overrideTaxRate,
        overrideMortgageRate: props.preferences.overrideMortgageRate,
        propertyTaxRateAnnualPct: props.preferences.propertyTaxRateAnnualPct,
        mortgageRateAnnualPct: props.preferences.mortgageRateAnnualPct,
        customLineItems: props.preferences.customLineItems || [],
        purchasePrice: props.purchasePrice,
        bedrooms: props.bedrooms,
        rentSource: props.preferences.rentSource || 'effective',
    };
    // Serialize config to base64 to avoid URL encoding issues
    const configJson = JSON.stringify(config);
    const configBase64 = btoa(configJson);
    // Build URL with referrer parameters
    const urlParams = new URLSearchParams();
    urlParams.set('config', configBase64);
    urlParams.set('ref', 'chrome-extension');
    if (props.sourceSite) {
        urlParams.set('source', props.sourceSite);
    }
    const base = props.apiBaseUrl.replace(/\/$/, '');
    iframe.src = `${base}/zip/${props.zipCode}?${urlParams.toString()}`;
    // Set referrer policy to ensure referrer header is sent (for Vercel analytics)
    // 'origin' sends the origin (e.g., https://zillow.com) as the referrer
    iframe.setAttribute('referrerpolicy', 'origin');
    iframe.style.cssText = `
    flex: 1;
    border: none;
    width: 100%;
    height: 100%;
  `;
    iframe.setAttribute('loading', 'eager');
    container.appendChild(header);
    container.appendChild(iframe);
    return container;
}


/***/ },

/***/ 576
(__unused_webpack_module, exports, __webpack_require__) {


// Auth service for Chrome extension
// Handles login, token storage, refresh, and logout
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokens = getTokens;
exports.logout = logout;
exports.refreshTokenIfNeeded = refreshTokenIfNeeded;
exports.getAuthHeaders = getAuthHeaders;
exports.login = login;
exports.isLoggedIn = isLoggedIn;
exports.getCurrentUser = getCurrentUser;
const config_1 = __webpack_require__(724);
const STORAGE_KEY = 'fmr_extension_auth';
function isContextInvalidated(err) {
    const msg = err instanceof Error ? err.message : String(err);
    return /Extension context invalidated/i.test(msg) || /context invalidated/i.test(msg);
}
// Get stored tokens
async function getTokens() {
    try {
        return await new Promise((resolve) => {
            try {
                chrome.storage.sync.get([STORAGE_KEY], (items) => {
                    if (chrome.runtime?.lastError && isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                        resolve(null);
                        return;
                    }
                    const tokens = items?.[STORAGE_KEY];
                    if (!tokens) {
                        resolve(null);
                        return;
                    }
                    const expiresAt = new Date(tokens.expiresAt);
                    if (expiresAt < new Date()) {
                        refreshTokenIfNeeded(tokens.refreshToken)
                            .then((newTokens) => resolve(newTokens))
                            .catch(() => resolve(null));
                        return;
                    }
                    resolve(tokens);
                });
            }
            catch (e) {
                if (isContextInvalidated(e)) {
                    resolve(null);
                }
                else {
                    throw e;
                }
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return null;
        throw e;
    }
}
// Store tokens
async function storeTokens(tokens) {
    try {
        return await new Promise((resolve, reject) => {
            try {
                chrome.storage.sync.set({ [STORAGE_KEY]: tokens }, () => {
                    if (chrome.runtime?.lastError) {
                        if (isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                            resolve();
                            return;
                        }
                        reject(new Error(chrome.runtime.lastError.message));
                    }
                    else {
                        resolve();
                    }
                });
            }
            catch (e) {
                if (isContextInvalidated(e)) {
                    resolve();
                }
                else {
                    reject(e);
                }
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return;
        throw e;
    }
}
// Clear tokens
async function logout() {
    try {
        const tokens = await getTokens();
        if (tokens?.refreshToken) {
            try {
                const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
                await fetch(`${API_BASE_URL}/api/auth/extension-token`, {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ refreshToken: tokens.refreshToken }),
                });
            }
            catch (error) {
                if (!isContextInvalidated(error))
                    console.error('Error revoking token:', error);
            }
        }
        await new Promise((resolve, reject) => {
            try {
                chrome.storage.sync.remove([STORAGE_KEY], () => {
                    if (chrome.runtime?.lastError && isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                        resolve();
                        return;
                    }
                    resolve();
                });
            }
            catch (e) {
                if (isContextInvalidated(e))
                    resolve();
                else
                    reject(e);
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return;
        throw e;
    }
}
// Refresh access token if needed
async function refreshTokenIfNeeded(refreshToken) {
    let tokens = null;
    try {
        tokens = await getTokens();
    }
    catch (e) {
        if (isContextInvalidated(e))
            return null;
        throw e;
    }
    if (!tokens && !refreshToken)
        return null;
    const tokenToUse = refreshToken || tokens?.refreshToken;
    if (!tokenToUse)
        return null;
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        const response = await fetch(`${API_BASE_URL}/api/auth/extension-token`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refreshToken: tokenToUse }),
        });
        if (!response.ok) {
            try {
                await logout();
            }
            catch {
                // ignore if logout fails (e.g. context invalidated)
            }
            return null;
        }
        const data = await response.json();
        const newTokens = {
            accessToken: data.accessToken,
            refreshToken: tokens?.refreshToken || tokenToUse,
            expiresAt: tokens?.expiresAt || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            user: data.user || tokens?.user,
        };
        await storeTokens(newTokens);
        return newTokens;
    }
    catch (error) {
        if (isContextInvalidated(error))
            return null;
        console.error('Error refreshing token:', error);
        try {
            await logout();
        }
        catch {
            // ignore
        }
        return null;
    }
}
// Get auth headers for API requests
async function getAuthHeaders() {
    let tokens = await getTokens();
    if (!tokens) {
        return {};
    }
    // Check if access token is expired or expiring soon (within 5 minutes)
    const expiresAt = new Date(tokens.expiresAt);
    const now = new Date();
    const fiveMinutesFromNow = new Date(now.getTime() + 5 * 60 * 1000);
    if (expiresAt < fiveMinutesFromNow) {
        // Refresh token
        tokens = await refreshTokenIfNeeded();
        if (!tokens) {
            return {};
        }
    }
    return {
        Authorization: `Bearer ${tokens.accessToken}`,
    };
}
// Open login tab - authentication is handled by the background service worker
async function login() {
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        return await new Promise((resolve, reject) => {
            try {
                if (typeof chrome.tabs === 'undefined' || !chrome.tabs.create) {
                    chrome.runtime.sendMessage({ type: 'OPEN_LOGIN_TAB', url: `${API_BASE_URL}/auth/extension` }, (response) => {
                        if (chrome.runtime?.lastError) {
                            const err = new Error(chrome.runtime.lastError.message);
                            if (isContextInvalidated(err)) {
                                reject(new Error('Extension was reloaded. Please refresh this page and try signing in again.'));
                                return;
                            }
                            reject(err);
                            return;
                        }
                        if (response?.success)
                            resolve();
                        else
                            reject(new Error(response?.error || 'Failed to open auth page'));
                    });
                    return;
                }
                chrome.tabs.create({ url: `${API_BASE_URL}/auth/extension`, active: true }, (tab) => {
                    if (chrome.runtime?.lastError) {
                        const err = new Error(chrome.runtime.lastError.message);
                        if (isContextInvalidated(err)) {
                            reject(new Error('Extension was reloaded. Please refresh this page and try signing in again.'));
                            return;
                        }
                        reject(err);
                        return;
                    }
                    if (!tab?.id) {
                        reject(new Error('Failed to open auth page'));
                        return;
                    }
                    resolve();
                });
            }
            catch (e) {
                if (isContextInvalidated(e)) {
                    reject(new Error('Extension was reloaded. Please refresh this page and try signing in again.'));
                }
                else {
                    reject(e);
                }
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e)) {
            throw new Error('Extension was reloaded. Please refresh this page and try signing in again.');
        }
        throw e;
    }
}
// Check if user is logged in
async function isLoggedIn() {
    const tokens = await getTokens();
    return tokens !== null;
}
// Get current user info
async function getCurrentUser() {
    const tokens = await getTokens();
    return tokens?.user || null;
}


/***/ },

/***/ 677
(__unused_webpack_module, exports) {


// Shared types for the extension
// These can reference types from the main app lib/types.ts
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DEFAULT_PREFERENCES = void 0;
exports.DEFAULT_PREFERENCES = {
    mode: 'cashFlow',
    rentSource: 'effective',
    bedrooms: null,
    purchasePrice: null,
    downPaymentMode: 'percent',
    downPaymentPercent: 20,
    downPaymentAmount: 0,
    insuranceMonthly: 100,
    hoaMonthly: 0,
    propertyManagementMode: 'percent',
    propertyManagementPercent: 10,
    propertyManagementAmount: 0,
    overrideTaxRate: false,
    overrideMortgageRate: false,
    propertyTaxRateAnnualPct: null,
    mortgageRateAnnualPct: null,
    customLineItems: [],
    enabledSites: {
        redfin: true,
        zillow: true,
    },
};


/***/ },

/***/ 724
(__unused_webpack_module, exports) {


// Shared configuration for the extension
// API base URL is stored in local storage; only the popup enforces admin-only editing.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getApiBaseUrl = getApiBaseUrl;
exports.setApiBaseUrl = setApiBaseUrl;
const DEFAULT_API_BASE_URL = 'https://fmr.fyi';
function isContextInvalidated(err) {
    const msg = err instanceof Error ? err.message : String(err);
    return /Extension context invalidated/i.test(msg) || /context invalidated/i.test(msg);
}
/**
 * Get the API base URL. Reads from storage (no auth check here).
 * If extension context is invalidated (e.g. after reload), returns default without throwing.
 */
async function getApiBaseUrl() {
    try {
        return await new Promise((resolve) => {
            try {
                chrome.storage.local.get(['api_base_url'], (items) => {
                    if (chrome.runtime?.lastError && isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                        resolve(DEFAULT_API_BASE_URL);
                        return;
                    }
                    resolve(items?.api_base_url || DEFAULT_API_BASE_URL);
                });
            }
            catch (e) {
                if (isContextInvalidated(e))
                    resolve(DEFAULT_API_BASE_URL);
                else
                    throw e;
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return DEFAULT_API_BASE_URL;
        throw e;
    }
}
/**
 * Set the API base URL. Caller (popup) must enforce admin-only.
 * No-ops if extension context is invalidated.
 */
async function setApiBaseUrl(url) {
    try {
        return await new Promise((resolve, reject) => {
            try {
                chrome.storage.local.set({ api_base_url: url }, () => {
                    if (chrome.runtime?.lastError) {
                        if (isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                            resolve();
                            return;
                        }
                        reject(new Error(chrome.runtime.lastError.message));
                    }
                    else {
                        resolve();
                    }
                });
            }
            catch (e) {
                if (isContextInvalidated(e))
                    resolve();
                else
                    reject(e);
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return;
        throw e;
    }
}


/***/ },

/***/ 776
(__unused_webpack_module, exports) {


// Property data extraction using site-specific CSS selectors
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.detectSite = detectSite;
exports.extractBedrooms = extractBedrooms;
exports.extractPrice = extractPrice;
exports.extractHOA = extractHOA;
exports.extractHOAFromZillowExpanded = extractHOAFromZillowExpanded;
exports.extractHOAFromRedfinDetail = extractHOAFromRedfinDetail;
exports.extractPropertyData = extractPropertyData;
exports.extractAddressFromCard = extractAddressFromCard;
exports.extractBedroomsFromCard = extractBedroomsFromCard;
exports.extractPriceFromCard = extractPriceFromCard;
exports.extractPropertyDataFromCard = extractPropertyDataFromCard;
exports.extractAddressFromZillowCard = extractAddressFromZillowCard;
exports.extractBedroomsFromZillowCard = extractBedroomsFromZillowCard;
exports.extractPriceFromZillowCard = extractPriceFromZillowCard;
exports.extractPropertyDataFromZillowCard = extractPropertyDataFromZillowCard;
exports.extractAddressFromZillowExpanded = extractAddressFromZillowExpanded;
exports.extractBedroomsFromZillowExpanded = extractBedroomsFromZillowExpanded;
exports.extractPriceFromZillowExpanded = extractPriceFromZillowExpanded;
exports.extractPropertyDataFromZillowExpanded = extractPropertyDataFromZillowExpanded;
/**
 * Detect which real estate site we're on
 */
function detectSite() {
    const hostname = window.location.hostname.toLowerCase();
    if (hostname.includes('zillow.com'))
        return 'zillow';
    if (hostname.includes('redfin.com'))
        return 'redfin';
    if (hostname.includes('realtor.com'))
        return 'realtor';
    if (hostname.includes('homes.com'))
        return 'homes';
    return 'unknown';
}
/**
 * Check if we're on a property detail page vs search results
 */
function isDetailPage() {
    const path = window.location.pathname.toLowerCase();
    // Zillow detail pages: /homedetails/...
    // Redfin detail pages: /home/...
    // Realtor.com detail pages: /realestateandhomes-detail/...
    // Homes.com detail pages: /property/...
    return (path.includes('/homedetails/') ||
        path.includes('/home/') ||
        path.includes('/realestateandhomes-detail/') ||
        path.includes('/property/'));
}
/**
 * Extract bedrooms count from the DOM
 */
function extractBedrooms() {
    const site = detectSite();
    const isDetail = isDetailPage();
    let selectors = [];
    if (site === 'zillow') {
        if (isDetail) {
            // For detail pages, try multiple approaches to find bedrooms
            // Approach 1: Try bed-bath-sqft-text structure (mobile/desktop)
            const mobileContainer = document.querySelector('[data-testid="mobile-bed-bath-sqft"]');
            const desktopContainer = document.querySelector('[data-testid="desktop-bed-bath-sqft"]');
            for (const container of [mobileContainer, desktopContainer].filter(Boolean)) {
                const firstContainer = container?.querySelector('[data-testid="bed-bath-sqft-text__container"]');
                if (firstContainer) {
                    const valueElement = firstContainer.querySelector('[data-testid="bed-bath-sqft-text__value"]');
                    if (valueElement) {
                        const valueText = valueElement.textContent?.trim() || '';
                        // Check for "—" or other non-numeric indicators
                        if (!valueText.includes('—') && !valueText.toLowerCase().includes('n/a') && valueText.length > 0) {
                            const count = parseInt(valueText, 10);
                            if (!isNaN(count) && count >= 0 && count <= 8) {
                                return count;
                            }
                        }
                    }
                }
            }
            // Approach 2: Try direct bed-bath-sqft-text__container (first one is beds)
            const allContainers = document.querySelectorAll('[data-testid="bed-bath-sqft-text__container"]');
            if (allContainers.length > 0) {
                const firstContainer = allContainers[0];
                const valueElement = firstContainer.querySelector('[data-testid="bed-bath-sqft-text__value"]');
                if (valueElement) {
                    const valueText = valueElement.textContent?.trim() || '';
                    if (!valueText.includes('—') && !valueText.toLowerCase().includes('n/a') && valueText.length > 0) {
                        const count = parseInt(valueText, 10);
                        if (!isNaN(count) && count >= 0 && count <= 8) {
                            return count;
                        }
                    }
                }
            }
            // Approach 3: Try to find elements with "bed" or "beds" text
            const bedElements = document.querySelectorAll('[data-testid*="bed"], [class*="bed"]');
            for (const element of Array.from(bedElements)) {
                const text = element.textContent || '';
                const match = text.match(/(\d+)\s*(?:bed|bd|br|bedroom)/i);
                if (match) {
                    const count = parseInt(match[1], 10);
                    if (!isNaN(count) && count >= 0 && count <= 8) {
                        return count;
                    }
                }
            }
            // Fallback to other selectors
            selectors = [
                '[data-testid="bed-bath-item"] [data-testid="bed"]',
                '.ds-bed-bath-living-area-container [data-testid="bed"]',
                '.ds-bed-bath-living-area-row [data-testid="bed"]',
                '[data-testid="bed"]',
            ];
        }
        else {
            selectors = [
                '.PropertyCardWrapper [data-testid="bed"]',
                '[data-testid="property-card-bed"]',
            ];
        }
    }
    else if (site === 'redfin') {
        if (isDetail) {
            selectors = [
                '[data-rf-test-id="abp-beds"] .statsValue',
                '[data-rf-test-id="abp-beds"]',
                '.PropertyStatsBlock .stats .stat[data-rf-test-id="abp-beds"]',
            ];
        }
        else {
            selectors = [
                '.bottomV2 .stats .stat',
            ];
        }
    }
    else if (site === 'realtor') {
        if (isDetail) {
            selectors = [
                '[data-label="property-meta-beds"]',
                '.PropertyMetaBlock [data-label="property-meta-beds"]',
            ];
        }
        else {
            selectors = [
                '.BasePropertyCard__PropertyMeta [data-label="pc-meta-beds"]',
            ];
        }
    }
    else if (site === 'homes') {
        if (isDetail) {
            selectors = [
                '.property-features .bedrooms',
                '.detail-features [data-feature="bedrooms"]',
            ];
        }
        else {
            selectors = [
                '.home-features [data-feature="bedrooms"]',
            ];
        }
    }
    // Try each selector
    for (const selector of selectors) {
        try {
            const element = document.querySelector(selector);
            if (element) {
                const text = element.textContent || element.getAttribute('aria-label') || '';
                const match = text.match(/(\d+)\s*(?:bed|bd|br|bedroom)/i);
                if (match) {
                    const count = parseInt(match[1], 10);
                    if (!isNaN(count) && count >= 0 && count <= 8) {
                        return count;
                    }
                }
                // Try to parse the text content directly as a number
                const directMatch = text.trim().match(/^(\d+)$/);
                if (directMatch) {
                    const count = parseInt(directMatch[1], 10);
                    if (!isNaN(count) && count >= 0 && count <= 8) {
                        return count;
                    }
                }
            }
        }
        catch (e) {
            // Continue to next selector
        }
    }
    return null;
}
/**
 * Extract price from the DOM
 */
function extractPrice() {
    const site = detectSite();
    const isDetail = isDetailPage();
    let selectors = [];
    if (site === 'zillow') {
        if (isDetail) {
            // Try price-text class first (matches the HTML structure)
            const priceTextElement = document.querySelector('[data-testid="home-info"] .price-text') ||
                document.querySelector('.price-text');
            if (priceTextElement) {
                const text = priceTextElement.textContent || '';
                const price = parsePrice(text);
                if (price !== null) {
                    return price;
                }
            }
            // Fallback to other selectors
            selectors = [
                '[data-testid="price"]',
                '[data-testid="home-info"] [data-testid="price"]',
                '.ds-price',
                '.ds-summary-row span[aria-label*="$"]',
            ];
        }
        else {
            selectors = [
                '.PropertyCardWrapper [data-testid="property-card-price"]',
                '[data-testid="price"]',
            ];
        }
    }
    else if (site === 'redfin') {
        if (isDetail) {
            selectors = [
                '[data-rf-test-id="abp-price"] .statsValue',
                '[data-rf-test-id="abp-price"]',
                '.info-block .price',
                '.dp-price-display',
            ];
        }
        else {
            selectors = [
                '.bottomV2 .homecardV2Price',
                '.homecardV2Price',
            ];
        }
    }
    else if (site === 'realtor') {
        if (isDetail) {
            selectors = [
                '[data-label="property-price"]',
                '.ldp-price',
            ];
        }
        else {
            selectors = [
                '.BasePropertyCard__Price [data-label="pc-price"]',
            ];
        }
    }
    else if (site === 'homes') {
        if (isDetail) {
            selectors = [
                '.property-price',
                '.price-display',
            ];
        }
        else {
            selectors = [
                '.home-price',
                '.price',
            ];
        }
    }
    // Try each selector
    for (const selector of selectors) {
        try {
            const element = document.querySelector(selector);
            if (element) {
                const text = element.textContent || element.getAttribute('aria-label') || '';
                const price = parsePrice(text);
                if (price !== null) {
                    return price;
                }
            }
        }
        catch (e) {
            // Continue to next selector
        }
    }
    return null;
}
/**
 * Parse price string to number
 * Handles formats like: $450,000, $1.2M, $500K, etc.
 */
function parsePrice(text) {
    // Remove currency symbols and whitespace
    let cleaned = text.replace(/[\$\s,]/g, '');
    // Handle million suffix
    if (cleaned.toLowerCase().includes('m')) {
        const match = cleaned.match(/^([\d.]+)m/i);
        if (match) {
            const value = parseFloat(match[1]);
            if (!isNaN(value)) {
                return Math.round(value * 1000000);
            }
        }
    }
    // Handle thousand suffix
    if (cleaned.toLowerCase().includes('k')) {
        const match = cleaned.match(/^([\d.]+)k/i);
        if (match) {
            const value = parseFloat(match[1]);
            if (!isNaN(value)) {
                return Math.round(value * 1000);
            }
        }
    }
    // Try to parse as direct number
    const number = parseFloat(cleaned);
    if (!isNaN(number) && number > 0) {
        return Math.round(number);
    }
    return null;
}
/**
 * Extract HOA monthly dues from the DOM (detail pages only)
 */
function extractHOA() {
    const site = detectSite();
    const isDetail = isDetailPage();
    // HOA is only available on detail pages
    if (!isDetail) {
        return null;
    }
    if (site === 'zillow') {
        // Zillow: Look for span with "HOA" text containing price
        // Format 1: <span class="Text-c11n-8-112-0__sc-aiai24-0 ...">$509/mo HOA</span>
        // Format 2: <span class="Text-c11n-8-112-0__sc-aiai24-0 hdp__sc-6k0go5-3 ...">$290 monthly HOA fee</span>
        // Or: $-- HOA (when no HOA)
        const hoaElements = document.querySelectorAll('span[class*="Text-c11n-8-112-0"]');
        for (const element of Array.from(hoaElements)) {
            const text = element.textContent?.trim() || '';
            if (text.includes('HOA')) {
                // Check if it's the "no HOA" indicator
                if (text.includes('$--') || text.includes('$—')) {
                    return 0; // Explicitly no HOA
                }
                // Format 1: "$509/mo HOA" -> 509
                let match = text.match(/\$([\d,]+)\/mo/);
                if (match) {
                    const price = parseFloat(match[1].replace(/,/g, ''));
                    if (!isNaN(price) && price >= 0) {
                        return price;
                    }
                }
                // Format 2: "$290 monthly HOA fee" -> 290
                match = text.match(/\$([\d,]+)\s+monthly\s+HOA\s+fee/i);
                if (match) {
                    const price = parseFloat(match[1].replace(/,/g, ''));
                    if (!isNaN(price) && price >= 0) {
                        return price;
                    }
                }
            }
        }
    }
    else if (site === 'redfin') {
        // Redfin: Look for keyDetails-row with "HOA Dues" valueType
        // Structure: <div class="keyDetails-row">...<span class="valueText">$509/mo</span><span class="valueType">HOA Dues</span>...</div>
        const keyDetailsRows = document.querySelectorAll('.keyDetails-row');
        for (const row of Array.from(keyDetailsRows)) {
            const valueType = row.querySelector('.valueType');
            if (valueType && valueType.textContent?.trim().toLowerCase().includes('hoa')) {
                const valueText = row.querySelector('.valueText');
                if (valueText) {
                    const text = valueText.textContent?.trim() || '';
                    // Extract price: "$509/mo" -> 509
                    const match = text.match(/\$([\d,]+)\/mo/);
                    if (match) {
                        const price = parseFloat(match[1].replace(/,/g, ''));
                        if (!isNaN(price) && price >= 0) {
                            return price;
                        }
                    }
                }
            }
        }
    }
    return null;
}
/**
 * Extract HOA from Zillow expanded view
 */
function extractHOAFromZillowExpanded(container) {
    // Look for span with "HOA" text containing price
    // Format 1: <span class="Text-c11n-8-112-0__sc-aiai24-0 ...">$509/mo HOA</span>
    // Format 2: <span class="Text-c11n-8-112-0__sc-aiai24-0 hdp__sc-6k0go5-3 ...">$290 monthly HOA fee</span>
    const hoaElements = container.querySelectorAll('span[class*="Text-c11n-8-112-0"]');
    for (const element of Array.from(hoaElements)) {
        const text = element.textContent?.trim() || '';
        if (text.includes('HOA')) {
            // Check if it's the "no HOA" indicator
            if (text.includes('$--') || text.includes('$—')) {
                return 0; // Explicitly no HOA
            }
            // Format 1: "$509/mo HOA" -> 509
            let match = text.match(/\$([\d,]+)\/mo/);
            if (match) {
                const price = parseFloat(match[1].replace(/,/g, ''));
                if (!isNaN(price) && price >= 0) {
                    return price;
                }
            }
            // Format 2: "$290 monthly HOA fee" -> 290
            match = text.match(/\$([\d,]+)\s+monthly\s+HOA\s+fee/i);
            if (match) {
                const price = parseFloat(match[1].replace(/,/g, ''));
                if (!isNaN(price) && price >= 0) {
                    return price;
                }
            }
        }
    }
    return null;
}
/**
 * Extract HOA from Redfin detail page
 */
function extractHOAFromRedfinDetail() {
    // Look for keyDetails-row with "HOA Dues" valueType
    const keyDetailsRows = document.querySelectorAll('.keyDetails-row');
    for (const row of Array.from(keyDetailsRows)) {
        const valueType = row.querySelector('.valueType');
        if (valueType && valueType.textContent?.trim().toLowerCase().includes('hoa')) {
            const valueText = row.querySelector('.valueText');
            if (valueText) {
                const text = valueText.textContent?.trim() || '';
                // Extract price: "$509/mo" -> 509
                const match = text.match(/\$([\d,]+)\/mo/);
                if (match) {
                    const price = parseFloat(match[1].replace(/,/g, ''));
                    if (!isNaN(price) && price >= 0) {
                        return price;
                    }
                }
            }
        }
    }
    return null;
}
/**
 * Extract both bedrooms and price
 */
function extractPropertyData() {
    return {
        bedrooms: extractBedrooms(),
        price: extractPrice(),
        hoaMonthly: extractHOA(),
    };
}
/**
 * Extract address from a Redfin card element
 */
function extractAddressFromCard(cardElement) {
    // Try the address link
    const addressLink = cardElement.querySelector('.bp-Homecard__Address');
    if (addressLink) {
        const text = addressLink.textContent?.trim();
        if (text && text.length > 5) {
            return text;
        }
    }
    return null;
}
/**
 * Extract bedrooms from a Redfin card element
 */
function extractBedroomsFromCard(cardElement) {
    const bedsElement = cardElement.querySelector('.bp-Homecard__Stats--beds');
    if (bedsElement) {
        const text = bedsElement.textContent || '';
        // Check for "—" or other non-numeric indicators
        if (text.includes('—') || text.trim() === '' || text.toLowerCase().includes('n/a')) {
            return null;
        }
        const match = text.match(/(\d+)\s*(?:bed|bd|br|bedroom)/i);
        if (match) {
            const count = parseInt(match[1], 10);
            if (!isNaN(count) && count >= 0 && count <= 8) {
                return count;
            }
        }
    }
    return null;
}
/**
 * Extract price from a Redfin card element
 */
function extractPriceFromCard(cardElement) {
    // Try the price value element
    const priceElement = cardElement.querySelector('.bp-Homecard__Price--value');
    if (priceElement) {
        const text = priceElement.textContent || '';
        const price = parsePrice(text);
        if (price !== null)
            return price;
    }
    // Fallback: try the whole price container
    const priceContainer = cardElement.querySelector('.bp-Homecard__Price');
    if (priceContainer) {
        const text = priceContainer.textContent || '';
        const price = parsePrice(text);
        if (price !== null)
            return price;
    }
    return null;
}
/**
 * Extract property data from a Redfin card element
 */
function extractPropertyDataFromCard(cardElement) {
    return {
        address: extractAddressFromCard(cardElement),
        bedrooms: extractBedroomsFromCard(cardElement),
        price: extractPriceFromCard(cardElement),
        hoaMonthly: null, // HOA not available in card view
    };
}
/**
 * Extract address from a Zillow card element
 */
function extractAddressFromZillowCard(cardElement) {
    // Try the address element inside the property-card-link
    const addressElement = cardElement.querySelector('address');
    if (addressElement) {
        const text = addressElement.textContent?.trim();
        if (text && text.length > 5) {
            return text;
        }
    }
    return null;
}
/**
 * Extract bedrooms from a Zillow card element
 */
function extractBedroomsFromZillowCard(cardElement) {
    // Bedrooms are in [data-testid="property-card-details"] > li > b (first li)
    const detailsList = cardElement.querySelector('[data-testid="property-card-details"]');
    if (detailsList) {
        const firstLi = detailsList.querySelector('li');
        if (firstLi) {
            const boldElement = firstLi.querySelector('b');
            if (boldElement) {
                const text = boldElement.textContent?.trim();
                if (text) {
                    // Check for "—" or other non-numeric indicators
                    if (text.includes('—') || text.toLowerCase().includes('n/a')) {
                        return null;
                    }
                    const count = parseInt(text, 10);
                    if (!isNaN(count) && count >= 0 && count <= 8) {
                        return count;
                    }
                }
            }
        }
    }
    return null;
}
/**
 * Extract price from a Zillow card element
 */
function extractPriceFromZillowCard(cardElement) {
    // Try the price element (data-test or data-testid for new c11n layout)
    const priceElement = cardElement.querySelector('[data-test="property-card-price"]') ||
        cardElement.querySelector('[data-testid="property-card-price"]');
    if (priceElement) {
        const text = priceElement.textContent || '';
        const price = parsePrice(text);
        if (price !== null)
            return price;
    }
    // Fallback: try the styled price line
    const priceLine = cardElement.querySelector('.PropertyCardWrapper__StyledPriceLine-srp-8-109-3__sc-16e8gqd-1');
    if (priceLine) {
        const text = priceLine.textContent || '';
        const price = parsePrice(text);
        if (price !== null)
            return price;
    }
    return null;
}
/**
 * Extract property data from a Zillow card element
 */
function extractPropertyDataFromZillowCard(cardElement) {
    return {
        address: extractAddressFromZillowCard(cardElement),
        bedrooms: extractBedroomsFromZillowCard(cardElement),
        price: extractPriceFromZillowCard(cardElement),
        hoaMonthly: null, // HOA not available in card view
    };
}
/**
 * Extract address from Zillow expanded view
 */
function extractAddressFromZillowExpanded(container) {
    // Try multiple selectors for AddressWrapper (class names may vary)
    const addressWrappers = [
        container.querySelector('.styles__AddressWrapper-fshdp-8-112-0__sc-13x5vko-0'),
        container.querySelector('[class*="AddressWrapper"]'),
        container.querySelector('[class*="address-wrapper"]'),
    ].filter(Boolean);
    for (const addressWrapper of addressWrappers) {
        const h1 = addressWrapper.querySelector('h1');
        if (h1) {
            const text = h1.textContent?.trim();
            if (text && text.length > 5) {
                return text;
            }
        }
    }
    // Fallback: try any h1 with address-like text
    const h1Elements = container.querySelectorAll('h1');
    for (const h1 of Array.from(h1Elements)) {
        const text = h1.textContent?.trim();
        if (text && text.length > 5 && text.includes(',')) {
            return text;
        }
    }
    return null;
}
/**
 * Extract bedrooms from Zillow expanded view
 */
function extractBedroomsFromZillowExpanded(container) {
    // Bedrooms are in [data-testid="bed-bath-sqft-facts"] > first [data-testid="bed-bath-sqft-fact-container"]
    const factsContainer = container.querySelector('[data-testid="bed-bath-sqft-facts"]');
    if (factsContainer) {
        const firstFact = factsContainer.querySelector('[data-testid="bed-bath-sqft-fact-container"]');
        if (firstFact) {
            // The value is in a span with class containing "StyledValueText"
            const valueSpan = firstFact.querySelector('span[class*="StyledValueText"]');
            if (valueSpan) {
                const text = valueSpan.textContent?.trim();
                if (text) {
                    // Check for "—" or other non-numeric indicators
                    if (text.includes('—') || text.toLowerCase().includes('n/a')) {
                        return null;
                    }
                    const count = parseInt(text, 10);
                    if (!isNaN(count) && count >= 0 && count <= 8) {
                        return count;
                    }
                }
            }
        }
    }
    return null;
}
/**
 * Extract price from Zillow expanded view
 */
function extractPriceFromZillowExpanded(container) {
    // Price is in [data-testid="price"]
    const priceElement = container.querySelector('[data-testid="price"]');
    if (priceElement) {
        const text = priceElement.textContent || '';
        const price = parsePrice(text);
        if (price !== null)
            return price;
    }
    return null;
}
/**
 * Extract property data from Zillow expanded view
 */
function extractPropertyDataFromZillowExpanded(container) {
    return {
        address: extractAddressFromZillowExpanded(container),
        bedrooms: extractBedroomsFromZillowExpanded(container),
        price: extractPriceFromZillowExpanded(container),
        hoaMonthly: extractHOAFromZillowExpanded(container),
    };
}


/***/ },

/***/ 790
(__unused_webpack_module, exports, __webpack_require__) {


// API client for making requests to the main app API
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.fetchFMRData = fetchFMRData;
exports.fetchMarketParams = fetchMarketParams;
exports.fetchInvestmentScore = fetchInvestmentScore;
exports.trackMissingData = trackMissingData;
const config_1 = __webpack_require__(724);
const auth_1 = __webpack_require__(576);
/**
 * Fetch FMR data for a ZIP code
 */
async function fetchFMRData(zipCode) {
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        const url = `${API_BASE_URL}/api/search/fmr?zip=${encodeURIComponent(zipCode)}`;
        const authHeaders = await (0, auth_1.getAuthHeaders)();
        const response = await fetch(url, {
            headers: {
                ...authHeaders,
            },
        });
        const data = await response.json();
        if (response.status === 429) {
            return { data: data, error: data.error || 'Rate limit exceeded', rateLimited: true };
        }
        if (!response.ok) {
            return { data: data, error: data.error || 'Failed to fetch FMR data' };
        }
        return { data: data.data };
    }
    catch (error) {
        return {
            data: {},
            error: error instanceof Error ? error.message : 'Network error',
        };
    }
}
/**
 * Fetch market parameters (tax rate, mortgage rate) for a zip code
 */
async function fetchMarketParams(zip) {
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        const url = `${API_BASE_URL}/api/investment/market-params?zip=${encodeURIComponent(zip)}`;
        const authHeaders = await (0, auth_1.getAuthHeaders)();
        const response = await fetch(url, {
            headers: {
                ...authHeaders,
            },
        });
        const data = await response.json();
        if (response.status === 429) {
            return {
                data: { propertyTaxRateAnnualPct: null, mortgageRateAnnualPct: null },
                error: data.error || 'Rate limit exceeded',
                rateLimited: true,
            };
        }
        if (!response.ok) {
            return {
                data: { propertyTaxRateAnnualPct: null, mortgageRateAnnualPct: null },
                error: data.error || 'Failed to fetch market params',
            };
        }
        return {
            data: {
                propertyTaxRateAnnualPct: data.data?.propertyTaxRateAnnualPct ?? null,
                mortgageRateAnnualPct: data.data?.mortgageRateAnnualPct ?? null,
            },
        };
    }
    catch (error) {
        return {
            data: { propertyTaxRateAnnualPct: null, mortgageRateAnnualPct: null },
            error: error instanceof Error ? error.message : 'Network error',
        };
    }
}
/**
 * Fetch investment score for a zip code
 */
async function fetchInvestmentScore(zip) {
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        const url = `${API_BASE_URL}/api/investment/score?zip=${encodeURIComponent(zip)}`;
        const authHeaders = await (0, auth_1.getAuthHeaders)();
        const response = await fetch(url, {
            headers: {
                ...authHeaders,
            },
        });
        const data = await response.json();
        if (!response.ok) {
            return { found: false, error: data.error || 'Failed to fetch investment score' };
        }
        return {
            found: data.found ?? false,
            score: data.score,
            medianScore: data.medianScore,
        };
    }
    catch (error) {
        return {
            found: false,
            error: error instanceof Error ? error.message : 'Network error',
        };
    }
}
/**
 * Fire-and-forget logging of missing data events.
 * Never throws or blocks - used for debugging data gaps.
 */
async function trackMissingData(params) {
    if (params.missingFields.length === 0)
        return;
    const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
    const url = `${API_BASE_URL}/api/track/missing-data`;
    const body = JSON.stringify({
        zipCode: params.zipCode,
        address: params.address,
        bedrooms: params.bedrooms,
        price: params.price,
        missingFields: params.missingFields,
        source: params.source || 'chrome-extension',
    });
    // Fire-and-forget: don't await, don't care about response
    const authHeaders = await (0, auth_1.getAuthHeaders)();
    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            ...authHeaders,
        },
        body,
    }).catch(() => {
        // Silently ignore errors - this is best-effort tracking
    });
}


/***/ },

/***/ 953
(__unused_webpack_module, exports) {


// Address detection using site-specific CSS selectors
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.extractAddress = extractAddress;
exports.extractZipFromAddress = extractZipFromAddress;
/**
 * Detect which real estate site we're on
 */
function detectSite() {
    const hostname = window.location.hostname.toLowerCase();
    if (hostname.includes('zillow.com'))
        return 'zillow';
    if (hostname.includes('redfin.com'))
        return 'redfin';
    if (hostname.includes('realtor.com'))
        return 'realtor';
    if (hostname.includes('homes.com'))
        return 'homes';
    return 'unknown';
}
/**
 * Check if we're on a property detail page vs search results
 */
function isDetailPage() {
    const path = window.location.pathname.toLowerCase();
    return (path.includes('/homedetails/') ||
        path.includes('/home/') ||
        path.includes('/realestateandhomes-detail/') ||
        path.includes('/property/'));
}
/**
 * Extract address from the DOM using site-specific selectors
 */
function extractAddress() {
    const site = detectSite();
    const isDetail = isDetailPage();
    let selectors = [];
    if (site === 'zillow') {
        if (isDetail) {
            selectors = [
                '[data-testid="home-info"] h1',
                'h1[data-testid="address"]',
                'h1.property-address',
                '[data-testid="zpid-address"]',
                '[data-testid="home-info"] .Text-c11n-8-112-0__sc-aiai24-0',
                'h1.Text-c11n-8-112-0__sc-aiai24-0',
            ];
        }
        else {
            selectors = [
                '[data-testid="property-card"] address',
                '[data-testid="property-card-data"] address',
                '.property-card-data address',
                '[data-testid="address"]',
                '.list-card-addr',
            ];
        }
    }
    else if (site === 'redfin') {
        if (isDetail) {
            selectors = [
                '[data-testid="AddressDisplay"]',
                '.AddressDisplay',
                '.dp-address-block',
                'h1[class*="address"]',
                '.addressHeader',
                'h1.address',
                '.property-header-address',
            ];
        }
        else {
            selectors = [
                '.addressDisplay',
                '.bottomV2 .link-and-anchor',
                '.address',
                '[data-testid="address"]',
            ];
        }
    }
    else if (site === 'realtor') {
        if (isDetail) {
            selectors = [
                '[data-label="property-address"]',
                '.ldp-header-address',
                '.PropertyAddress',
            ];
        }
        else {
            selectors = [
                '.BasePropertyCard__Address',
                '[data-label="pc-address"]',
                '.PropertyCardAddress',
            ];
        }
    }
    else if (site === 'homes') {
        if (isDetail) {
            selectors = [
                '.property-header-address',
                'h1.address',
                '.property-address-header',
            ];
        }
        else {
            selectors = [
                '.property-address',
                '.home-card-address',
                '.address',
            ];
        }
    }
    // Try each selector
    for (const selector of selectors) {
        try {
            const element = document.querySelector(selector);
            if (element) {
                const text = (element.textContent || element.getAttribute('aria-label') || '').trim();
                if (text && text.length > 5) { // Minimum reasonable address length
                    return text;
                }
            }
        }
        catch (e) {
            // Continue to next selector
        }
    }
    return null;
}
/**
 * Extract zip code from address string
 * Prefers ZIP codes that appear at the end or after a state abbreviation
 */
function extractZipFromAddress(address) {
    if (!address)
        return null;
    // Pattern 1: ZIP code at the end of the string (most common)
    // Matches: "..., MI 48184" or "...48184"
    const endZipMatch = address.match(/\b(\d{5})\s*$/);
    if (endZipMatch) {
        return endZipMatch[1];
    }
    // Pattern 2: ZIP code after a state abbreviation (2 letters)
    // Matches: "..., MI 48184" or "..., CA 90210"
    const stateZipMatch = address.match(/\b([A-Z]{2})\s+(\d{5})\b/);
    if (stateZipMatch) {
        return stateZipMatch[2];
    }
    // Pattern 3: ZIP code after a comma (likely at the end of address line)
    // Matches: "..., 48184" or "..., Wayne, MI 48184"
    const commaZipMatch = address.match(/,\s*(\d{5})\b/);
    if (commaZipMatch) {
        return commaZipMatch[1];
    }
    // Pattern 4: Find all 5-digit numbers and prefer the last one
    // (ZIP codes typically appear after street numbers)
    const allZips = Array.from(address.matchAll(/\b(\d{5})\b/g));
    if (allZips.length > 0) {
        // Return the last match (most likely to be the ZIP code)
        return allZips[allZips.length - 1][1];
    }
    return null;
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;
var __webpack_unused_export__;

// Main content script for address detection and badge injection
__webpack_unused_export__ = ({ value: true });
const address_detector_1 = __webpack_require__(953);
const property_detector_1 = __webpack_require__(776);
const api_client_1 = __webpack_require__(790);
const cashflow_1 = __webpack_require__(293);
const types_1 = __webpack_require__(677);
const badge_1 = __webpack_require__(349);
const mini_view_1 = __webpack_require__(389);
const auth_1 = __webpack_require__(576);
const config_1 = __webpack_require__(724);
// Rate limit marker - returned when API returns 429
const RATE_LIMITED = 'RATE_LIMITED';
// Cache to avoid re-processing the same page
let processedAddresses = new Set();
let badgeElement = null;
let miniViewContainer = null;
// Track badges by card element for cleanup
const cardBadges = new Map();
// Observer refs so we can disconnect on re-entry (prevents memory leak when SPA navigates)
let redfinObserver = null;
let zillowObserver = null;
// Used to detect when Zillow reuses a card DOM node for a different listing
const CARD_KEY_DATASET_FIELD = 'fmrKey';
const HOA_PENDING_DATASET_FIELD = 'fmrHoaPending';
// Zillow card selectors: property-card (new c11n layout), property-card-data (legacy)
const ZILLOW_CARD_SELECTOR = '[data-testid="property-card"], [data-testid="property-card-data"]';
function isZillowListOrMapCard(el) {
    const tid = el.getAttribute('data-testid');
    return tid === 'property-card' || tid === 'property-card-data';
}
// We keep a lightweight, live view of the current mode so we can
// - branch badge rendering without re-reading storage for every decision
// - update badges immediately when the user switches modes in the popup
let currentBadgeMode = types_1.DEFAULT_PREFERENCES.mode;
let hasLoadedInitialMode = false;
let zillowCardPollInterval = null;
function isElementWithinZillowCardOrExpandedView(target) {
    if (!target)
        return false;
    const el = (target.nodeType === Node.ELEMENT_NODE ? target : target.parentElement);
    if (!el)
        return false;
    return !!el.closest?.(`${ZILLOW_CARD_SELECTOR}, [data-testid="fs-chip-container"]`);
}
/**
 * Remove cardBadges entries whose card element is no longer in the DOM (e.g. Zillow virtualized it).
 * Prevents unbounded growth and detached-DOM memory leaks.
 */
function pruneDetachedCardBadges() {
    for (const [card] of Array.from(cardBadges.entries())) {
        if (!card.isConnected) {
            cardBadges.delete(card);
        }
    }
}
function startZillowCardKeyPolling() {
    // Backstop: Zillow sometimes swaps selected map card state without triggering our debounced observer.
    if (zillowCardPollInterval !== null)
        return;
    zillowCardPollInterval = setInterval(() => {
        try {
            // Only poll on Zillow search/map pages (not detail pages)
            const site = window.location.hostname.toLowerCase();
            const isZillowDetail = site.includes('zillow.com') && window.location.pathname.toLowerCase().includes('/homedetails/');
            if (!site.includes('zillow.com') || isZillowDetail)
                return;
            pruneDetachedCardBadges();
            // Limit work: only check a small number of visible cards that already have badges
            const badgedCards = Array.from(document.querySelectorAll(`${ZILLOW_CARD_SELECTOR} .fmr-badge`))
                .map((b) => b.closest(ZILLOW_CARD_SELECTOR))
                .filter(Boolean);
            const seen = new Set();
            let checked = 0;
            for (const card of badgedCards) {
                if (seen.has(card))
                    continue;
                seen.add(card);
                if (!card.isConnected)
                    continue;
                // "Visible-ish" heuristic
                if (card.offsetParent === null)
                    continue;
                checked++;
                if (checked > 5)
                    break;
                const cardData = (0, property_detector_1.extractPropertyDataFromZillowCard)(card);
                if (!cardData.address)
                    continue;
                const key = getCardDataKey(cardData.address, cardData.price, cardData.bedrooms);
                const lastKey = card.dataset?.[CARD_KEY_DATASET_FIELD];
                if (lastKey && lastKey !== key) {
                    const existingBadge = card.querySelector('.fmr-badge');
                    if (existingBadge)
                        existingBadge.remove();
                    processCard(card, 'map', 'zillow').catch(() => { });
                }
            }
        }
        catch {
            // Ignore polling errors
        }
    }, 650);
}
// LRU-like cache with max 100 entries (using Map with insertion order)
const zipCodeCache = new Map();
const MAX_CACHE_SIZE = 100;
const fmrOnlyZipCache = new Map();
const MAX_FMR_ONLY_CACHE_SIZE = 100;
function getCachedFmrOnlyZipData(zipCode) {
    const entry = fmrOnlyZipCache.get(zipCode);
    if (!entry)
        return null;
    // LRU: move to end
    fmrOnlyZipCache.delete(zipCode);
    fmrOnlyZipCache.set(zipCode, entry);
    return entry.fmrData;
}
function setCachedFmrOnlyZipData(zipCode, fmrData) {
    if (fmrOnlyZipCache.size >= MAX_FMR_ONLY_CACHE_SIZE) {
        const firstKey = fmrOnlyZipCache.keys().next().value;
        if (firstKey)
            fmrOnlyZipCache.delete(firstKey);
    }
    fmrOnlyZipCache.set(zipCode, { fmrData, timestamp: Date.now() });
}
// Cache key: address + price + bedrooms (normalized)
function getCashFlowCacheKey(address, price, bedrooms) {
    const normalizedAddress = address.toLowerCase().trim();
    const priceStr = price !== null ? String(price) : 'null';
    const bedroomsStr = bedrooms !== null ? String(bedrooms) : 'null';
    return `${normalizedAddress}|${priceStr}|${bedroomsStr}`;
}
// LRU-like cache with max 200 entries
const cashFlowCache = new Map();
const MAX_CASH_FLOW_CACHE_SIZE = 200;
/**
 * Get cached cash flow for a property
 * Returns null if not cached, or if cached but HOA unavailable and we need HOA
 */
function getCachedCashFlow(address, price, bedrooms, requireHOA = false) {
    const key = getCashFlowCacheKey(address, price, bedrooms);
    const entry = cashFlowCache.get(key);
    if (entry) {
        // If we require HOA but cached entry doesn't have HOA, don't use it
        if (requireHOA && !entry.hasHOA) {
            return null;
        }
        // Move to end (most recently used) for LRU behavior
        cashFlowCache.delete(key);
        cashFlowCache.set(key, entry);
        return entry;
    }
    return null;
}
/**
 * Set cached cash flow for a property
 * If entry exists with HOA, only update if new entry also has HOA (prioritize HOA results)
 * If entry exists without HOA, always update (expanded view results are better)
 */
function setCachedCashFlow(address, price, bedrooms, cashFlow, hoaMonthly, hasHOA) {
    const key = getCashFlowCacheKey(address, price, bedrooms);
    const existing = cashFlowCache.get(key);
    // If existing entry has HOA and new one doesn't, don't overwrite (prioritize HOA)
    if (existing && existing.hasHOA && !hasHOA) {
        return;
    }
    // Remove oldest entry if cache is full
    if (cashFlowCache.size >= MAX_CASH_FLOW_CACHE_SIZE) {
        const firstKey = cashFlowCache.keys().next().value;
        if (firstKey) {
            cashFlowCache.delete(firstKey);
        }
    }
    // Add or update entry
    cashFlowCache.set(key, {
        cashFlow,
        hoaMonthly,
        hasHOA,
        timestamp: Date.now(),
    });
}
/**
 * Get cached data for a ZIP code
 */
function getCachedZipData(zipCode) {
    const entry = zipCodeCache.get(zipCode);
    if (entry) {
        // Move to end (most recently used) for LRU behavior
        zipCodeCache.delete(zipCode);
        zipCodeCache.set(zipCode, entry);
        return entry;
    }
    return null;
}
/**
 * Set cached data for a ZIP code
 */
function setCachedZipData(zipCode, fmrData, marketParams) {
    // Remove oldest entry if cache is full
    if (zipCodeCache.size >= MAX_CACHE_SIZE) {
        const firstKey = zipCodeCache.keys().next().value;
        if (firstKey) {
            zipCodeCache.delete(firstKey);
        }
    }
    // Add new entry (or update existing)
    zipCodeCache.set(zipCode, {
        fmrData,
        marketParams,
        timestamp: Date.now(),
    });
}
/**
 * Get user preferences from Chrome storage
 */
async function getPreferences() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(types_1.DEFAULT_PREFERENCES, (items) => {
            resolve(items);
        });
    });
}
function normalizeBadgeMode(value) {
    return value === 'fmr' ? 'fmr' : 'cashFlow';
}
async function loadInitialBadgeMode() {
    try {
        const prefs = await getPreferences();
        currentBadgeMode = normalizeBadgeMode(prefs.mode);
    }
    catch {
        // ignore
    }
    finally {
        hasLoadedInitialMode = true;
    }
}
async function refreshBadgesForModeChange(options) {
    const site = window.location.hostname.toLowerCase();
    const forceReprocess = options?.forceReprocess ?? false;
    // Only refresh if this site is enabled.
    const siteEnabled = await isSiteEnabled(site);
    if (!siteEnabled) {
        // If disabled, remove any existing badges (best-effort) to avoid stale mode display.
        document.querySelectorAll('.fmr-badge').forEach((b) => b.remove());
        cardBadges.clear();
        badgeElement = null;
        return;
    }
    const isRedfinDetail = site.includes('redfin.com') && window.location.pathname.toLowerCase().includes('/home/');
    const isZillowDetail = site.includes('zillow.com') && window.location.pathname.toLowerCase().includes('/homedetails/');
    // List/map pages: re-run card processing.
    // When forceReprocess (e.g. rent source change), remove badges first so processCards reprocesses all.
    if (site.includes('redfin.com') && !isRedfinDetail) {
        if (forceReprocess) {
            document.querySelectorAll('.fmr-badge').forEach((b) => b.remove());
            cardBadges.clear();
        }
        await processCards('list', 'redfin');
        await processCards('map', 'redfin');
        return;
    }
    if (site.includes('zillow.com') && !isZillowDetail) {
        if (forceReprocess) {
            document.querySelectorAll('.fmr-badge').forEach((b) => b.remove());
            cardBadges.clear();
        }
        const expandedView = document.querySelector('[data-testid="fs-chip-container"]');
        if (expandedView) {
            processCard(expandedView, 'map', 'zillow').catch(() => { });
        }
        await processCards('list', 'zillow');
        await processCards('map', 'zillow');
        return;
    }
    // Detail pages: force re-processing quickly.
    processedAddresses.clear();
    document.querySelectorAll('.fmr-badge').forEach((b) => b.remove());
    cardBadges.clear();
    badgeElement = null;
    await processPage({ skipWait: true });
}
function setupModeChangeListener() {
    try {
        chrome.storage.onChanged.addListener((changes, areaName) => {
            if (areaName !== 'sync')
                return;
            // Handle mode changes
            if (changes.mode) {
                const next = normalizeBadgeMode(changes.mode.newValue);
                const prev = currentBadgeMode;
                currentBadgeMode = next;
                if (next !== prev) {
                    // Refresh in the background; badge updates are "live" and shouldn't require page refresh.
                    refreshBadgesForModeChange().catch(() => { });
                }
            }
            // Handle rent source changes (effective vs FMR) - affects both FMR display and cash flow calc
            if (changes.rentSource) {
                const next = changes.rentSource.newValue;
                const prev = changes.rentSource.oldValue;
                if (next !== prev && (next === 'effective' || next === 'fmr')) {
                    cashFlowCache.clear(); // Cached cash flow was computed with old rentSource
                    refreshBadgesForModeChange({ forceReprocess: true }).catch(() => { });
                }
            }
            // Handle auth state changes (user logged in/out)
            if (changes.fmr_extension_auth) {
                console.log('[FMR Content] Auth state changed, clearing cache and refreshing badges');
                // Clear all caches so we re-fetch data with new auth state
                zipCodeCache.clear();
                cashFlowCache.clear();
                processedAddresses.clear();
                // Refresh all badges
                refreshBadgesForModeChange().catch(() => { });
            }
        });
    }
    catch {
        // ignore
    }
}
/**
 * Calculate cash flow for detected property
 * @param address Property address
 * @param detectedBedrooms Number of bedrooms
 * @param detectedPrice Purchase price
 * @param preferences User preferences
 * @param hoaMonthly HOA monthly dues (null if not available)
 * @param checkCache Whether to check cache first (default: true)
 * @param isExpandedView Whether this is from an expanded/detail view (default: false)
 */
async function calculateCashFlow(address, detectedBedrooms, detectedPrice, preferences, hoaMonthly = null, checkCache = true, isExpandedView = false) {
    try {
        // Check cash flow cache first if enabled
        if (checkCache && detectedPrice !== null && detectedBedrooms !== null) {
            const cached = getCachedCashFlow(address, detectedPrice, detectedBedrooms, false);
            if (cached && (!isExpandedView || cached.hasHOA)) {
                // Use cached value if:
                // - It's a card view (not expanded), or
                // - It's an expanded view and cached value has HOA
                return cached.cashFlow;
            }
        }
        // Extract ZIP code from address first
        const zipCode = (0, address_detector_1.extractZipFromAddress)(address);
        if (!zipCode) {
            (0, api_client_1.trackMissingData)({
                address,
                bedrooms: detectedBedrooms,
                price: detectedPrice,
                missingFields: ['zip_code'],
            });
            return null;
        }
        // Check cache first
        let fmrData;
        let marketParams;
        const cachedData = getCachedZipData(zipCode);
        if (cachedData) {
            fmrData = cachedData.fmrData;
            marketParams = cachedData.marketParams;
        }
        else {
            // Fetch FMR data using ZIP code
            const fmrResponse = await (0, api_client_1.fetchFMRData)(zipCode);
            if (fmrResponse.rateLimited) {
                // Rate limited - return special marker
                return 'RATE_LIMITED';
            }
            if (fmrResponse.error || !fmrResponse.data) {
                (0, api_client_1.trackMissingData)({
                    zipCode,
                    address,
                    bedrooms: detectedBedrooms,
                    price: detectedPrice,
                    missingFields: ['fmr_data'],
                });
                return null;
            }
            fmrData = fmrResponse.data;
            // Fetch market params (tax rate and mortgage rate)
            const marketResponse = await (0, api_client_1.fetchMarketParams)(zipCode);
            if (marketResponse.rateLimited) {
                // Rate limited - return special marker
                return 'RATE_LIMITED';
            }
            if (marketResponse.error) {
                return null;
            }
            marketParams = {
                propertyTaxRateAnnualPct: marketResponse.data.propertyTaxRateAnnualPct,
                mortgageRateAnnualPct: marketResponse.data.mortgageRateAnnualPct,
            };
            // Store in cache
            setCachedZipData(zipCode, fmrData, marketParams);
        }
        // Use detected bedrooms or preference/default
        const bedrooms = detectedBedrooms ?? preferences.bedrooms ?? 3;
        if (bedrooms === null) {
            return null;
        }
        // Get rent for bedrooms (use rentSource preference: effective or fmr)
        const rentMonthly = (0, cashflow_1.getRentForBedrooms)(fmrData, bedrooms, preferences.rentSource || 'effective');
        if (rentMonthly === null) {
            (0, api_client_1.trackMissingData)({
                zipCode,
                address,
                bedrooms,
                price: detectedPrice,
                missingFields: ['fmr_bedroom'],
            });
            return null;
        }
        // Use detected price or preference (if price is null, can't calculate)
        const purchasePrice = detectedPrice ?? preferences.purchasePrice;
        if (purchasePrice === null || purchasePrice <= 0) {
            return null;
        }
        const taxRate = preferences.overrideTaxRate && preferences.propertyTaxRateAnnualPct !== null
            ? preferences.propertyTaxRateAnnualPct
            : marketParams.propertyTaxRateAnnualPct;
        const mortgageRate = preferences.overrideMortgageRate && preferences.mortgageRateAnnualPct !== null
            ? preferences.mortgageRateAnnualPct
            : marketParams.mortgageRateAnnualPct;
        if (taxRate === null || mortgageRate === null) {
            const missingFields = [];
            if (taxRate === null)
                missingFields.push('property_tax_rate');
            if (mortgageRate === null)
                missingFields.push('mortgage_rate');
            (0, api_client_1.trackMissingData)({
                zipCode,
                address,
                bedrooms,
                price: purchasePrice,
                missingFields,
            });
            return null;
        }
        // Calculate property management cost
        let propertyManagementMonthly = 0;
        if (preferences.propertyManagementMode === 'percent') {
            propertyManagementMonthly = rentMonthly * (preferences.propertyManagementPercent / 100);
        }
        else {
            propertyManagementMonthly = preferences.propertyManagementAmount;
        }
        // Use detected HOA if available, otherwise use preference (default 0)
        const hoa = hoaMonthly !== null ? hoaMonthly : preferences.hoaMonthly;
        // Calculate cash flow
        const result = (0, cashflow_1.computeCashFlow)({
            purchasePrice,
            rentMonthly,
            bedrooms,
            interestRateAnnualPct: mortgageRate,
            propertyTaxRateAnnualPct: taxRate,
            insuranceMonthly: preferences.insuranceMonthly,
            hoaMonthly: hoa,
            propertyManagementMonthly,
            downPayment: {
                mode: preferences.downPaymentMode || 'percent',
                percent: preferences.downPaymentPercent,
                amount: preferences.downPaymentAmount,
            },
            termMonths: 360,
            customLineItems: preferences.customLineItems || [],
        });
        const cashFlow = result?.monthlyCashFlow ?? null;
        // Cache the result
        if (checkCache && purchasePrice !== null && bedrooms !== null) {
            const hasHOA = hoaMonthly !== null; // HOA was available (even if 0)
            setCachedCashFlow(address, purchasePrice, bedrooms, cashFlow, hoaMonthly, hasHOA);
        }
        return cashFlow;
    }
    catch (error) {
        console.error('[FMR Extension] Error calculating cash flow:', error);
        return null;
    }
}
/**
 * Calculate FMR monthly rent for a detected property (no cash flow calculation).
 * Uses ZIP -> FMR data and bedroom count.
 */
async function calculateFmrMonthly(address, detectedBedrooms, rentSource = 'effective') {
    try {
        const zipCode = (0, address_detector_1.extractZipFromAddress)(address);
        if (!zipCode) {
            (0, api_client_1.trackMissingData)({
                address,
                bedrooms: detectedBedrooms,
                missingFields: ['zip_code'],
                source: 'chrome-extension-fmr-only',
            });
            return null;
        }
        if (detectedBedrooms === null || detectedBedrooms === undefined || isNaN(detectedBedrooms)) {
            (0, api_client_1.trackMissingData)({
                zipCode,
                address,
                missingFields: ['bedrooms'],
                source: 'chrome-extension-fmr-only',
            });
            return null;
        }
        // Reuse cash-flow ZIP cache if available (it includes FMR data), otherwise use FMR-only cache.
        const cachedZip = getCachedZipData(zipCode);
        let fmrData = cachedZip?.fmrData ?? getCachedFmrOnlyZipData(zipCode);
        if (!fmrData) {
            const fmrResponse = await (0, api_client_1.fetchFMRData)(zipCode);
            if (fmrResponse.rateLimited) {
                // Rate limited - return special marker
                return 'RATE_LIMITED';
            }
            if (fmrResponse.error || !fmrResponse.data) {
                (0, api_client_1.trackMissingData)({
                    zipCode,
                    address,
                    bedrooms: detectedBedrooms,
                    missingFields: ['fmr_data'],
                    source: 'chrome-extension-fmr-only',
                });
                return null;
            }
            fmrData = fmrResponse.data;
            setCachedFmrOnlyZipData(zipCode, fmrData);
        }
        const rentMonthly = (0, cashflow_1.getRentForBedrooms)(fmrData, detectedBedrooms, rentSource);
        if (rentMonthly === null) {
            (0, api_client_1.trackMissingData)({
                zipCode,
                address,
                bedrooms: detectedBedrooms,
                missingFields: ['fmr_bedroom'],
                source: 'chrome-extension-fmr-only',
            });
        }
        return rentMonthly;
    }
    catch (error) {
        console.error('[FMR Extension] Error calculating FMR:', error);
        return null;
    }
}
/**
 * Inject badge near address element
 */
async function injectBadge(addressElement, cashFlow, address, isLoading = false, cardElement, propertyData, insufficientInfo = false, nonInteractive = false, hoaUnavailable = false, rateLimited = false) {
    // Remove existing badge for this card if any
    if (cardElement) {
        const existingBadge = cardElement.querySelector('.fmr-badge');
        if (existingBadge) {
            existingBadge.remove();
        }
        // Also remove from our tracking
        const trackedBadge = cardBadges.get(cardElement);
        if (trackedBadge && trackedBadge.parentElement) {
            trackedBadge.remove();
        }
        cardBadges.delete(cardElement);
    }
    else {
        // For detail pages, remove any existing badges (check multiple locations)
        const existingBadges = document.querySelectorAll('.fmr-badge');
        existingBadges.forEach(badge => badge.remove());
        // Also clear the badgeElement reference
        if (badgeElement && badgeElement.parentElement) {
            badgeElement.remove();
        }
        badgeElement = null;
    }
    // Get FMR data if in FMR mode (and rent constraint flags for tooltip when available)
    let fmrMonthly = null;
    let rentConstrained = false;
    let missingMarketRent = false;
    const zipCode = (0, address_detector_1.extractZipFromAddress)(address);
    if (zipCode) {
        const cachedZip = getCachedZipData(zipCode);
        const cachedFmrOnly = getCachedFmrOnlyZipData(zipCode);
        const fmrData = cachedZip?.fmrData ?? cachedFmrOnly ?? null;
        if (fmrData) {
            const rc = fmrData.rentConstraint;
            if (rc) {
                rentConstrained = !!rc.isConstrained;
                missingMarketRent = !!rc.missingMarketRent;
            }
            if (currentBadgeMode === 'fmr' && !isLoading && !insufficientInfo && propertyData && propertyData.bedrooms !== null) {
                const prefs = await getPreferences();
                fmrMonthly = (0, cashflow_1.getRentForBedrooms)(fmrData, propertyData.bedrooms, prefs.rentSource || 'effective');
            }
        }
    }
    // Create and inject badge
    const badge = (0, badge_1.createBadgeElement)({
        cashFlow,
        mode: currentBadgeMode,
        fmrMonthly,
        isLoading,
        insufficientInfo,
        nonInteractive,
        hoaUnavailable,
        rateLimited,
        rentConstrained,
        missingMarketRent,
        onClick: async () => {
            // Check if user is logged in
            const loggedIn = await (0, auth_1.isLoggedIn)();
            if (rateLimited || !loggedIn) {
                // Trigger login flow
                try {
                    await (0, auth_1.login)();
                    location.reload();
                }
                catch (error) {
                    console.error('[FMR Extension] Login error:', error);
                }
            }
            else {
                // Open mini view
                const zipCode = (0, address_detector_1.extractZipFromAddress)(address);
                if (zipCode) {
                    // Use provided property data or extract it
                    const data = propertyData || (0, property_detector_1.extractPropertyData)();
                    openMiniView(address, zipCode, data.price, data.bedrooms, data.hoaMonthly);
                }
            }
        },
    });
    // Track badge for this card
    if (cardElement) {
        cardBadges.set(cardElement, badge);
        badgeElement = badge; // Keep for detail pages
    }
    else {
        badgeElement = badge;
    }
    // Inject near the address
    // For Zillow cards, the address is inside a link, so we need to inject after the link
    if (cardElement && isZillowListOrMapCard(cardElement)) {
        // Zillow card: inject after the address link
        const addressLink = addressElement.closest('a');
        if (addressLink && addressLink.parentElement) {
            // Insert after the link
            if (addressLink.nextSibling) {
                addressLink.parentElement.insertBefore(badge, addressLink.nextSibling);
            }
            else {
                addressLink.parentElement.appendChild(badge);
            }
        }
        else {
            // Fallback: inject after address element
            const fallbackParent1 = addressElement.parentElement;
            if (fallbackParent1) {
                if (addressElement.nextSibling) {
                    fallbackParent1.insertBefore(badge, addressElement.nextSibling);
                }
                else {
                    fallbackParent1.appendChild(badge);
                }
            }
        }
    }
    else if (cardElement && cardElement.getAttribute('data-testid') === 'fs-chip-container') {
        // Zillow expanded view: inject after the address wrapper or h1
        const addressWrapper = addressElement.closest('[class*="AddressWrapper"]');
        const targetParent = addressWrapper || addressElement.parentElement;
        if (targetParent) {
            if (addressElement.nextSibling) {
                targetParent.insertBefore(badge, addressElement.nextSibling);
            }
            else {
                targetParent.appendChild(badge);
            }
        }
        else {
            // Fallback: inject after address element
            const fallbackParent = addressElement.parentElement;
            if (fallbackParent) {
                if (addressElement.nextSibling) {
                    fallbackParent.insertBefore(badge, addressElement.nextSibling);
                }
                else {
                    fallbackParent.appendChild(badge);
                }
            }
        }
    }
    else {
        // Redfin or other: inject after address element
        const fallbackParent2 = addressElement.parentElement;
        if (fallbackParent2) {
            if (addressElement.nextSibling) {
                fallbackParent2.insertBefore(badge, addressElement.nextSibling);
            }
            else {
                fallbackParent2.appendChild(badge);
            }
        }
    }
}
/**
 * Check if we have sufficient data to calculate cash flow (Cash Flow mode).
 */
function hasSufficientData(address, bedrooms, price) {
    if (!address)
        return false;
    // Check if ZIP code can be extracted
    const zipCode = (0, address_detector_1.extractZipFromAddress)(address);
    if (!zipCode)
        return false;
    // Check if price is valid
    if (price === null || price === undefined || isNaN(price) || price <= 0)
        return false;
    // Check if bedrooms is valid (can be 0, but not null/NaN)
    if (bedrooms === null || bedrooms === undefined || isNaN(bedrooms))
        return false;
    return true;
}
/**
 * Check if we have sufficient data to display FMR (FMR-only mode).
 * Price is not required.
 */
function hasSufficientDataForFmr(address, bedrooms) {
    if (!address)
        return false;
    const zipCode = (0, address_detector_1.extractZipFromAddress)(address);
    if (!zipCode)
        return false;
    if (bedrooms === null || bedrooms === undefined || isNaN(bedrooms))
        return false;
    return true;
}
/**
 * Check if a badge already has valid data (not loading, not insufficient info, has cash flow)
 */
function badgeHasValidData(badge) {
    if (!badge)
        return false;
    const rawMode = badge.dataset?.fmrMode;
    const mode = rawMode === 'fmr' ? 'fmr' : 'cashFlow';
    // Check if badge is in loading state (has shimmer animation)
    const hasShimmer = badge.querySelector('[style*="shimmer"]') ||
        badge.querySelector('[style*="animation"]');
    if (hasShimmer) {
        return false; // Still loading
    }
    // Check if badge shows insufficient data (covers both missing input data and failed API fetch)
    const badgeText = badge.textContent || '';
    if (badgeText.includes('Insufficient data')) {
        return false; // Invalid or missing data
    }
    if (mode === 'cashFlow') {
        // Check if badge has a cash flow value (contains $ sign and number)
        // Badge format is like: "fmr.fyi +$1,234/mo"
        return /[\+\-]\$[\d,]+/.test(badgeText) && badgeText.includes('/mo');
    }
    // FMR-only mode: "$1,234/mo"
    return /\$[\d,]+/.test(badgeText) && badgeText.includes('/mo');
}
function getCardDataKey(address, price, bedrooms) {
    // Reuse the same normalization as the cashflow cache key
    return getCashFlowCacheKey(address, price, bedrooms);
}
/**
 * Process a single card element (Redfin or Zillow)
 */
async function processCard(cardElement, viewType, site) {
    // Extract data from card based on site
    let cardData;
    let addressElement = null;
    let isExpandedView = false;
    if (site === 'redfin') {
        cardData = (0, property_detector_1.extractPropertyDataFromCard)(cardElement);
        addressElement = cardElement.querySelector('.bp-Homecard__Address');
    }
    else {
        // Zillow - check if it's an expanded view or regular card
        if (cardElement.getAttribute('data-testid') === 'fs-chip-container') {
            // Expanded view
            isExpandedView = true;
            cardData = (0, property_detector_1.extractPropertyDataFromZillowExpanded)(cardElement);
            const addressWrapper = cardElement.querySelector('.styles__AddressWrapper-fshdp-8-112-0__sc-13x5vko-0');
            addressElement = addressWrapper?.querySelector('h1');
        }
        else {
            // Regular card
            cardData = (0, property_detector_1.extractPropertyDataFromZillowCard)(cardElement);
            // Address element is the <address> tag inside the address link
            const addressLink = cardElement.querySelector('.property-card-link') ||
                cardElement.querySelector('a[data-test="property-card-link"]') ||
                cardElement.querySelector('a[data-testid="property-card-address-link"]');
            addressElement = addressLink?.querySelector('address');
        }
    }
    if (!cardData.address || !addressElement) {
        return;
    }
    // If Zillow reuses the same card DOM node for a new listing (common in map view),
    // detect it and reprocess even if a badge already exists.
    const currentKey = getCardDataKey(cardData.address, cardData.price, cardData.bedrooms);
    const lastKey = cardElement.dataset?.[CARD_KEY_DATASET_FIELD];
    // Check if badge already exists in this card
    const existingBadge = cardElement.querySelector('.fmr-badge');
    if (existingBadge) {
        // Badge exists, check if it's still valid (not orphaned)
        const badgeParent = existingBadge.parentElement;
        const isOrphaned = !(badgeParent && cardElement.contains(badgeParent));
        const isSameListing = lastKey === currentKey;
        const rawMode = existingBadge.dataset?.fmrMode;
        const existingMode = rawMode === 'fmr' ? 'fmr' : 'cashFlow'; // default old badges to cashFlow
        const modeMatches = existingMode === currentBadgeMode;
        // Check if badge shows "Insufficient data" - if so, treat as final state (don't reprocess)
        const badgeText = existingBadge.textContent || '';
        const showsInsufficientData = badgeText.includes('Insufficient data');
        if (isSameListing && !isOrphaned && modeMatches) {
            // If badge shows insufficient data, don't reprocess (it's a final state)
            if (showsInsufficientData) {
                return;
            }
            // Otherwise check if badge has valid data
            if (badgeHasValidData(existingBadge)) {
                return;
            }
        }
        // Badge exists but listing changed, is orphaned, mode changed, or needs update; remove and reprocess
        existingBadge.remove();
    }
    // Record the key we processed for this DOM node (best-effort)
    try {
        cardElement.dataset[CARD_KEY_DATASET_FIELD] = currentKey;
    }
    catch { }
    // Check if user is logged in - require login for extension to work
    const loggedIn = await (0, auth_1.isLoggedIn)();
    if (!loggedIn) {
        // Show login required badge immediately
        const isZillowCard = site === 'zillow' && !isExpandedView;
        await injectBadge(addressElement, null, cardData.address, false, cardElement, {
            price: cardData.price,
            bedrooms: cardData.bedrooms,
            hoaMonthly: cardData.hoaMonthly,
        }, false, isZillowCard, !isExpandedView, true); // rateLimited = true
        return;
    }
    // Check if we have sufficient data
    const hasCashFlowData = hasSufficientData(cardData.address, cardData.bedrooms, cardData.price);
    const hasFmrData = hasSufficientDataForFmr(cardData.address, cardData.bedrooms);
    const hasData = currentBadgeMode === 'fmr' ? hasFmrData : hasCashFlowData;
    if (!hasData) {
        // Show insufficient info badge immediately
        // For Zillow cards, make badge non-interactive to prevent event propagation issues
        const isZillowCard = site === 'zillow' && !isExpandedView;
        await injectBadge(addressElement, null, cardData.address, false, cardElement, {
            price: cardData.price,
            bedrooms: cardData.bedrooms,
            hoaMonthly: cardData.hoaMonthly,
        }, true, isZillowCard, !isExpandedView); // insufficientInfo = true, nonInteractive = isZillowCard, hoaUnavailable = !isExpandedView
        return;
    }
    // Inject loading skeleton immediately
    // For Zillow cards, make badge non-interactive to prevent event propagation issues
    const isZillowCard = site === 'zillow' && !isExpandedView;
    await injectBadge(addressElement, null, cardData.address, true, cardElement, {
        price: cardData.price,
        bedrooms: cardData.bedrooms,
        hoaMonthly: cardData.hoaMonthly,
    }, false, isZillowCard, !isExpandedView);
    // Get user preferences
    const preferences = await getPreferences();
    // Keep our live mode in sync with storage (used by observers + mode switching refresh).
    currentBadgeMode = normalizeBadgeMode(preferences.mode);
    if (currentBadgeMode === 'fmr') {
        const fmrMonthly = await calculateFmrMonthly(cardData.address, cardData.bedrooms, preferences.rentSource || 'effective');
        // Update badge with actual data (FMR-only mode)
        const badge = cardBadges.get(cardElement);
        if (fmrMonthly === RATE_LIMITED) {
            if (badge && badge.updateRateLimitedContent) {
                badge.updateRateLimitedContent();
            }
        }
        else if (badge && badge.updateFmrContent) {
            badge.updateFmrContent(fmrMonthly, false, false, !isExpandedView);
        }
        else if (badge && badge.updateContent) {
            // Fallback: show N/A using existing rendering
            badge.updateContent(null, false, false, false);
        }
        return;
    }
    // Check cache first for card views
    let cashFlow = null;
    let hoaUnavailable = !isExpandedView;
    if (!isExpandedView && cardData.price !== null && cardData.bedrooms !== null) {
        // Check if we have a cached result with HOA
        const cached = getCachedCashFlow(cardData.address, cardData.price, cardData.bedrooms, false);
        if (cached && cached.hasHOA) {
            // Use cached result with HOA - no tooltip needed
            cashFlow = cached.cashFlow;
            hoaUnavailable = false;
        }
    }
    // Calculate if not using cache
    if (cashFlow === null) {
        cashFlow = await calculateCashFlow(cardData.address, cardData.bedrooms, cardData.price, preferences, cardData.hoaMonthly, true, // checkCache
        isExpandedView);
    }
    // Update badge with actual data
    const badge = cardBadges.get(cardElement);
    if (cashFlow === RATE_LIMITED) {
        if (badge && badge.updateRateLimitedContent) {
            badge.updateRateLimitedContent();
        }
    }
    else if (badge && badge.updateContent) {
        badge.updateContent(cashFlow, false, false, hoaUnavailable);
    }
}
/**
 * Process all cards in list or map view
 */
async function processCards(viewType, site) {
    // Find all card containers based on site
    let cards;
    if (site === 'redfin') {
        // Redfin uses .bp-Homecard__Content for card content
        cards = document.querySelectorAll('.bp-Homecard__Content');
    }
    else {
        // Zillow: property-card (new c11n layout), property-card-data (legacy)
        cards = document.querySelectorAll(ZILLOW_CARD_SELECTOR);
    }
    const processPromises = [];
    // Convert NodeList to Array for iteration
    const cardsArray = Array.from(cards);
    for (const card of cardsArray) {
        const cardElement = card;
        // Extract data to check if card has address
        let cardData;
        if (site === 'redfin') {
            cardData = (0, property_detector_1.extractPropertyDataFromCard)(cardElement);
        }
        else {
            cardData = (0, property_detector_1.extractPropertyDataFromZillowCard)(cardElement);
        }
        if (cardData.address) {
            const key = getCardDataKey(cardData.address, cardData.price, cardData.bedrooms);
            const lastKey = cardElement.dataset?.[CARD_KEY_DATASET_FIELD];
            // Check if badge exists in card - if not, process it
            const existingBadge = cardElement.querySelector('.fmr-badge');
            if (!existingBadge) {
                // Process asynchronously
                processPromises.push(processCard(cardElement, viewType, site).catch(() => { }));
            }
            else {
                // If Zillow reused this card node for a different listing, reprocess even if badge exists.
                if (site === 'zillow' && lastKey && lastKey !== key) {
                    existingBadge.remove();
                    processPromises.push(processCard(cardElement, viewType, site).catch(() => { }));
                    continue;
                }
                // If the badge is from a different mode, force reprocess so it swaps cleanly.
                const rawMode = existingBadge.dataset?.fmrMode;
                const existingMode = rawMode === 'fmr' ? 'fmr' : 'cashFlow';
                if (existingMode !== currentBadgeMode) {
                    existingBadge.remove();
                    processPromises.push(processCard(cardElement, viewType, site).catch(() => { }));
                    continue;
                }
                // Badge exists, verify it's still valid
                const badgeParent = existingBadge.parentElement;
                if (!badgeParent || !cardElement.contains(badgeParent)) {
                    // Badge is orphaned, reprocess
                    existingBadge.remove();
                    processPromises.push(processCard(cardElement, viewType, site).catch(() => { }));
                }
                else {
                    // Check if badge shows "Insufficient data" - if so, don't reprocess (it's a final state)
                    const badgeText = existingBadge.textContent || '';
                    if (badgeText.includes('Insufficient data')) {
                        // Badge shows insufficient data, skip reprocessing
                        continue;
                    }
                    // Badge exists and is valid - check if we have cached HOA data to update it
                    if (currentBadgeMode === 'cashFlow') {
                        if (cardData.price !== null && cardData.bedrooms !== null) {
                            const cached = getCachedCashFlow(cardData.address, cardData.price, cardData.bedrooms, false);
                            if (cached && cached.hasHOA && existingBadge.updateContent) {
                                // Update badge with cached HOA data (remove tooltip)
                                existingBadge.updateContent(cached.cashFlow, false, false, false);
                            }
                        }
                    }
                }
            }
        }
    }
    // Wait for all cards to start processing (but don't wait for completion)
    await Promise.all(processPromises);
}
/**
 * Check if the current site is enabled in preferences
 */
async function isSiteEnabled(site) {
    const preferences = await getPreferences();
    const enabledSites = preferences.enabledSites || { redfin: true, zillow: true };
    if (site.includes('redfin.com')) {
        return enabledSites.redfin !== false;
    }
    if (site.includes('zillow.com')) {
        return enabledSites.zillow !== false;
    }
    // For other sites (realtor, homes), default to enabled for now
    return true;
}
async function processPage(options) {
    // Disconnect previous observers to avoid leaking them on SPA navigation
    if (redfinObserver) {
        redfinObserver.disconnect();
        redfinObserver = null;
    }
    if (zillowObserver) {
        zillowObserver.disconnect();
        zillowObserver = null;
    }
    const site = window.location.hostname.toLowerCase();
    const isZillowListOrMap = site.includes('zillow.com') && !window.location.pathname.toLowerCase().includes('/homedetails/');
    if (!isZillowListOrMap && zillowCardPollInterval !== null) {
        clearInterval(zillowCardPollInterval);
        zillowCardPollInterval = null;
    }
    pruneDetachedCardBadges();
    if (processedAddresses.size > 300) {
        processedAddresses.clear();
    }
    // Ensure we have the user's selected mode before processing anything.
    if (!hasLoadedInitialMode) {
        await loadInitialBadgeMode();
    }
    // Wait a bit for page to load (especially for SPAs like Redfin)
    if (!options?.skipWait) {
        await new Promise(resolve => setTimeout(resolve, 1000));
    }
    // Check if this site is enabled
    const siteEnabled = await isSiteEnabled(site);
    if (!siteEnabled) {
        return; // Site is disabled, don't process
    }
    const isRedfinDetail = site.includes('redfin.com') && window.location.pathname.toLowerCase().includes('/home/');
    const isZillowDetail = site.includes('zillow.com') && window.location.pathname.toLowerCase().includes('/homedetails/');
    // Check if we're on Redfin list or map view
    if (site.includes('redfin.com') && !isRedfinDetail) {
        // Process existing cards (both list and map)
        await processCards('list', 'redfin');
        await processCards('map', 'redfin');
        // Watch for new cards being added or cards being re-rendered
        let processTimeout = null;
        redfinObserver = new MutationObserver((mutations) => {
            let hasChanges = false;
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const element = node;
                        if (element.classList?.contains('bp-Homecard__Content') ||
                            element.querySelector?.('.bp-Homecard__Content')) {
                            hasChanges = true;
                        }
                    }
                });
                mutation.removedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const element = node;
                        if (element.classList?.contains('bp-Homecard__Content') ||
                            element.querySelector?.('.bp-Homecard__Content')) {
                            hasChanges = true;
                        }
                    }
                });
            });
            if (hasChanges) {
                if (processTimeout)
                    clearTimeout(processTimeout);
                processTimeout = setTimeout(() => {
                    processCards('list', 'redfin').catch(() => { });
                    processCards('map', 'redfin').catch(() => { });
                }, 500);
            }
        });
        const contentAreas = [
            document.querySelector('.HomeViewsView'),
            document.querySelector('.MapAndListView'),
            document.querySelector('[data-rf-test-id="MapAndListView"]'),
            document.querySelector('.MapView'),
            document.querySelector('.MapHomeCard'),
            document.querySelector('main'),
            document.body
        ].filter(Boolean);
        contentAreas.forEach((contentArea) => {
            if (contentArea && redfinObserver) {
                redfinObserver.observe(contentArea, { childList: true, subtree: true });
            }
        });
        return;
    }
    // Check if we're on Zillow list or map view
    if (site.includes('zillow.com') && !isZillowDetail) {
        startZillowCardKeyPolling();
        // Check for expanded view (fs-chip-container)
        const expandedView = document.querySelector('[data-testid="fs-chip-container"]');
        if (expandedView) {
            if (currentBadgeMode === 'fmr') {
                // FMR-only mode: keep expanded view simple and reuse the normal card processing path.
                await processCard(expandedView, 'map', 'zillow');
            }
            else {
                const expandedData = (0, property_detector_1.extractPropertyDataFromZillowExpanded)(expandedView);
                if (expandedData.address) {
                    const expandedKey = getCardDataKey(expandedData.address, expandedData.price, expandedData.bedrooms);
                    const lastExpandedKey = expandedView.dataset?.[CARD_KEY_DATASET_FIELD];
                    // Find address element (h1 in AddressWrapper)
                    // Try multiple selectors for AddressWrapper
                    let addressElement = null;
                    const addressWrappers = [
                        expandedView.querySelector('.styles__AddressWrapper-fshdp-8-112-0__sc-13x5vko-0'),
                        expandedView.querySelector('[class*="AddressWrapper"]'),
                        expandedView.querySelector('[class*="address-wrapper"]'),
                    ].filter(Boolean);
                    for (const addressWrapper of addressWrappers) {
                        const h1 = addressWrapper.querySelector('h1');
                        if (h1) {
                            addressElement = h1;
                            break;
                        }
                    }
                    // Fallback: try any h1 with address-like text
                    if (!addressElement) {
                        const h1Elements = expandedView.querySelectorAll('h1');
                        for (const h1 of Array.from(h1Elements)) {
                            const text = h1.textContent?.trim();
                            if (text && text.length > 5 && text.includes(',')) {
                                addressElement = h1;
                                break;
                            }
                        }
                    }
                    if (addressElement) {
                        // If Zillow reused this expanded container for a new listing, never keep the old badge
                        const existingBadge = expandedView.querySelector('.fmr-badge');
                        const isSameListing = lastExpandedKey === expandedKey;
                        // Check if existing badge shows "Insufficient data" - if so, don't reprocess (it's a final state)
                        if (existingBadge && isSameListing) {
                            const badgeText = existingBadge.textContent || '';
                            if (badgeText.includes('Insufficient data')) {
                                // Badge already shows insufficient data for this listing, skip reprocessing
                                return;
                            }
                        }
                        if (existingBadge && !isSameListing) {
                            existingBadge.remove();
                            cardBadges.delete(expandedView);
                        }
                        // Track which listing this expanded view currently represents (Zillow can reuse this node)
                        try {
                            expandedView.dataset[CARD_KEY_DATASET_FIELD] = expandedKey;
                        }
                        catch { }
                        // Get current mode (ensure it's loaded) - use currentBadgeMode if available, otherwise fetch
                        if (!hasLoadedInitialMode) {
                            await loadInitialBadgeMode();
                        }
                        // Get preferences to ensure mode is current
                        const prefs = await getPreferences();
                        const mode = normalizeBadgeMode(prefs.mode);
                        // Check if we have sufficient data
                        const hasCashFlowData = hasSufficientData(expandedData.address, expandedData.bedrooms, expandedData.price);
                        const hasFmrData = hasSufficientDataForFmr(expandedData.address, expandedData.bedrooms);
                        const hasData = mode === 'fmr' ? hasFmrData : hasCashFlowData;
                        if (!hasData) {
                            // Clear HOA pending flag
                            try {
                                expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '0';
                            }
                            catch { }
                            await injectBadge(addressElement, null, expandedData.address, false, expandedView, {
                                price: expandedData.price,
                                bedrooms: expandedData.bedrooms,
                                hoaMonthly: expandedData.hoaMonthly,
                            }, true, false, false); // hoaUnavailable = false for expanded view
                            return;
                        }
                        // In expanded view, never show the non-HOA cached value even briefly.
                        // If we already have an HOA-aware cached result, we can show it immediately.
                        let cachedHoaCashFlow = null;
                        if (expandedData.price !== null && expandedData.bedrooms !== null) {
                            const cachedHoa = getCachedCashFlow(expandedData.address, expandedData.price, expandedData.bedrooms, true);
                            if (cachedHoa && cachedHoa.hasHOA) {
                                cachedHoaCashFlow = cachedHoa.cashFlow;
                            }
                        }
                        const existingBadge2 = expandedView.querySelector('.fmr-badge');
                        if (cachedHoaCashFlow !== null && existingBadge2 && existingBadge2.updateContent) {
                            // Ensure we don't refetch if we already have HOA-aware cached result and badge matches listing
                            existingBadge2.updateContent(cachedHoaCashFlow, false, false, false);
                            try {
                                expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '0';
                            }
                            catch { }
                            if (isSameListing && badgeHasValidData(existingBadge2)) {
                                return;
                            }
                        }
                        else {
                            // Force loading immediately (prevents "cached -> loading -> HOA" flicker)
                            try {
                                expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '1';
                            }
                            catch { }
                            if (existingBadge2 && existingBadge2.updateContent) {
                                existingBadge2.updateContent(null, true, false, false);
                            }
                            else {
                                await injectBadge(addressElement, null, expandedData.address, true, expandedView, {
                                    price: expandedData.price,
                                    bedrooms: expandedData.bedrooms,
                                    hoaMonthly: expandedData.hoaMonthly,
                                }, false, false, false); // hoaUnavailable = false for expanded view
                            }
                        }
                        // Get preferences and calculate
                        const preferences = await getPreferences();
                        const cashFlow = await calculateCashFlow(expandedData.address, expandedData.bedrooms, expandedData.price, preferences, expandedData.hoaMonthly, true, // checkCache
                        true // isExpandedView
                        );
                        // Update badge
                        const badge = cardBadges.get(expandedView);
                        if (cashFlow === RATE_LIMITED) {
                            if (badge && badge.updateRateLimitedContent) {
                                badge.updateRateLimitedContent();
                            }
                        }
                        else if (badge && badge.updateContent) {
                            // HOA is available in expanded view
                            badge.updateContent(cashFlow, false, false, false);
                        }
                        try {
                            expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '0';
                        }
                        catch { }
                    }
                }
            }
        }
        // Process existing cards (both list and map)
        await processCards('list', 'zillow');
        await processCards('map', 'zillow');
        // Watch for new cards being added or cards being re-rendered
        let processTimeout = null;
        zillowObserver = new MutationObserver((mutations) => {
            let hasChanges = false;
            mutations.forEach((mutation) => {
                if (mutation.type === 'attributes' || mutation.type === 'characterData') {
                    if (isElementWithinZillowCardOrExpandedView(mutation.target)) {
                        hasChanges = true;
                    }
                }
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const element = node;
                        // Check if it's a card or contains cards
                        if (element.matches?.(ZILLOW_CARD_SELECTOR) ||
                            element.querySelector?.(ZILLOW_CARD_SELECTOR) ||
                            element.getAttribute?.('data-testid') === 'fs-chip-container' ||
                            element.querySelector?.('[data-testid="fs-chip-container"]')) {
                            hasChanges = true;
                        }
                    }
                });
                // Check for removed nodes (cards being re-rendered)
                mutation.removedNodes.forEach((node) => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const element = node;
                        // If a card was removed, we need to reprocess
                        if (element.matches?.(ZILLOW_CARD_SELECTOR) ||
                            element.querySelector?.(ZILLOW_CARD_SELECTOR) ||
                            element.getAttribute?.('data-testid') === 'fs-chip-container' ||
                            element.querySelector?.('[data-testid="fs-chip-container"]')) {
                            hasChanges = true;
                        }
                    }
                });
            });
            if (hasChanges) {
                // Debounce to avoid processing too frequently
                if (processTimeout) {
                    clearTimeout(processTimeout);
                }
                processTimeout = setTimeout(() => {
                    // Check for expanded view again
                    const expandedView = document.querySelector('[data-testid="fs-chip-container"]');
                    if (expandedView) {
                        const existingBadge = expandedView.querySelector('.fmr-badge');
                        const expandedData = (0, property_detector_1.extractPropertyDataFromZillowExpanded)(expandedView);
                        if (expandedData.address) {
                            const expandedKey = getCardDataKey(expandedData.address, expandedData.price, expandedData.bedrooms);
                            const lastExpandedKey = expandedView.dataset?.[CARD_KEY_DATASET_FIELD];
                            const isSameListing = lastExpandedKey === expandedKey;
                            // If listing changed, clear old badge immediately
                            if (existingBadge && !isSameListing) {
                                existingBadge.remove();
                                cardBadges.delete(expandedView);
                            }
                            // Check if existing badge shows "Insufficient data" - if so, don't reprocess (it's a final state)
                            if (isSameListing && existingBadge) {
                                const badgeText = existingBadge.textContent || '';
                                if (badgeText.includes('Insufficient data')) {
                                    // Badge already shows insufficient data for this listing, skip reprocessing
                                    return; // Return early from the timeout callback
                                }
                            }
                            // If we already have HOA-aware cached value and badge is valid, skip
                            if (isSameListing && existingBadge && badgeHasValidData(existingBadge)) {
                                // ok
                            }
                            else {
                                // Find address element (h1 in AddressWrapper)
                                let addressElement = null;
                                const addressWrappers = [
                                    expandedView.querySelector('.styles__AddressWrapper-fshdp-8-112-0__sc-13x5vko-0'),
                                    expandedView.querySelector('[class*="AddressWrapper"]'),
                                    expandedView.querySelector('[class*="address-wrapper"]'),
                                ].filter(Boolean);
                                for (const addressWrapper of addressWrappers) {
                                    const h1 = addressWrapper.querySelector('h1');
                                    if (h1) {
                                        addressElement = h1;
                                        break;
                                    }
                                }
                                if (!addressElement) {
                                    const h1Elements = expandedView.querySelectorAll('h1');
                                    for (const h1 of Array.from(h1Elements)) {
                                        const text = h1.textContent?.trim();
                                        if (text && text.length > 5 && text.includes(',')) {
                                            addressElement = h1;
                                            break;
                                        }
                                    }
                                }
                                if (addressElement) {
                                    // Track which listing this expanded view currently represents
                                    try {
                                        expandedView.dataset[CARD_KEY_DATASET_FIELD] = expandedKey;
                                    }
                                    catch { }
                                    const hasCashFlowData = hasSufficientData(expandedData.address, expandedData.bedrooms, expandedData.price);
                                    const hasFmrData = hasSufficientDataForFmr(expandedData.address, expandedData.bedrooms);
                                    const hasData = currentBadgeMode === 'fmr' ? hasFmrData : hasCashFlowData;
                                    if (!hasData) {
                                        try {
                                            expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '0';
                                        }
                                        catch { }
                                        injectBadge(addressElement, null, expandedData.address, false, expandedView, {
                                            price: expandedData.price,
                                            bedrooms: expandedData.bedrooms,
                                            hoaMonthly: expandedData.hoaMonthly,
                                        }, true, false, false).catch(() => { });
                                    }
                                    else {
                                        // Always show loading unless we already have HOA-aware cached result
                                        let cachedHoaCashFlow = null;
                                        if (expandedData.price !== null && expandedData.bedrooms !== null) {
                                            const cachedHoa = getCachedCashFlow(expandedData.address, expandedData.price, expandedData.bedrooms, true);
                                            if (cachedHoa && cachedHoa.hasHOA)
                                                cachedHoaCashFlow = cachedHoa.cashFlow;
                                        }
                                        const existingBadge2 = expandedView.querySelector('.fmr-badge');
                                        if (cachedHoaCashFlow !== null && existingBadge2 && existingBadge2.updateContent) {
                                            existingBadge2.updateContent(cachedHoaCashFlow, false, false, false);
                                            try {
                                                expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '0';
                                            }
                                            catch { }
                                        }
                                        else {
                                            try {
                                                expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '1';
                                            }
                                            catch { }
                                            if (existingBadge2 && existingBadge2.updateContent) {
                                                existingBadge2.updateContent(null, true, false, false);
                                            }
                                            else {
                                                injectBadge(addressElement, null, expandedData.address, true, expandedView, {
                                                    price: expandedData.price,
                                                    bedrooms: expandedData.bedrooms,
                                                    hoaMonthly: expandedData.hoaMonthly,
                                                }, false, false, false).catch(() => { });
                                            }
                                        }
                                        getPreferences()
                                            .then((preferences) => calculateCashFlow(expandedData.address, expandedData.bedrooms, expandedData.price, preferences, expandedData.hoaMonthly, true, true))
                                            .then((cashFlow) => {
                                            const badge = cardBadges.get(expandedView);
                                            if (cashFlow === RATE_LIMITED) {
                                                if (badge && badge.updateRateLimitedContent) {
                                                    badge.updateRateLimitedContent();
                                                }
                                            }
                                            else if (badge && badge.updateContent) {
                                                badge.updateContent(cashFlow, false, false, false);
                                            }
                                            try {
                                                expandedView.dataset[HOA_PENDING_DATASET_FIELD] = '0';
                                            }
                                            catch { }
                                        })
                                            .catch(() => { });
                                    }
                                }
                            }
                        }
                    }
                    // Process both list and map cards
                    processCards('list', 'zillow').catch(() => { });
                    processCards('map', 'zillow').catch(() => { });
                }, 150);
            }
        });
        // Observe multiple areas to catch both list and map cards
        const contentAreas = [
            document.querySelector('#search-page-list-container'),
            document.querySelector('#map-fullscreen'),
            document.querySelector('#map-fullscreen-list-container'),
            document.querySelector('[data-testid="map-list-container"]'),
            document.querySelector('.SearchPage'),
            document.querySelector('[data-testid="search-page-list-container"]'),
            document.querySelector('main'),
            document.body
        ].filter(Boolean);
        contentAreas.forEach((contentArea) => {
            if (contentArea && zillowObserver) {
                zillowObserver.observe(contentArea, {
                    childList: true,
                    subtree: true,
                    attributes: true,
                    characterData: true,
                });
            }
        });
        return;
    }
    // Handle detail pages (existing logic)
    const address = (0, address_detector_1.extractAddress)();
    if (!address) {
        return;
    }
    // Skip if already processed
    const addressKey = `${window.location.href}-${address}`;
    if (processedAddresses.has(addressKey)) {
        // Check if badge already exists and shows insufficient data - if so, don't reprocess
        const existingBadge = document.querySelector('.fmr-badge');
        if (existingBadge) {
            const badgeText = existingBadge.textContent || '';
            if (badgeText.includes('Insufficient data')) {
                return; // Badge already shows insufficient data, don't reprocess
            }
            // If badge has valid data, also don't reprocess
            if (badgeHasValidData(existingBadge)) {
                return;
            }
        }
        return;
    }
    processedAddresses.add(addressKey);
    try {
        // Find address element first (before async operations)
        let addressElement = null;
        if (site.includes('zillow.com')) {
            // Try multiple selectors for Zillow detail pages
            addressElement = document.querySelector('[data-testid="home-info"] h1') ||
                document.querySelector('h1[data-testid="address"]') ||
                document.querySelector('h1.property-address') ||
                document.querySelector('[data-testid="zpid-address"]') ||
                document.querySelector('[data-testid="home-info"] .Text-c11n-8-112-0__sc-aiai24-0') ||
                document.querySelector('h1.Text-c11n-8-112-0__sc-aiai24-0');
        }
        else if (site.includes('redfin.com')) {
            // Try multiple selectors for Redfin
            addressElement = document.querySelector('[data-testid="AddressDisplay"]') ||
                document.querySelector('.AddressDisplay') ||
                document.querySelector('.dp-address-block') ||
                document.querySelector('h1[class*="address"]') ||
                document.querySelector('.addressHeader');
        }
        else if (site.includes('realtor.com')) {
            addressElement = document.querySelector('[data-label="property-address"]');
        }
        else if (site.includes('homes.com')) {
            addressElement = document.querySelector('.property-header-address');
        }
        if (!addressElement) {
            return;
        }
        // Wait a bit for page to fully load before extracting property data
        await new Promise(resolve => setTimeout(resolve, 500));
        // Extract property data after page has had time to load
        const propertyData = (0, property_detector_1.extractPropertyData)();
        // Check if user is logged in - require login for extension to work
        const loggedIn = await (0, auth_1.isLoggedIn)();
        if (!loggedIn) {
            // Show login required badge immediately
            await injectBadge(addressElement, null, address, false, undefined, propertyData, false, false, false, true); // rateLimited = true
            return;
        }
        // Get user preferences to check mode
        const preferences = await getPreferences();
        currentBadgeMode = normalizeBadgeMode(preferences.mode);
        // Check if we have sufficient data based on mode
        const hasCashFlowData = hasSufficientData(address, propertyData.bedrooms, propertyData.price);
        const hasFmrData = hasSufficientDataForFmr(address, propertyData.bedrooms);
        const hasData = currentBadgeMode === 'fmr' ? hasFmrData : hasCashFlowData;
        if (!hasData) {
            // Inject insufficient info badge
            await injectBadge(addressElement, null, address, false, undefined, undefined, true, false);
            return;
        }
        if (currentBadgeMode === 'fmr') {
            // FMR-only mode: check for cached FMR data first
            let cachedFmrMonthly = null;
            if (propertyData.bedrooms !== null) {
                const zipCode = (0, address_detector_1.extractZipFromAddress)(address);
                if (zipCode) {
                    const cachedZip = getCachedZipData(zipCode);
                    const cachedFmrOnly = getCachedFmrOnlyZipData(zipCode);
                    const fmrData = cachedZip?.fmrData ?? cachedFmrOnly;
                    if (fmrData) {
                        cachedFmrMonthly = (0, cashflow_1.getRentForBedrooms)(fmrData, propertyData.bedrooms, preferences.rentSource || 'effective');
                    }
                }
            }
            // Inject badge: show cached FMR if available, otherwise show loading
            if (cachedFmrMonthly !== null) {
                await injectBadge(addressElement, null, address, false, undefined, propertyData, false, false);
                // Update badge with cached FMR immediately
                if (badgeElement && badgeElement.updateFmrContent) {
                    badgeElement.updateFmrContent(cachedFmrMonthly, false, false, false);
                }
            }
            else {
                await injectBadge(addressElement, null, address, true, undefined, propertyData, false, false);
            }
            // Calculate and display FMR (if not already cached)
            if (cachedFmrMonthly === null) {
                const fmrMonthly = await calculateFmrMonthly(address, propertyData.bedrooms, preferences.rentSource || 'effective');
                // Update badge with FMR data
                if (badgeElement && badgeElement.updateFmrContent) {
                    if (fmrMonthly === RATE_LIMITED) {
                        if (badgeElement.updateRateLimitedContent) {
                            badgeElement.updateRateLimitedContent();
                        }
                    }
                    else if (fmrMonthly === null) {
                        // If fmrMonthly is null (missing data), show insufficient data instead of N/A to prevent reprocessing
                        badgeElement.updateFmrContent(null, false, true, false); // insufficientInfo = true
                    }
                    else {
                        badgeElement.updateFmrContent(fmrMonthly, false, false, false);
                    }
                }
            }
        }
        else {
            // Cash flow mode: existing logic
            // On detail pages, never show non-HOA cached value even briefly.
            // Check if we already have HOA-aware cached result first.
            let cachedHoaCashFlow = null;
            if (propertyData.price !== null && propertyData.bedrooms !== null) {
                const cachedHoa = getCachedCashFlow(address, propertyData.price, propertyData.bedrooms, true);
                if (cachedHoa && cachedHoa.hasHOA) {
                    cachedHoaCashFlow = cachedHoa.cashFlow;
                }
            }
            // Inject badge first (show loading or cached value)
            if (cachedHoaCashFlow !== null && cachedHoaCashFlow !== RATE_LIMITED) {
                await injectBadge(addressElement, cachedHoaCashFlow, address, false, undefined, propertyData, false, false);
                // Badge already shows cached value, no need to update
            }
            else {
                // Inject badge with loading state
                await injectBadge(addressElement, null, address, true, undefined, propertyData, false, false);
            }
            // Calculate cash flow (HOA is available on detail pages)
            // Always recalculate to ensure we have the latest result (cache might be stale)
            const cashFlow = await calculateCashFlow(address, propertyData.bedrooms, propertyData.price, preferences, propertyData.hoaMonthly, false, // checkCache: skip cache check to always recalculate with HOA (prevents flicker)
            true // isExpandedView (detail pages are expanded views)
            );
            // Update badge with actual data (HOA is available on detail pages)
            // Ensure badgeElement exists (it should have been created above)
            if (!badgeElement) {
                // Badge wasn't created, create it now
                await injectBadge(addressElement, null, address, false, undefined, propertyData, false, false);
            }
            if (badgeElement && badgeElement.updateContent) {
                if (cashFlow === RATE_LIMITED) {
                    if (badgeElement.updateRateLimitedContent) {
                        badgeElement.updateRateLimitedContent();
                    }
                }
                else if (cashFlow === null) {
                    // If cashFlow is null (missing market data), show insufficient data instead of N/A to prevent reprocessing
                    badgeElement.updateContent(null, false, true, false); // insufficientInfo = true
                }
                else {
                    badgeElement.updateContent(cashFlow, false, false, false);
                }
            }
        }
    }
    catch (error) {
        console.error('[FMR Extension] Error:', error);
        // Update badge to show error state (show insufficient data to prevent reprocessing)
        if (badgeElement && badgeElement.updateContent) {
            badgeElement.updateContent(null, false, true, false); // insufficientInfo = true
        }
    }
}
/**
 * Update card badges for a property when we get expanded view results
 * Also triggers re-processing of matching cards to ensure they get updated
 */
function updateCardBadgesForProperty(address, price, bedrooms) {
    // Check cache for this property
    const cached = getCachedCashFlow(address, price, bedrooms, false);
    if (!cached || !cached.hasHOA) {
        return; // No cached result with HOA
    }
    // Normalize address for comparison
    const normalizedAddress = address.toLowerCase().trim();
    // Track which cards we've updated to avoid duplicates
    const updatedCards = new Set();
    // Find all card badges in the map and update them if they match this property
    for (const [cardElement, badge] of cardBadges.entries()) {
        // Skip expanded views (they're already updated)
        if (cardElement.getAttribute('data-testid') === 'fs-chip-container') {
            continue;
        }
        // Check if card element is still in the DOM
        if (!cardElement.isConnected) {
            continue;
        }
        // Try to extract property data from the card to see if it matches
        let cardData = null;
        try {
            // Check if it's a Zillow card
            if (isZillowListOrMapCard(cardElement)) {
                cardData = (0, property_detector_1.extractPropertyDataFromZillowCard)(cardElement);
            }
            else if (cardElement.classList?.contains('bp-Homecard__Content')) {
                // Redfin card
                cardData = (0, property_detector_1.extractPropertyDataFromCard)(cardElement);
            }
        }
        catch (e) {
            // Skip if extraction fails
            continue;
        }
        // Check if this card matches the property
        if (!cardData || !cardData.address) {
            continue;
        }
        // Use more flexible matching - check if addresses are similar (normalize whitespace, case)
        const cardAddressNormalized = cardData.address.toLowerCase().trim().replace(/\s+/g, ' ');
        const targetAddressNormalized = normalizedAddress.replace(/\s+/g, ' ');
        if (cardAddressNormalized === targetAddressNormalized &&
            cardData.price === price &&
            cardData.bedrooms === bedrooms) {
            // Update the badge with cached result (no tooltip since HOA is available)
            if (badge.updateContent) {
                badge.updateContent(cached.cashFlow, false, false, false);
                updatedCards.add(cardElement);
            }
        }
    }
    // Also search the DOM directly for badges that might not be in the map
    // (e.g., if cards were re-rendered after expanded view closed)
    const allBadges = document.querySelectorAll('.fmr-badge');
    for (const badgeElement of Array.from(allBadges)) {
        const badge = badgeElement;
        // Skip if this badge is already in our map (we updated it above)
        let isInMap = false;
        for (const mappedBadge of Array.from(cardBadges.values())) {
            if (mappedBadge === badge) {
                isInMap = true;
                break;
            }
        }
        if (isInMap) {
            continue;
        }
        // Find the card element that contains this badge
        const cardElement = badge.closest(ZILLOW_CARD_SELECTOR) ||
            badge.closest('.bp-Homecard__Content') ||
            badge.closest('[data-testid="fs-chip-container"]');
        if (!cardElement) {
            continue;
        }
        // Skip expanded views
        if (cardElement.getAttribute('data-testid') === 'fs-chip-container') {
            continue;
        }
        // Skip if already updated
        if (updatedCards.has(cardElement)) {
            continue;
        }
        // Try to extract property data
        let cardData = null;
        try {
            if (isZillowListOrMapCard(cardElement)) {
                cardData = (0, property_detector_1.extractPropertyDataFromZillowCard)(cardElement);
            }
            else if (cardElement.classList?.contains('bp-Homecard__Content')) {
                cardData = (0, property_detector_1.extractPropertyDataFromCard)(cardElement);
            }
        }
        catch (e) {
            continue;
        }
        // Check if this card matches the property
        if (!cardData || !cardData.address) {
            continue;
        }
        // Use more flexible matching - check if addresses are similar (normalize whitespace, case)
        const cardAddressNormalized = cardData.address.toLowerCase().trim().replace(/\s+/g, ' ');
        const targetAddressNormalized = normalizedAddress.replace(/\s+/g, ' ');
        if (cardAddressNormalized === targetAddressNormalized &&
            cardData.price === price &&
            cardData.bedrooms === bedrooms) {
            // Update the badge with cached result (no tooltip since HOA is available)
            if (badge.updateContent) {
                badge.updateContent(cached.cashFlow, false, false, false);
                updatedCards.add(cardElement);
            }
        }
    }
    // Also trigger re-processing of matching cards that don't have badges yet
    // This ensures newly rendered cards get the HOA-aware value
    const site = window.location.hostname.toLowerCase();
    if (site.includes('zillow.com')) {
        const allCards = document.querySelectorAll(ZILLOW_CARD_SELECTOR);
        for (const card of Array.from(allCards)) {
            const cardElement = card;
            if (updatedCards.has(cardElement)) {
                continue; // Already updated
            }
            let cardData = null;
            try {
                cardData = (0, property_detector_1.extractPropertyDataFromZillowCard)(cardElement);
            }
            catch (e) {
                continue;
            }
            if (!cardData || !cardData.address) {
                continue;
            }
            const cardAddressNormalized = cardData.address.toLowerCase().trim().replace(/\s+/g, ' ');
            const targetAddressNormalized = normalizedAddress.replace(/\s+/g, ' ');
            if (cardAddressNormalized === targetAddressNormalized &&
                cardData.price === price &&
                cardData.bedrooms === bedrooms) {
                // Re-process this card to get the HOA-aware value
                processCard(cardElement, 'list', 'zillow').catch(() => { });
                processCard(cardElement, 'map', 'zillow').catch(() => { });
            }
        }
    }
    else if (site.includes('redfin.com')) {
        const allCards = document.querySelectorAll('.bp-Homecard__Content');
        for (const card of Array.from(allCards)) {
            const cardElement = card;
            if (updatedCards.has(cardElement)) {
                continue; // Already updated
            }
            let cardData = null;
            try {
                cardData = (0, property_detector_1.extractPropertyDataFromCard)(cardElement);
            }
            catch (e) {
                continue;
            }
            if (!cardData || !cardData.address) {
                continue;
            }
            const cardAddressNormalized = cardData.address.toLowerCase().trim().replace(/\s+/g, ' ');
            const targetAddressNormalized = normalizedAddress.replace(/\s+/g, ' ');
            if (cardAddressNormalized === targetAddressNormalized &&
                cardData.price === price &&
                cardData.bedrooms === bedrooms) {
                // Re-process this card to get the HOA-aware value
                processCard(cardElement, 'list', 'redfin').catch(() => { });
                processCard(cardElement, 'map', 'redfin').catch(() => { });
            }
        }
    }
}
/**
 * Open mini view modal
 */
async function openMiniView(address, zipCode, purchasePrice, bedrooms, hoaMonthly = null) {
    // Remove existing mini view if any
    const existingOverlay = document.querySelector('.fmr-mini-view-overlay');
    if (existingOverlay) {
        existingOverlay.remove();
    }
    // Get user preferences and API base URL (respects popup config)
    const [preferences, apiBaseUrl] = await Promise.all([getPreferences(), (0, config_1.getApiBaseUrl)()]);
    // Detect source site from hostname
    const hostname = window.location.hostname.toLowerCase();
    let sourceSite;
    if (hostname.includes('zillow.com')) {
        sourceSite = 'zillow';
    }
    else if (hostname.includes('redfin.com')) {
        sourceSite = 'redfin';
    }
    else if (hostname.includes('realtor.com')) {
        sourceSite = 'realtor';
    }
    else if (hostname.includes('homes.com')) {
        sourceSite = 'homes';
    }
    // Create overlay
    const overlay = document.createElement('div');
    overlay.className = 'fmr-mini-view-overlay';
    overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 10011;
  `;
    // Create mini view
    miniViewContainer = (0, mini_view_1.createMiniViewElement)({
        address,
        zipCode,
        apiBaseUrl,
        preferences,
        purchasePrice,
        bedrooms,
        hoaMonthly, // Pass detected HOA (null if not available, 0 if explicitly no HOA, or the actual amount)
        overlay, // Pass overlay reference so it can be hidden during dragging
        sourceSite, // Pass source site for referrer tracking
        onClose: () => {
            overlay.remove();
            miniViewContainer = null;
        },
    });
    // Append to overlay
    overlay.appendChild(miniViewContainer);
    // Close on overlay click (but not if we just finished dragging)
    overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
            // Don't close if drag just ended (prevents accidental close after dragging)
            if (overlay.__fmrDragJustEnded) {
                return;
            }
            overlay.remove();
            miniViewContainer = null;
        }
    });
    // Append to document
    document.body.appendChild(overlay);
}
/**
 * Initialize content script
 */
function init() {
    // Setup mode change listener first
    setupModeChangeListener();
    // Process page when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(() => processPage(), 500);
        });
    }
    else {
        setTimeout(() => processPage(), 500);
    }
    // Watch for navigation changes (SPA)
    let lastUrl = location.href;
    const handleUrlChange = () => {
        const url = location.href;
        if (url !== lastUrl) {
            lastUrl = url;
            processedAddresses.clear();
            cardBadges.clear();
            if (zillowCardPollInterval !== null) {
                clearInterval(zillowCardPollInterval);
                zillowCardPollInterval = null;
            }
            setTimeout(processPage, 1500);
        }
    };
    setInterval(handleUrlChange, 500);
    // Also watch for DOM changes that might indicate new content loaded
    if (document.body) {
        new MutationObserver(handleUrlChange).observe(document.body, { subtree: true, childList: true });
    }
    else {
        const bodyObserver = new MutationObserver(() => {
            if (document.body) {
                bodyObserver.disconnect();
                new MutationObserver(handleUrlChange).observe(document.body, { subtree: true, childList: true });
            }
        });
        bodyObserver.observe(document.documentElement, { childList: true });
    }
}
// Global error handler to catch any errors preventing script execution
window.addEventListener('error', (e) => {
    console.error('[FMR Extension] Error:', e.error, e.message);
});
// Start the content script
try {
    init();
}
catch (error) {
    console.error('[FMR Extension] Error initializing:', error);
}

})();

/******/ })()
;