/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 45
(__unused_webpack_module, exports, __webpack_require__) {


// Background service worker for the extension
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", ({ value: true }));
const auth = __importStar(__webpack_require__(576));
// Service worker initialized
console.log('[FMR Background] Service worker started');
// Inject auth-bridge script into auth pages
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        // Check if this is an auth page (fmr.fyi)
        const url = new URL(tab.url);
        const isAuthPage = url.hostname === 'fmr.fyi' &&
            url.pathname.startsWith('/auth/extension');
        if (isAuthPage) {
            console.log('[FMR Background] Injecting auth-bridge into:', tab.url);
            chrome.scripting.executeScript({
                target: { tabId },
                files: ['content/auth-bridge.js']
            }).then(() => {
                console.log('[FMR Background] Auth-bridge injected successfully');
            }).catch((error) => {
                console.error('[FMR Background] Failed to inject auth-bridge:', error);
            });
        }
    }
});
// Handle extension installation
chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        // Set default preferences on first install
        chrome.storage.sync.set({
            mode: 'cashFlow',
            bedrooms: null,
            purchasePrice: null,
            downPaymentPercent: 20,
            insuranceMonthly: 100,
            hoaMonthly: 0,
            propertyManagementMode: 'percent',
            propertyManagementPercent: 10,
            propertyManagementAmount: 0,
            overrideTaxRate: false,
            overrideMortgageRate: false,
            propertyTaxRateAnnualPct: null,
            mortgageRateAnnualPct: null,
            enabledSites: {
                redfin: true,
                zillow: true,
            },
        });
    }
});
// Listen for messages from content scripts and popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log('[FMR Background] Received message:', message.type, 'from tab:', sender.tab?.id);
    // Handle auth success from auth-bridge content script
    if (message.type === 'EXTENSION_AUTH_SUCCESS') {
        console.log('[FMR Background] Auth success received, storing tokens');
        (async () => {
            try {
                await chrome.storage.sync.set({ 'fmr_extension_auth': message.tokens });
                console.log('[FMR Background] Tokens stored successfully');
                if (sender.tab?.id) {
                    chrome.tabs.remove(sender.tab.id).catch(() => { });
                }
                sendResponse({ success: true });
            }
            catch (error) {
                console.error('[FMR Background] Failed to store tokens:', error);
                sendResponse({ success: false, error: String(error) });
            }
        })();
        return true; // Keep channel open for async response
    }
    // Handle auth error from auth-bridge content script
    if (message.type === 'EXTENSION_AUTH_ERROR') {
        console.log('[FMR Background] Auth error received:', message.error);
        // Close the auth tab
        if (sender.tab?.id) {
            chrome.tabs.remove(sender.tab.id).catch(() => { });
        }
        sendResponse({ success: false, error: message.error });
        return true;
    }
    // Handle auth-related messages
    if (message.type === 'AUTH_STATE_CHANGED') {
        // Notify all tabs about auth state change
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach((tab) => {
                if (tab.id) {
                    chrome.tabs.sendMessage(tab.id, {
                        type: 'AUTH_STATE_CHANGED',
                        isLoggedIn: message.isLoggedIn,
                    }).catch(() => {
                        // Ignore errors (tab might not have content script)
                    });
                }
            });
        });
    }
    // Handle token refresh requests
    if (message.type === 'REFRESH_TOKEN') {
        auth.refreshTokenIfNeeded()
            .then((tokens) => {
            sendResponse({ success: true, tokens });
        })
            .catch((error) => {
            sendResponse({ success: false, error: error.message });
        });
        return true; // Keep message channel open for async response
    }
    // Handle login tab opening requests from content scripts
    if (message.type === 'OPEN_LOGIN_TAB') {
        chrome.tabs.create({
            url: message.url,
            active: true,
        }, (tab) => {
            if (chrome.runtime.lastError || !tab || !tab.id) {
                sendResponse({ success: false, error: chrome.runtime.lastError?.message || 'Failed to open auth page' });
                return;
            }
            sendResponse({ success: true });
        });
        return true; // Keep message channel open for async response
    }
    return true; // Keep message channel open for async responses
});
// Listen for storage changes (e.g., token updates)
chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'sync' && changes.fmr_extension_auth) {
        // Auth tokens changed - notify all tabs
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach((tab) => {
                if (tab.id) {
                    chrome.tabs.sendMessage(tab.id, {
                        type: 'AUTH_STATE_CHANGED',
                        isLoggedIn: !!changes.fmr_extension_auth.newValue,
                    }).catch(() => {
                        // Ignore errors (tab might not have content script)
                    });
                }
            });
        });
    }
});


/***/ },

/***/ 576
(__unused_webpack_module, exports, __webpack_require__) {


// Auth service for Chrome extension
// Handles login, token storage, refresh, and logout
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokens = getTokens;
exports.logout = logout;
exports.refreshTokenIfNeeded = refreshTokenIfNeeded;
exports.getAuthHeaders = getAuthHeaders;
exports.login = login;
exports.isLoggedIn = isLoggedIn;
exports.getCurrentUser = getCurrentUser;
const config_1 = __webpack_require__(724);
const STORAGE_KEY = 'fmr_extension_auth';
function isContextInvalidated(err) {
    const msg = err instanceof Error ? err.message : String(err);
    return /Extension context invalidated/i.test(msg) || /context invalidated/i.test(msg);
}
// Get stored tokens
async function getTokens() {
    try {
        return await new Promise((resolve) => {
            try {
                chrome.storage.sync.get([STORAGE_KEY], (items) => {
                    if (chrome.runtime?.lastError && isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                        resolve(null);
                        return;
                    }
                    const tokens = items?.[STORAGE_KEY];
                    if (!tokens) {
                        resolve(null);
                        return;
                    }
                    const expiresAt = new Date(tokens.expiresAt);
                    if (expiresAt < new Date()) {
                        refreshTokenIfNeeded(tokens.refreshToken)
                            .then((newTokens) => resolve(newTokens))
                            .catch(() => resolve(null));
                        return;
                    }
                    resolve(tokens);
                });
            }
            catch (e) {
                if (isContextInvalidated(e)) {
                    resolve(null);
                }
                else {
                    throw e;
                }
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return null;
        throw e;
    }
}
// Store tokens
async function storeTokens(tokens) {
    try {
        return await new Promise((resolve, reject) => {
            try {
                chrome.storage.sync.set({ [STORAGE_KEY]: tokens }, () => {
                    if (chrome.runtime?.lastError) {
                        if (isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                            resolve();
                            return;
                        }
                        reject(new Error(chrome.runtime.lastError.message));
                    }
                    else {
                        resolve();
                    }
                });
            }
            catch (e) {
                if (isContextInvalidated(e)) {
                    resolve();
                }
                else {
                    reject(e);
                }
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return;
        throw e;
    }
}
// Clear tokens
async function logout() {
    try {
        const tokens = await getTokens();
        if (tokens?.refreshToken) {
            try {
                const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
                await fetch(`${API_BASE_URL}/api/auth/extension-token`, {
                    method: 'DELETE',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ refreshToken: tokens.refreshToken }),
                });
            }
            catch (error) {
                if (!isContextInvalidated(error))
                    console.error('Error revoking token:', error);
            }
        }
        await new Promise((resolve, reject) => {
            try {
                chrome.storage.sync.remove([STORAGE_KEY], () => {
                    if (chrome.runtime?.lastError && isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                        resolve();
                        return;
                    }
                    resolve();
                });
            }
            catch (e) {
                if (isContextInvalidated(e))
                    resolve();
                else
                    reject(e);
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return;
        throw e;
    }
}
// Refresh access token if needed
async function refreshTokenIfNeeded(refreshToken) {
    let tokens = null;
    try {
        tokens = await getTokens();
    }
    catch (e) {
        if (isContextInvalidated(e))
            return null;
        throw e;
    }
    if (!tokens && !refreshToken)
        return null;
    const tokenToUse = refreshToken || tokens?.refreshToken;
    if (!tokenToUse)
        return null;
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        const response = await fetch(`${API_BASE_URL}/api/auth/extension-token`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refreshToken: tokenToUse }),
        });
        if (!response.ok) {
            try {
                await logout();
            }
            catch {
                // ignore if logout fails (e.g. context invalidated)
            }
            return null;
        }
        const data = await response.json();
        const newTokens = {
            accessToken: data.accessToken,
            refreshToken: tokens?.refreshToken || tokenToUse,
            expiresAt: tokens?.expiresAt || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            user: data.user || tokens?.user,
        };
        await storeTokens(newTokens);
        return newTokens;
    }
    catch (error) {
        if (isContextInvalidated(error))
            return null;
        console.error('Error refreshing token:', error);
        try {
            await logout();
        }
        catch {
            // ignore
        }
        return null;
    }
}
// Get auth headers for API requests
async function getAuthHeaders() {
    let tokens = await getTokens();
    if (!tokens) {
        return {};
    }
    // Check if access token is expired or expiring soon (within 5 minutes)
    const expiresAt = new Date(tokens.expiresAt);
    const now = new Date();
    const fiveMinutesFromNow = new Date(now.getTime() + 5 * 60 * 1000);
    if (expiresAt < fiveMinutesFromNow) {
        // Refresh token
        tokens = await refreshTokenIfNeeded();
        if (!tokens) {
            return {};
        }
    }
    return {
        Authorization: `Bearer ${tokens.accessToken}`,
    };
}
// Open login tab - authentication is handled by the background service worker
async function login() {
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        return await new Promise((resolve, reject) => {
            try {
                if (typeof chrome.tabs === 'undefined' || !chrome.tabs.create) {
                    chrome.runtime.sendMessage({ type: 'OPEN_LOGIN_TAB', url: `${API_BASE_URL}/auth/extension` }, (response) => {
                        if (chrome.runtime?.lastError) {
                            const err = new Error(chrome.runtime.lastError.message);
                            if (isContextInvalidated(err)) {
                                reject(new Error('Extension was reloaded. Please refresh this page and try signing in again.'));
                                return;
                            }
                            reject(err);
                            return;
                        }
                        if (response?.success)
                            resolve();
                        else
                            reject(new Error(response?.error || 'Failed to open auth page'));
                    });
                    return;
                }
                chrome.tabs.create({ url: `${API_BASE_URL}/auth/extension`, active: true }, (tab) => {
                    if (chrome.runtime?.lastError) {
                        const err = new Error(chrome.runtime.lastError.message);
                        if (isContextInvalidated(err)) {
                            reject(new Error('Extension was reloaded. Please refresh this page and try signing in again.'));
                            return;
                        }
                        reject(err);
                        return;
                    }
                    if (!tab?.id) {
                        reject(new Error('Failed to open auth page'));
                        return;
                    }
                    resolve();
                });
            }
            catch (e) {
                if (isContextInvalidated(e)) {
                    reject(new Error('Extension was reloaded. Please refresh this page and try signing in again.'));
                }
                else {
                    reject(e);
                }
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e)) {
            throw new Error('Extension was reloaded. Please refresh this page and try signing in again.');
        }
        throw e;
    }
}
// Check if user is logged in
async function isLoggedIn() {
    const tokens = await getTokens();
    return tokens !== null;
}
// Get current user info
async function getCurrentUser() {
    const tokens = await getTokens();
    return tokens?.user || null;
}


/***/ },

/***/ 724
(__unused_webpack_module, exports) {


// Shared configuration for the extension
// API base URL is stored in local storage; only the popup enforces admin-only editing.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getApiBaseUrl = getApiBaseUrl;
exports.setApiBaseUrl = setApiBaseUrl;
const DEFAULT_API_BASE_URL = 'https://fmr.fyi';
function isContextInvalidated(err) {
    const msg = err instanceof Error ? err.message : String(err);
    return /Extension context invalidated/i.test(msg) || /context invalidated/i.test(msg);
}
/**
 * Get the API base URL. Reads from storage (no auth check here).
 * If extension context is invalidated (e.g. after reload), returns default without throwing.
 */
async function getApiBaseUrl() {
    try {
        return await new Promise((resolve) => {
            try {
                chrome.storage.local.get(['api_base_url'], (items) => {
                    if (chrome.runtime?.lastError && isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                        resolve(DEFAULT_API_BASE_URL);
                        return;
                    }
                    resolve(items?.api_base_url || DEFAULT_API_BASE_URL);
                });
            }
            catch (e) {
                if (isContextInvalidated(e))
                    resolve(DEFAULT_API_BASE_URL);
                else
                    throw e;
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return DEFAULT_API_BASE_URL;
        throw e;
    }
}
/**
 * Set the API base URL. Caller (popup) must enforce admin-only.
 * No-ops if extension context is invalidated.
 */
async function setApiBaseUrl(url) {
    try {
        return await new Promise((resolve, reject) => {
            try {
                chrome.storage.local.set({ api_base_url: url }, () => {
                    if (chrome.runtime?.lastError) {
                        if (isContextInvalidated(new Error(chrome.runtime.lastError.message))) {
                            resolve();
                            return;
                        }
                        reject(new Error(chrome.runtime.lastError.message));
                    }
                    else {
                        resolve();
                    }
                });
            }
            catch (e) {
                if (isContextInvalidated(e))
                    resolve();
                else
                    reject(e);
            }
        });
    }
    catch (e) {
        if (isContextInvalidated(e))
            return;
        throw e;
    }
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__(45);
/******/ 	
/******/ })()
;