/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ 224
(__unused_webpack_module, exports, __webpack_require__) {


// Settings management for the extension
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getPreferences = getPreferences;
exports.savePreferences = savePreferences;
exports.resetPreferences = resetPreferences;
const types_1 = __webpack_require__(677);
/**
 * Get user preferences from Chrome storage
 */
function getPreferences() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(types_1.DEFAULT_PREFERENCES, (items) => {
            resolve(items);
        });
    });
}
/**
 * Save user preferences to Chrome storage
 */
function savePreferences(prefs) {
    return new Promise((resolve, reject) => {
        chrome.storage.sync.set(prefs, () => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            }
            else {
                resolve();
            }
        });
    });
}
/**
 * Reset preferences to defaults
 */
function resetPreferences() {
    return savePreferences(types_1.DEFAULT_PREFERENCES);
}


/***/ },

/***/ 576
(__unused_webpack_module, exports, __webpack_require__) {


// Auth service for Chrome extension
// Handles login, token storage, refresh, and logout
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getTokens = getTokens;
exports.logout = logout;
exports.refreshTokenIfNeeded = refreshTokenIfNeeded;
exports.getAuthHeaders = getAuthHeaders;
exports.login = login;
exports.isLoggedIn = isLoggedIn;
exports.getCurrentUser = getCurrentUser;
const config_1 = __webpack_require__(724);
const STORAGE_KEY = 'fmr_extension_auth';
// Get stored tokens
async function getTokens() {
    return new Promise((resolve) => {
        chrome.storage.sync.get([STORAGE_KEY], (items) => {
            const tokens = items[STORAGE_KEY];
            if (!tokens) {
                resolve(null);
                return;
            }
            // Check if access token is expired
            const expiresAt = new Date(tokens.expiresAt);
            if (expiresAt < new Date()) {
                // Token expired, try to refresh
                refreshTokenIfNeeded(tokens.refreshToken)
                    .then((newTokens) => resolve(newTokens))
                    .catch(() => resolve(null));
                return;
            }
            resolve(tokens);
        });
    });
}
// Store tokens
async function storeTokens(tokens) {
    return new Promise((resolve, reject) => {
        chrome.storage.sync.set({ [STORAGE_KEY]: tokens }, () => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            }
            else {
                resolve();
            }
        });
    });
}
// Clear tokens
async function logout() {
    const tokens = await getTokens();
    if (tokens?.refreshToken) {
        // Revoke refresh token on server
        try {
            const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
            await fetch(`${API_BASE_URL}/api/auth/extension-token`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ refreshToken: tokens.refreshToken }),
            });
        }
        catch (error) {
            // Ignore errors - still clear local storage
            console.error('Error revoking token:', error);
        }
    }
    return new Promise((resolve) => {
        chrome.storage.sync.remove([STORAGE_KEY], () => {
            resolve();
        });
    });
}
// Refresh access token if needed
async function refreshTokenIfNeeded(refreshToken) {
    const tokens = await getTokens();
    if (!tokens && !refreshToken) {
        return null;
    }
    const tokenToUse = refreshToken || tokens?.refreshToken;
    if (!tokenToUse) {
        return null;
    }
    try {
        const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
        const response = await fetch(`${API_BASE_URL}/api/auth/extension-token`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ refreshToken: tokenToUse }),
        });
        if (!response.ok) {
            // Refresh failed - clear tokens
            await logout();
            return null;
        }
        const data = await response.json();
        // Merge with existing tokens (keep refresh token and user info)
        const newTokens = {
            accessToken: data.accessToken,
            refreshToken: tokens?.refreshToken || tokenToUse,
            expiresAt: tokens?.expiresAt || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
            user: data.user || tokens?.user,
        };
        await storeTokens(newTokens);
        return newTokens;
    }
    catch (error) {
        console.error('Error refreshing token:', error);
        await logout();
        return null;
    }
}
// Get auth headers for API requests
async function getAuthHeaders() {
    let tokens = await getTokens();
    if (!tokens) {
        return {};
    }
    // Check if access token is expired or expiring soon (within 5 minutes)
    const expiresAt = new Date(tokens.expiresAt);
    const now = new Date();
    const fiveMinutesFromNow = new Date(now.getTime() + 5 * 60 * 1000);
    if (expiresAt < fiveMinutesFromNow) {
        // Refresh token
        tokens = await refreshTokenIfNeeded();
        if (!tokens) {
            return {};
        }
    }
    return {
        Authorization: `Bearer ${tokens.accessToken}`,
    };
}
// Open login tab - authentication is handled by the background service worker
async function login() {
    const API_BASE_URL = await (0, config_1.getApiBaseUrl)();
    return new Promise((resolve, reject) => {
        // Check if we're in a content script (chrome.tabs is undefined)
        // If so, send a message to the background service worker
        if (typeof chrome.tabs === 'undefined' || !chrome.tabs.create) {
            chrome.runtime.sendMessage({ type: 'OPEN_LOGIN_TAB', url: `${API_BASE_URL}/auth/extension` }, (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error(chrome.runtime.lastError.message));
                    return;
                }
                if (response?.success) {
                    resolve();
                }
                else {
                    reject(new Error(response?.error || 'Failed to open auth page'));
                }
            });
            return;
        }
        // Use chrome.tabs.create for extension popups (window.open doesn't work)
        chrome.tabs.create({
            url: `${API_BASE_URL}/auth/extension`,
            active: true,
        }, (tab) => {
            if (chrome.runtime.lastError || !tab || !tab.id) {
                reject(new Error(chrome.runtime.lastError?.message || 'Failed to open auth page'));
                return;
            }
            // The background service worker will handle the auth success message
            // and store the tokens. Just resolve here - the popup will detect
            // auth state changes via storage listener.
            resolve();
        });
    });
}
// Check if user is logged in
async function isLoggedIn() {
    const tokens = await getTokens();
    return tokens !== null;
}
// Get current user info
async function getCurrentUser() {
    const tokens = await getTokens();
    return tokens?.user || null;
}


/***/ },

/***/ 677
(__unused_webpack_module, exports) {


// Shared types for the extension
// These can reference types from the main app lib/types.ts
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DEFAULT_PREFERENCES = void 0;
exports.DEFAULT_PREFERENCES = {
    mode: 'cashFlow',
    rentSource: 'effective',
    bedrooms: null,
    purchasePrice: null,
    downPaymentMode: 'percent',
    downPaymentPercent: 20,
    downPaymentAmount: 0,
    insuranceMonthly: 100,
    hoaMonthly: 0,
    propertyManagementMode: 'percent',
    propertyManagementPercent: 10,
    propertyManagementAmount: 0,
    overrideTaxRate: false,
    overrideMortgageRate: false,
    propertyTaxRateAnnualPct: null,
    mortgageRateAnnualPct: null,
    customLineItems: [],
    enabledSites: {
        redfin: true,
        zillow: true,
    },
};


/***/ },

/***/ 724
(__unused_webpack_module, exports) {


// Shared configuration for the extension
// API base URL is stored in local storage; only the popup enforces admin-only editing.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getApiBaseUrl = getApiBaseUrl;
exports.setApiBaseUrl = setApiBaseUrl;
const DEFAULT_API_BASE_URL = 'https://fmr.fyi';
/**
 * Get the API base URL. Reads from storage (no auth check here).
 * Popup hides the API config UI for non-admin users; this just returns the stored or default URL.
 */
async function getApiBaseUrl() {
    return new Promise((resolve) => {
        chrome.storage.local.get(['api_base_url'], (items) => {
            resolve(items.api_base_url || DEFAULT_API_BASE_URL);
        });
    });
}
/**
 * Set the API base URL. Caller (popup) must enforce admin-only.
 */
async function setApiBaseUrl(url) {
    return new Promise((resolve, reject) => {
        chrome.storage.local.set({ api_base_url: url }, () => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
            }
            else {
                resolve();
            }
        });
    });
}


/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;
var __webpack_unused_export__;

// Popup UI logic
__webpack_unused_export__ = ({ value: true });
const settings_1 = __webpack_require__(224);
// Custom line items state (used by modal and saveFormData)
let customLineItemsState = [];
let currentEditingItemId = null;
const types_1 = __webpack_require__(677);
const auth_1 = __webpack_require__(576);
const config_1 = __webpack_require__(724);
/**
 * Attach all button and form listeners synchronously, before any async work.
 * This ensures buttons work even when the extension runs in strict environments
 * (e.g. Chrome Web Store) where storage or timing might fail during init.
 * Uses try/catch per attachment so one failure does not block the rest.
 */
function attachAllListeners() {
    const loginBtn = document.getElementById('login-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const form = document.getElementById('settings-form');
    const resetBtn = document.getElementById('reset-btn');
    const displayMode = document.getElementById('display-mode');
    const pmMode = document.getElementById('pm-mode');
    const overrideTax = document.getElementById('override-tax-rate');
    const overrideMortgage = document.getElementById('override-mortgage-rate');
    if (!loginBtn && !form) {
        console.warn('[FMR Extension] Popup DOM not ready: login-btn and settings-form not found. Will retry.');
        setTimeout(attachAllListeners, 50);
        return;
    }
    try {
        if (loginBtn && !loginBtn.__fmrLoginListenerAttached) {
            loginBtn.__fmrLoginListenerAttached = true;
            loginBtn.addEventListener('click', async () => {
                try {
                    loginBtn.textContent = 'Signing in...';
                    loginBtn.setAttribute('disabled', 'true');
                    await (0, auth_1.login)();
                    await new Promise((r) => setTimeout(r, 100));
                    await refreshAccountSection();
                    showMessage('Successfully signed in!');
                }
                catch (error) {
                    console.error('Login error:', error);
                    showMessage('Login failed. Please try again.');
                }
                finally {
                    loginBtn.textContent = 'Sign In';
                    loginBtn.removeAttribute('disabled');
                }
            });
        }
        if (logoutBtn && !logoutBtn.__fmrLogoutListenerAttached) {
            logoutBtn.__fmrLogoutListenerAttached = true;
            logoutBtn.addEventListener('click', async () => {
                try {
                    logoutBtn.textContent = 'Logging out...';
                    logoutBtn.setAttribute('disabled', 'true');
                    await (0, auth_1.logout)();
                    await refreshAccountSection();
                    showMessage('Logged out successfully');
                }
                catch (error) {
                    console.error('Logout error:', error);
                    showMessage('Logout failed. Please try again.');
                }
                finally {
                    logoutBtn.textContent = 'Logout';
                    logoutBtn.removeAttribute('disabled');
                }
            });
        }
        if (form) {
            form.addEventListener('submit', async (e) => {
                e.preventDefault();
                try {
                    await saveFormData();
                    showMessage('Settings saved!');
                }
                catch (err) {
                    showMessage('Failed to save settings');
                }
            });
        }
        resetBtn?.addEventListener('click', async () => {
            if (confirm('Reset all settings to defaults?')) {
                try {
                    await (0, settings_1.resetPreferences)();
                    location.reload();
                }
                catch {
                    showMessage('Failed to reset');
                }
            }
        });
        displayMode?.addEventListener('change', updateConditionalFields);
        pmMode?.addEventListener('change', updateConditionalFields);
        overrideTax?.addEventListener('change', updateConditionalFields);
        overrideMortgage?.addEventListener('change', updateConditionalFields);
        try {
            chrome.storage.onChanged.addListener((changes, areaName) => {
                if (areaName === 'sync' && changes.fmr_extension_auth) {
                    setTimeout(() => {
                        refreshAccountSection().catch(() => { });
                        loadApiBaseUrl().catch(() => { });
                    }, 100);
                }
            });
        }
        catch (e) {
            console.warn('[FMR Extension] storage.onChanged listener:', e);
        }
        try {
            initCustomItems([]);
        }
        catch (e) {
            console.warn('[FMR Extension] initCustomItems:', e);
        }
    }
    catch (err) {
        console.error('[FMR Extension] attachAllListeners error:', err);
    }
}
/** Refresh account UI and API config visibility (async). */
async function refreshAccountSection() {
    await updateAccountSectionUI();
    await loadApiBaseUrl();
}
// Initialize popup
async function init() {
    // Attach all listeners first so buttons work even if async init fails (e.g. store install)
    attachAllListeners();
    try {
        await updateAccountSectionUI();
        await initApiConfig();
        const prefs = await (0, settings_1.getPreferences)();
        document.getElementById('display-mode').value =
            prefs.mode || 'cashFlow';
        document.getElementById('rent-source').value =
            prefs.rentSource || 'effective';
        document.getElementById('down-payment-percent').value =
            String(prefs.downPaymentPercent);
        document.getElementById('insurance-monthly').value =
            String(prefs.insuranceMonthly);
        document.getElementById('pm-mode').value =
            prefs.propertyManagementMode;
        document.getElementById('pm-percent').value =
            String(prefs.propertyManagementPercent);
        document.getElementById('pm-amount').value =
            String(prefs.propertyManagementAmount);
        document.getElementById('override-tax-rate').checked =
            prefs.overrideTaxRate;
        document.getElementById('override-mortgage-rate').checked =
            prefs.overrideMortgageRate;
        document.getElementById('tax-rate').value =
            prefs.propertyTaxRateAnnualPct !== null ? String(prefs.propertyTaxRateAnnualPct) : '';
        document.getElementById('mortgage-rate').value =
            prefs.mortgageRateAnnualPct !== null ? String(prefs.mortgageRateAnnualPct) : '';
        document.getElementById('enable-redfin').checked =
            prefs.enabledSites?.redfin !== false;
        document.getElementById('enable-zillow').checked =
            prefs.enabledSites?.zillow !== false;
        await loadApiBaseUrl();
        updateConditionalFields();
        customLineItemsState = prefs.customLineItems || [];
        renderCustomItems();
    }
    catch (error) {
        console.error('[FMR Extension] Init error:', error);
        showMessage('Settings loading failed. Buttons should still work.');
    }
}
function updateConditionalFields() {
    const displayMode = document.getElementById('display-mode').value;
    const isFmrMode = displayMode === 'fmr';
    // Show/hide cash flow related sections based on mode
    const financialSection = document.getElementById('financial-params-section');
    const propertyMgmtSection = document.getElementById('property-management-section');
    const customExpensesSection = document.getElementById('custom-expenses-section');
    const rateOverridesSection = document.getElementById('rate-overrides-section');
    if (financialSection) {
        financialSection.style.display = isFmrMode ? 'none' : 'block';
        financialSection.style.opacity = isFmrMode ? '0' : '1';
        financialSection.style.transition = 'opacity 0.2s ease, display 0.2s ease';
    }
    if (propertyMgmtSection) {
        propertyMgmtSection.style.display = isFmrMode ? 'none' : 'block';
        propertyMgmtSection.style.opacity = isFmrMode ? '0' : '1';
        propertyMgmtSection.style.transition = 'opacity 0.2s ease, display 0.2s ease';
    }
    if (customExpensesSection) {
        customExpensesSection.style.display = isFmrMode ? 'none' : 'block';
        customExpensesSection.style.opacity = isFmrMode ? '0' : '1';
        customExpensesSection.style.transition = 'opacity 0.2s ease, display 0.2s ease';
    }
    if (rateOverridesSection) {
        rateOverridesSection.style.display = isFmrMode ? 'none' : 'block';
        rateOverridesSection.style.opacity = isFmrMode ? '0' : '1';
        rateOverridesSection.style.transition = 'opacity 0.2s ease, display 0.2s ease';
    }
    const pmMode = document.getElementById('pm-mode').value;
    const pmPercentGroup = document.getElementById('pm-percent-group');
    const pmAmountGroup = document.getElementById('pm-amount-group');
    if (pmMode === 'percent') {
        pmPercentGroup.style.display = 'block';
        pmAmountGroup.style.display = 'none';
    }
    else {
        pmPercentGroup.style.display = 'none';
        pmAmountGroup.style.display = 'block';
    }
    const overrideTax = document.getElementById('override-tax-rate').checked;
    const overrideMortgage = document.getElementById('override-mortgage-rate').checked;
    const taxRateGroup = document.getElementById('tax-rate-group');
    const mortgageRateGroup = document.getElementById('mortgage-rate-group');
    taxRateGroup.style.display = overrideTax ? 'block' : 'none';
    mortgageRateGroup.style.display = overrideMortgage ? 'block' : 'none';
}
async function saveFormData() {
    const prefs = {
        mode: document.getElementById('display-mode').value,
        rentSource: document.getElementById('rent-source').value,
        downPaymentPercent: parseFloat(document.getElementById('down-payment-percent').value) || types_1.DEFAULT_PREFERENCES.downPaymentPercent,
        insuranceMonthly: parseFloat(document.getElementById('insurance-monthly').value) || types_1.DEFAULT_PREFERENCES.insuranceMonthly,
        propertyManagementMode: document.getElementById('pm-mode').value,
        propertyManagementPercent: parseFloat(document.getElementById('pm-percent').value) || types_1.DEFAULT_PREFERENCES.propertyManagementPercent,
        propertyManagementAmount: parseFloat(document.getElementById('pm-amount').value) || types_1.DEFAULT_PREFERENCES.propertyManagementAmount,
        overrideTaxRate: document.getElementById('override-tax-rate').checked,
        overrideMortgageRate: document.getElementById('override-mortgage-rate').checked,
        propertyTaxRateAnnualPct: document.getElementById('override-tax-rate').checked
            ? parseFloat(document.getElementById('tax-rate').value) || null
            : null,
        mortgageRateAnnualPct: document.getElementById('override-mortgage-rate').checked
            ? parseFloat(document.getElementById('mortgage-rate').value) || null
            : null,
        customLineItems: customLineItemsState,
        enabledSites: {
            redfin: document.getElementById('enable-redfin').checked,
            zillow: document.getElementById('enable-zillow').checked,
        },
    };
    await (0, settings_1.savePreferences)(prefs);
}
async function loadApiBaseUrl() {
    // Find the API Configuration section (it contains the api-base-url input)
    const apiBaseUrlInput = document.getElementById('api-base-url');
    if (!apiBaseUrlInput)
        return;
    const apiConfigSection = apiBaseUrlInput.closest('.section.card');
    if (!apiConfigSection)
        return;
    const user = await (0, auth_1.getCurrentUser)();
    const isAdmin = user?.role === 'admin';
    if (!isAdmin) {
        // Hide API config section for non-admin users
        apiConfigSection.style.display = 'none';
        return;
    }
    // Show API config section for admin users
    apiConfigSection.style.display = 'block';
    const apiBaseUrl = await (0, config_1.getApiBaseUrl)();
    apiBaseUrlInput.value = apiBaseUrl;
}
async function initApiConfig() {
    const apiBaseUrlInput = document.getElementById('api-base-url');
    if (!apiBaseUrlInput)
        return;
    // Check if user is admin before allowing API config
    const user = await (0, auth_1.getCurrentUser)();
    const isAdmin = user?.role === 'admin';
    if (!isAdmin) {
        return;
    }
    // Save API base URL on blur
    apiBaseUrlInput.addEventListener('blur', async () => {
        const url = apiBaseUrlInput.value.trim();
        if (url) {
            try {
                await (0, config_1.setApiBaseUrl)(url);
                showMessage('API URL updated!');
            }
            catch (error) {
                console.error('Error saving API URL:', error);
                showMessage('Failed to save API URL');
            }
        }
    });
}
/** Update account section UI only (login state, email, tier). Listeners are attached in attachAllListeners(). */
async function updateAccountSectionUI() {
    const loggedOutDiv = document.getElementById('account-logged-out');
    const loggedInDiv = document.getElementById('account-logged-in');
    const userEmail = document.getElementById('user-email');
    const userTier = document.getElementById('user-tier');
    const accountAvatar = document.getElementById('account-avatar');
    if (!loggedOutDiv || !loggedInDiv || !userEmail || !userTier) {
        if (loggedOutDiv)
            loggedOutDiv.style.display = 'block';
        return;
    }
    try {
        const isLoggedInStatus = await (0, auth_1.isLoggedIn)();
        const user = await (0, auth_1.getCurrentUser)();
        if (isLoggedInStatus && user) {
            loggedOutDiv.style.display = 'none';
            loggedInDiv.style.display = 'block';
            userEmail.textContent = user.email;
            const tierDisplay = user.tier
                .replace(/_/g, ' ')
                .replace(/\b\w/g, (c) => c.toUpperCase());
            userTier.textContent = `${tierDisplay}${user.role === 'admin' ? ' • Admin' : ''}`;
            if (accountAvatar)
                accountAvatar.textContent = user.email.charAt(0).toUpperCase();
        }
        else {
            loggedOutDiv.style.display = 'block';
            loggedInDiv.style.display = 'none';
            if (accountAvatar)
                accountAvatar.textContent = '';
        }
    }
    catch (error) {
        console.error('[FMR Extension] Error checking login status:', error);
        loggedOutDiv.style.display = 'block';
        loggedInDiv.style.display = 'none';
        if (accountAvatar)
            accountAvatar.textContent = '';
    }
}
function showMessage(message) {
    const msg = document.createElement('div');
    msg.textContent = message;
    msg.style.cssText = `
    position: fixed;
    top: 16px;
    right: 16px;
    background: #0a0a0a;
    color: white;
    padding: 8px 16px;
    border-radius: 4px;
    font-size: 12px;
    z-index: 10000;
  `;
    document.body.appendChild(msg);
    setTimeout(() => msg.remove(), 2000);
}
// --- Custom Line Items ---
function renderCustomItems() {
    const container = document.getElementById('custom-items-list');
    if (!container)
        return;
    if (customLineItemsState.length === 0) {
        container.innerHTML = '<p style="font-size: 12px; color: #737373; text-align: center; padding: 12px 0;">No custom expenses added yet</p>';
        return;
    }
    container.innerHTML = customLineItemsState.map((item) => {
        let details = '';
        if (item.method === 'amount') {
            details = `$${item.value.toFixed(2)}/month`;
        }
        else {
            const percentOfLabel = item.percentOf === 'purchasePrice' ? 'Purchase Price' :
                item.percentOf === 'rent' ? 'Monthly Rent' :
                    item.percentOf === 'downPayment' ? 'Down Payment' : '';
            details = `${item.value}% of ${percentOfLabel}`;
        }
        return `
      <div class="custom-item">
        <div class="custom-item-info">
          <div class="custom-item-label">${escapeHtml(item.label)}</div>
          <div class="custom-item-details">${escapeHtml(details)}</div>
        </div>
        <div class="custom-item-actions">
          <button type="button" class="icon-btn edit" data-id="${escapeHtml(item.id)}">Edit</button>
          <button type="button" class="icon-btn delete" data-id="${escapeHtml(item.id)}">Delete</button>
        </div>
      </div>
    `;
    }).join('');
    container.querySelectorAll('.edit').forEach((btn) => {
        btn.addEventListener('click', () => editCustomItem(btn.dataset.id ?? ''));
    });
    container.querySelectorAll('.delete').forEach((btn) => {
        btn.addEventListener('click', () => deleteCustomItem(btn.dataset.id ?? ''));
    });
}
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
function openCustomItemModal(itemId = null) {
    const modal = document.getElementById('custom-item-modal');
    const form = document.getElementById('custom-item-form');
    const titleEl = document.getElementById('modal-title');
    if (!modal || !form || !titleEl)
        return;
    currentEditingItemId = itemId;
    if (itemId) {
        titleEl.textContent = 'Edit Custom Expense';
        const item = customLineItemsState.find((i) => i.id === itemId);
        if (item) {
            document.getElementById('custom-item-label').value = item.label;
            document.getElementById('custom-item-method').value = item.method;
            document.getElementById('custom-item-value').value = String(item.value);
            if (item.method === 'percent') {
                document.getElementById('custom-item-percent-of').value = item.percentOf || 'purchasePrice';
            }
            updateCustomItemMethodUI();
        }
    }
    else {
        titleEl.textContent = 'Add Custom Expense';
        form.reset();
        updateCustomItemMethodUI();
    }
    modal.style.display = 'flex';
}
function closeCustomItemModal() {
    const modal = document.getElementById('custom-item-modal');
    const form = document.getElementById('custom-item-form');
    if (modal)
        modal.style.display = 'none';
    if (form)
        form.reset();
    currentEditingItemId = null;
}
function updateCustomItemMethodUI() {
    const methodEl = document.getElementById('custom-item-method');
    const percentOfGroup = document.getElementById('custom-item-percent-of-group');
    const valueLabel = document.getElementById('custom-item-value-label');
    if (!methodEl || !percentOfGroup || !valueLabel)
        return;
    const method = methodEl.value;
    if (method === 'percent') {
        percentOfGroup.style.display = 'block';
        valueLabel.textContent = 'Percentage (%)';
    }
    else {
        percentOfGroup.style.display = 'none';
        valueLabel.textContent = 'Amount ($)';
    }
}
function saveCustomItem(e) {
    e.preventDefault();
    const labelEl = document.getElementById('custom-item-label');
    const methodEl = document.getElementById('custom-item-method');
    const valueEl = document.getElementById('custom-item-value');
    const percentOfEl = document.getElementById('custom-item-percent-of');
    if (!labelEl || !methodEl || !valueEl)
        return;
    const label = labelEl.value;
    const method = methodEl.value;
    const value = parseFloat(valueEl.value);
    const percentOf = method === 'percent' ? percentOfEl?.value : undefined;
    const newItem = {
        id: currentEditingItemId || Date.now().toString(),
        label,
        method,
        value,
        percentOf,
    };
    if (currentEditingItemId) {
        const index = customLineItemsState.findIndex((i) => i.id === currentEditingItemId);
        if (index !== -1)
            customLineItemsState[index] = newItem;
    }
    else {
        customLineItemsState.push(newItem);
    }
    chrome.storage.sync.set({ customLineItems: customLineItemsState }, () => {
        renderCustomItems();
        closeCustomItemModal();
        showMessage('Custom expense saved');
    });
}
function editCustomItem(itemId) {
    openCustomItemModal(itemId);
}
function deleteCustomItem(itemId) {
    if (!confirm('Are you sure you want to delete this custom expense?'))
        return;
    customLineItemsState = customLineItemsState.filter((i) => i.id !== itemId);
    chrome.storage.sync.set({ customLineItems: customLineItemsState }, () => {
        renderCustomItems();
        showMessage('Custom expense deleted');
    });
}
function initCustomItems(initialItems) {
    customLineItemsState = initialItems;
    renderCustomItems();
    const addBtn = document.getElementById('add-custom-item-btn');
    if (!addBtn?.__fmrCustomItemsAttached) {
        addBtn.__fmrCustomItemsAttached = true;
        addBtn?.addEventListener('click', () => openCustomItemModal(null));
    }
    const modalClose = document.getElementById('modal-close-btn');
    const modalCancel = document.getElementById('modal-cancel-btn');
    const customForm = document.getElementById('custom-item-form');
    const customMethod = document.getElementById('custom-item-method');
    if (!modalClose?.__fmrCustomItemsModalAttached) {
        modalClose.__fmrCustomItemsModalAttached = true;
        modalClose?.addEventListener('click', closeCustomItemModal);
        modalCancel?.addEventListener('click', closeCustomItemModal);
        customForm?.addEventListener('submit', (e) => saveCustomItem(e));
        customMethod?.addEventListener('change', updateCustomItemMethodUI);
    }
}
/**
 * Run init only after the popup DOM is ready.
 * Extension popups can run the script before elements exist; waiting ensures getElementById finds them.
 */
function runWhenReady() {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => safeInit());
    }
    else {
        // Already loaded: defer one tick so the popup document is fully ready
        setTimeout(safeInit, 0);
    }
}
function safeInit() {
    try {
        init();
    }
    catch (err) {
        console.error('[FMR Extension] Popup init error:', err);
        showMessage('Something went wrong. Try opening the popup again.');
    }
}
runWhenReady();

})();

/******/ })()
;