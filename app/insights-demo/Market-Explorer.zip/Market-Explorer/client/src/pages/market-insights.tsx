import { useMemo, useState } from "react";
import {
  ArrowDown,
  ArrowRight,
  ArrowUp,
  ArrowUpDown,
  Building2,
  DollarSign,
  Filter,
  Globe,
  Percent,
  TrendingDown,
  TrendingUp,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Trend = "up" | "flat" | "down";

type Market = {
  id: string;
  name: string;
  state: string;
  region: string;
  population: number;
  priceMedian: number;
  priceYoY: number;
  fmr2br: number;
  fmrYoY: number;
  capRate: number;
  yieldYoY: number;
  risk: "Low" | "Medium" | "High";
};

const MARKETS: Market[] = [
  {
    id: "madison-wi",
    name: "Madison",
    state: "WI",
    region: "Midwest",
    population: 281000,
    priceMedian: 438000,
    priceYoY: 4.9,
    fmr2br: 1790,
    fmrYoY: 3.2,
    capRate: 6.1,
    yieldYoY: 0.6,
    risk: "Low",
  },
  {
    id: "raleigh-nc",
    name: "Raleigh",
    state: "NC",
    region: "Southeast",
    population: 476000,
    priceMedian: 512000,
    priceYoY: 2.1,
    fmr2br: 1910,
    fmrYoY: 2.9,
    capRate: 5.7,
    yieldYoY: 0.3,
    risk: "Low",
  },
  {
    id: "pittsburgh-pa",
    name: "Pittsburgh",
    state: "PA",
    region: "Northeast",
    population: 303000,
    priceMedian: 276000,
    priceYoY: 1.1,
    fmr2br: 1440,
    fmrYoY: 2.4,
    capRate: 7.2,
    yieldYoY: 0.8,
    risk: "Medium",
  },
  {
    id: "tampa-fl",
    name: "Tampa",
    state: "FL",
    region: "Southeast",
    population: 401000,
    priceMedian: 495000,
    priceYoY: -0.8,
    fmr2br: 2060,
    fmrYoY: 1.6,
    capRate: 5.3,
    yieldYoY: -0.2,
    risk: "Medium",
  },
  {
    id: "phoenix-az",
    name: "Phoenix",
    state: "AZ",
    region: "West",
    population: 1660000,
    priceMedian: 472000,
    priceYoY: -1.7,
    fmr2br: 1935,
    fmrYoY: 0.2,
    capRate: 5.6,
    yieldYoY: -0.4,
    risk: "High",
  },
  {
    id: "columbus-oh",
    name: "Columbus",
    state: "OH",
    region: "Midwest",
    population: 915000,
    priceMedian: 332000,
    priceYoY: 3.6,
    fmr2br: 1560,
    fmrYoY: 2.0,
    capRate: 6.8,
    yieldYoY: 0.4,
    risk: "Low",
  },
  {
    id: "sacramento-ca",
    name: "Sacramento",
    state: "CA",
    region: "West",
    population: 526000,
    priceMedian: 599000,
    priceYoY: 0.4,
    fmr2br: 2335,
    fmrYoY: 1.1,
    capRate: 4.8,
    yieldYoY: 0.1,
    risk: "Medium",
  },
  {
    id: "kansas-city-mo",
    name: "Kansas City",
    state: "MO",
    region: "Midwest",
    population: 508000,
    priceMedian: 329000,
    priceYoY: 2.7,
    fmr2br: 1525,
    fmrYoY: 2.2,
    capRate: 6.6,
    yieldYoY: 0.3,
    risk: "Medium",
  },
  {
    id: "charlotte-nc",
    name: "Charlotte",
    state: "NC",
    region: "Southeast",
    population: 915000,
    priceMedian: 468000,
    priceYoY: 1.3,
    fmr2br: 1845,
    fmrYoY: 2.7,
    capRate: 5.9,
    yieldYoY: 0.2,
    risk: "Medium",
  },
  {
    id: "minneapolis-mn",
    name: "Minneapolis",
    state: "MN",
    region: "Midwest",
    population: 429000,
    priceMedian: 396000,
    priceYoY: 2.6,
    fmr2br: 1680,
    fmrYoY: 1.5,
    capRate: 6.0,
    yieldYoY: 0.2,
    risk: "Low",
  },
];

function trendFromDelta(delta: number): Trend {
  if (delta > 0.25) return "up";
  if (delta < -0.25) return "down";
  return "flat";
}

function trendLabel(t: Trend) {
  return t === "up" ? "Up" : t === "down" ? "Down" : "Flat";
}

function TrendPill({ trend }: { trend: Trend }) {
  const cfg =
    trend === "up"
      ? {
          icon: TrendingUp,
          cls: "bg-emerald-500/10 text-emerald-700 border-emerald-600/15 dark:text-emerald-300",
        }
      : trend === "down"
        ? {
            icon: TrendingDown,
            cls: "bg-rose-500/10 text-rose-700 border-rose-600/15 dark:text-rose-300",
          }
        : {
            icon: ArrowRight,
            cls: "bg-slate-500/10 text-slate-700 border-slate-600/15 dark:text-slate-300",
          };

  const Icon = cfg.icon;
  return (
    <span
      data-testid={`pill-trend-${trend}`}
      className={`inline-flex items-center gap-1 rounded-md border px-2 py-0.5 text-[12px] font-medium ${cfg.cls}`}
    >
      <Icon className="h-3.5 w-3.5" strokeWidth={2} />
      {trendLabel(trend)}
    </span>
  );
}

function formatUSD(n: number) {
  return n.toLocaleString(undefined, {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  });
}

function formatPct(n: number) {
  return `${n.toFixed(1)}%`;
}

type SortKey = "price" | "fmr" | "yield";

type TrendMulti = Set<Trend>;

const TREND_OPTIONS: { value: Trend; label: string }[] = [
  { value: "up", label: "Up" },
  { value: "flat", label: "Flat" },
  { value: "down", label: "Down" },
];

function setEqualsAll(set: TrendMulti) {
  return set.size === 3;
}

function toggleTrend(set: TrendMulti, t: Trend) {
  const next = new Set(set);
  if (next.has(t)) next.delete(t);
  else next.add(t);
  return next;
}

function matchesTrend(set: TrendMulti, t: Trend) {
  // "All selected" behaves as Any
  if (setEqualsAll(set)) return true;
  return set.has(t);
}

export default function MarketInsightsPage() {
  const [query, setQuery] = useState("");
  const [region, setRegion] = useState<string>("all");

  const [propertyTrend, setPropertyTrend] = useState<Set<Trend>>(
    () => new Set<Trend>(["up", "flat", "down"]),
  );
  const [fmrTrend, setFmrTrend] = useState<Set<Trend>>(
    () => new Set<Trend>(["up"]),
  );
  const [yieldTrend, setYieldTrend] = useState<Set<Trend>>(
    () => new Set<Trend>(["up"]),
  );

  const [sortKey, setSortKey] = useState<SortKey>("yield");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();

    const filtered = MARKETS.filter((m) => {
      const matchesQuery =
        q.length === 0 ||
        `${m.name} ${m.state} ${m.region}`.toLowerCase().includes(q);

      const matchesRegion = region === "all" || m.region === region;

      const pTrend = trendFromDelta(m.priceYoY);
      const rTrend = trendFromDelta(m.fmrYoY);
      const yTrend = trendFromDelta(m.yieldYoY);

      const matchesP = matchesTrend(propertyTrend, pTrend);
      const matchesR = matchesTrend(fmrTrend, rTrend);
      const matchesY = matchesTrend(yieldTrend, yTrend);

      return matchesQuery && matchesRegion && matchesP && matchesR && matchesY;
    });

    const sorted = [...filtered].sort((a, b) => {
      const av =
        sortKey === "price" ? a.priceYoY : sortKey === "fmr" ? a.fmrYoY : a.capRate;
      const bv =
        sortKey === "price" ? b.priceYoY : sortKey === "fmr" ? b.fmrYoY : b.capRate;

      if (av === bv) return 0;

      if (sortDir === "desc") return av > bv ? -1 : 1;
      return av < bv ? -1 : 1;
    });

    return sorted;
  }, [query, region, propertyTrend, fmrTrend, yieldTrend, sortKey, sortDir]);

  const regions = useMemo(() => {
    const set = new Set(MARKETS.map((m) => m.region));
    return ["all", ...Array.from(set).sort()];
  }, []);

  const activeFiltersCount =
    (query.trim().length ? 1 : 0) +
    (region !== "all" ? 1 : 0) +
    (!setEqualsAll(propertyTrend) ? 1 : 0) +
    (!setEqualsAll(fmrTrend) ? 1 : 0) +
    (!setEqualsAll(yieldTrend) ? 1 : 0);

  function clearFilters() {
    setQuery("");
    setRegion("all");
    setPropertyTrend(new Set<Trend>(["up", "flat", "down"]));
    setFmrTrend(new Set<Trend>(["up", "flat", "down"]));
    setYieldTrend(new Set<Trend>(["up", "flat", "down"]));
  }

  function toggleSort(next: SortKey) {
    if (sortKey !== next) {
      setSortKey(next);
      // default for a newly selected sort is highest first
      setSortDir("desc");
      return;
    }
    // toggle direction
    setSortDir((d) => (d === "desc" ? "asc" : "desc"));
  }

  function SortIcon({ k }: { k: SortKey }) {
    if (sortKey !== k) return <ArrowUpDown className="h-4 w-4" />;
    return sortDir === "desc" ? (
      <ArrowDown className="h-4 w-4" />
    ) : (
      <ArrowUp className="h-4 w-4" />
    );
  }

  return (
    <div
      data-testid="view-market-insights"
      className="noise min-h-[calc(100vh-0px)] bg-background"
    >
      <div className="mx-auto w-full max-w-6xl px-5 py-8">
        {/* Header */}
        <div className="flex flex-col gap-5">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Globe className="h-4 w-4" />
                <span data-testid="text-breadcrumb">Insights</span>
                <span aria-hidden className="text-muted-foreground/60">
                  /
                </span>
                <span data-testid="text-breadcrumb-current" className="text-foreground">
                  Market explorer
                </span>
              </div>
              <h1
                data-testid="text-title"
                className="mt-2 text-balance text-3xl font-semibold tracking-tight"
              >
                Market insights explorer
              </h1>
              <p
                data-testid="text-subtitle"
                className="mt-1 max-w-2xl text-pretty text-sm leading-6 text-muted-foreground"
              >
                Explore markets by home value, rent, and yield.
              </p>
            </div>

            <div className="hidden sm:flex items-center gap-2">
              <Badge
                data-testid="badge-results"
                variant="secondary"
                className="rounded-md px-3 py-1"
              >
                {results.length} markets
              </Badge>
              {activeFiltersCount > 0 ? (
                <Badge
                  data-testid="badge-filters"
                  variant="outline"
                  className="rounded-md px-3 py-1"
                >
                  {activeFiltersCount} filter{activeFiltersCount === 1 ? "" : "s"}
                </Badge>
              ) : null}
            </div>
          </div>

          {/* Controls */}
          <Card
            data-testid="card-filters"
            className="rounded-lg border-card-border bg-card shadow-none"
          >
            <div className="p-4 sm:p-5">
              <div className="flex flex-col gap-4">
                <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                  <div className="flex min-w-0 flex-1 flex-col gap-3 md:flex-row md:items-center">
                    <div className="relative w-full md:max-w-[420px]">
                      <Input
                        data-testid="input-search"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="Search markets (city, state, region)"
                        className="h-10 bg-background"
                        type="search"
                      />
                      <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                        <Filter className="h-4 w-4" />
                      </div>
                    </div>

                    <div className="w-full md:w-[190px]">
                      <Select value={region} onValueChange={setRegion}>
                        <SelectTrigger data-testid="select-region" className="h-10">
                          <SelectValue placeholder="Region" />
                        </SelectTrigger>
                        <SelectContent>
                          {regions.map((r) => (
                            <SelectItem
                              data-testid={`option-region-${r}`}
                              key={r}
                              value={r}
                            >
                              {r === "all" ? "All regions" : r}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      data-testid="button-clear-filters"
                      variant="secondary"
                      className="h-10"
                      onClick={clearFilters}
                      disabled={activeFiltersCount === 0}
                    >
                      Clear
                    </Button>
                    <Button
                      data-testid="button-export"
                      variant="outline"
                      className="h-10"
                      onClick={() => {
                        // mock action
                      }}
                    >
                      Export
                    </Button>
                  </div>
                </div>

                <Separator />

                <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                  <TrendMultiFilter
                    label="Home value"
                    description="Median sale price (YoY)"
                    icon={Building2}
                    value={propertyTrend}
                    onChange={setPropertyTrend}
                    testIdPrefix="home-value"
                  />
                  <TrendMultiFilter
                    label="FMR"
                    description="Fair market rent (YoY)"
                    icon={DollarSign}
                    value={fmrTrend}
                    onChange={setFmrTrend}
                    testIdPrefix="fmr"
                  />
                  <TrendMultiFilter
                    label="Yield"
                    description="Cap rate (trend proxy)"
                    icon={Percent}
                    value={yieldTrend}
                    onChange={setYieldTrend}
                    testIdPrefix="yield"
                  />
                </div>

                <div className="flex flex-col gap-3 pt-1 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-2">
                    <Badge
                      data-testid="badge-sort"
                      variant="secondary"
                      className="rounded-md"
                    >
                      Sort
                    </Badge>
                    <div className="flex items-center gap-2">
                      <Button
                        data-testid="button-sort-price"
                        variant={sortKey === "price" ? "default" : "outline"}
                        className="h-9 gap-2"
                        onClick={() => toggleSort("price")}
                      >
                        <span>Price</span>
                        <SortIcon k="price" />
                      </Button>
                      <Button
                        data-testid="button-sort-fmr"
                        variant={sortKey === "fmr" ? "default" : "outline"}
                        className="h-9 gap-2"
                        onClick={() => toggleSort("fmr")}
                      >
                        <span>FMR</span>
                        <SortIcon k="fmr" />
                      </Button>
                      <Button
                        data-testid="button-sort-yield"
                        variant={sortKey === "yield" ? "default" : "outline"}
                        className="h-9 gap-2"
                        onClick={() => toggleSort("yield")}
                      >
                        <span>Yield</span>
                        <SortIcon k="yield" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Results */}
        <div className="mt-6">
          <div className="flex items-end justify-between">
            <div className="space-y-1">
              <h2 data-testid="text-results-title" className="text-sm font-medium">
                Results
              </h2>
            </div>
            <div className="hidden md:block text-xs text-muted-foreground">
              Showing <span className="text-foreground font-medium">{results.length}</span> of{" "}
              <span className="text-foreground font-medium">{MARKETS.length}</span>
            </div>
          </div>

          <div className="mt-3 overflow-hidden rounded-lg border border-card-border bg-card shadow-none">
            <div className="hidden md:grid grid-cols-[1.5fr_1fr_1fr_1fr_0.8fr] gap-3 px-4 py-3 text-xs font-medium text-muted-foreground">
              <div data-testid="header-market">Market</div>
              <div data-testid="header-price">Home value</div>
              <div data-testid="header-fmr">FMR</div>
              <div data-testid="header-yield">Yield</div>
              <div data-testid="header-risk" className="text-right">
                Risk
              </div>
            </div>
            <Separator className="hidden md:block" />

            <div className="divide-y divide-border">
              {results.length === 0 ? (
                <div className="px-4 py-12 text-center">
                  <div
                    data-testid="empty-title"
                    className="text-sm font-medium text-foreground"
                  >
                    No markets match these filters
                  </div>
                  <div
                    data-testid="empty-subtitle"
                    className="mt-1 text-xs text-muted-foreground"
                  >
                    Try broadening a signal or switching a trend to Any.
                  </div>
                  <div className="mt-4">
                    <Button
                      data-testid="button-empty-clear"
                      variant="secondary"
                      onClick={clearFilters}
                    >
                      Clear filters
                    </Button>
                  </div>
                </div>
              ) : (
                results.map((m, idx) => {
                  const p = trendFromDelta(m.priceYoY);
                  const r = trendFromDelta(m.fmrYoY);
                  const y = trendFromDelta(m.yieldYoY);

                  return (
                    <div
                      data-testid={`row-market-${m.id}`}
                      key={m.id}
                      className="group px-4 py-4 transition-colors hover:bg-muted/40"
                    >
                      <div className="grid grid-cols-1 gap-3 md:grid-cols-[1.5fr_1fr_1fr_1fr_0.8fr] md:items-center">
                        <div className="min-w-0">
                          <div className="flex items-center justify-between gap-3 md:justify-start">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span
                                  data-testid={`text-rank-${m.id}`}
                                  className="inline-flex h-6 w-6 items-center justify-center rounded-md border border-card-border bg-background text-[12px] font-semibold text-muted-foreground"
                                >
                                  {idx + 1}
                                </span>
                                <div className="min-w-0">
                                  <div
                                    data-testid={`text-market-${m.id}`}
                                    className="truncate text-sm font-semibold"
                                  >
                                    {m.name}, {m.state}
                                  </div>
                                  <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                                    <span
                                      data-testid={`text-region-${m.id}`}
                                      className="inline-flex items-center gap-1"
                                    >
                                      {m.region}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="md:hidden flex items-center gap-2">
                              <RiskPill risk={m.risk} id={m.id} />
                            </div>
                          </div>
                        </div>

                        <SignalCell
                          testIdPrefix="price"
                          id={m.id}
                          valueMain={formatUSD(m.priceMedian)}
                          delta={m.priceYoY}
                          trend={p}
                        />

                        <SignalCell
                          testIdPrefix="fmr"
                          id={m.id}
                          valueMain={`${formatUSD(m.fmr2br)}/mo`}
                          delta={m.fmrYoY}
                          trend={r}
                        />

                        <SignalCell
                          testIdPrefix="yield"
                          id={m.id}
                          valueMain={formatPct(m.capRate)}
                          delta={m.yieldYoY}
                          trend={y}
                        />

                        <div className="hidden md:flex justify-end">
                          <RiskPill risk={m.risk} id={m.id} />
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-card-border bg-card px-4 py-3 shadow-none">
            <div className="text-xs text-muted-foreground" data-testid="text-footnote">
              Showing <span className="text-foreground font-medium">{results.length}</span> matches.
            </div>
            <div className="flex items-center gap-2">
              <Badge data-testid="badge-source" variant="outline" className="rounded-md">
                Mock dataset
              </Badge>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function TrendMultiFilter({
  label,
  description,
  icon: Icon,
  value,
  onChange,
  testIdPrefix,
}: {
  label: string;
  description: string;
  icon: any;
  value: TrendMulti;
  onChange: (v: TrendMulti) => void;
  testIdPrefix: string;
}) {
  const allSelected = setEqualsAll(value);

  function setAll() {
    onChange(new Set<Trend>(["up", "flat", "down"]));
  }

  return (
    <div
      data-testid={`filter-${testIdPrefix}`}
      className="rounded-md border border-card-border bg-background p-3"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-sm border border-card-border bg-card">
              <Icon className="h-4 w-4" strokeWidth={2} />
            </span>
            <div>
              <div
                data-testid={`text-filter-label-${testIdPrefix}`}
                className="text-sm font-semibold"
              >
                {label}
              </div>
              <div
                data-testid={`text-filter-desc-${testIdPrefix}`}
                className="text-xs text-muted-foreground"
              >
                {description}
              </div>
            </div>
          </div>
        </div>

      </div>

      <div className="mt-3 flex items-center gap-2">
        <span
          data-testid={`text-${testIdPrefix}-mode`}
          className="text-xs font-medium text-muted-foreground"
        >
          Direction
        </span>

        <div
          data-testid={`segmented-${testIdPrefix}`}
          className="inline-flex overflow-hidden rounded-sm border border-card-border bg-background"
        >
          <button
            type="button"
            data-testid={`segmented-${testIdPrefix}-any`}
            onClick={setAll}
            className={
              "h-8 px-2.5 text-xs font-medium transition-colors " +
              (allSelected
                ? "bg-foreground text-background"
                : "text-foreground hover:bg-muted/50")
            }
            aria-pressed={allSelected}
          >
            Any
          </button>
          <div className="w-px bg-card-border" />
          <button
            type="button"
            data-testid={`segmented-${testIdPrefix}-up`}
            onClick={() => onChange(new Set<Trend>(["up"]))}
            className={
              "h-8 px-2.5 text-xs font-medium transition-colors " +
              (value.size === 1 && value.has("up")
                ? "bg-foreground text-background"
                : "text-foreground hover:bg-muted/50")
            }
            aria-pressed={value.size === 1 && value.has("up")}
          >
            Up
          </button>
          <div className="w-px bg-card-border" />
          <button
            type="button"
            data-testid={`segmented-${testIdPrefix}-flat`}
            onClick={() => onChange(new Set<Trend>(["flat"]))}
            className={
              "h-8 px-2.5 text-xs font-medium transition-colors " +
              (value.size === 1 && value.has("flat")
                ? "bg-foreground text-background"
                : "text-foreground hover:bg-muted/50")
            }
            aria-pressed={value.size === 1 && value.has("flat")}
          >
            Flat
          </button>
          <div className="w-px bg-card-border" />
          <button
            type="button"
            data-testid={`segmented-${testIdPrefix}-down`}
            onClick={() => onChange(new Set<Trend>(["down"]))}
            className={
              "h-8 px-2.5 text-xs font-medium transition-colors " +
              (value.size === 1 && value.has("down")
                ? "bg-foreground text-background"
                : "text-foreground hover:bg-muted/50")
            }
            aria-pressed={value.size === 1 && value.has("down")}
          >
            Down
          </button>
        </div>

        {!allSelected ? (
          <button
            type="button"
            data-testid={`button-${testIdPrefix}-clear`}
            onClick={setAll}
            className="ml-auto text-xs font-medium text-muted-foreground underline-offset-4 hover:underline"
          >
            Clear
          </button>
        ) : null}
      </div>

    </div>
  );
}

function SignalCell({
  id,
  testIdPrefix,
  valueMain,
  delta,
  trend,
}: {
  id: string;
  testIdPrefix: "price" | "fmr" | "yield";
  valueMain: string;
  delta: number;
  trend: Trend;
}) {
  const deltaColor =
    delta > 0.25
      ? "text-emerald-700 dark:text-emerald-300"
      : delta < -0.25
        ? "text-rose-700 dark:text-rose-300"
        : "text-muted-foreground";

  return (
    <div className="rounded-md border border-card-border bg-background p-3">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div
            data-testid={`text-${testIdPrefix}-value-${id}`}
            className="truncate text-sm font-semibold"
          >
            {valueMain}
          </div>
          <div className="mt-0.5 flex items-center gap-2 text-xs">
            <span
              data-testid={`text-${testIdPrefix}-delta-${id}`}
              className={`font-medium ${deltaColor}`}
            >
              {delta > 0 ? "+" : ""}
              {formatPct(delta)}
            </span>
            <span className="text-muted-foreground">
              <span className="sr-only">Year over year</span>
              YoY
            </span>
          </div>
        </div>
        <TrendPill trend={trend} />
      </div>
    </div>
  );
}

function RiskPill({ risk, id }: { risk: Market["risk"]; id: string }) {
  const cfg =
    risk === "Low"
      ? { cls: "bg-emerald-500/10 text-emerald-700 border-emerald-600/15 dark:text-emerald-300" }
      : risk === "High"
        ? { cls: "bg-rose-500/10 text-rose-700 border-rose-600/15 dark:text-rose-300" }
        : { cls: "bg-amber-500/10 text-amber-700 border-amber-600/15 dark:text-amber-300" };

  return (
    <span
      data-testid={`pill-risk-${id}`}
      className={`inline-flex items-center rounded-md border px-2.5 py-0.5 text-[12px] font-medium ${cfg.cls}`}
    >
      {risk}
    </span>
  );
}
