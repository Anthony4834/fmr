import { motion } from "framer-motion";
import { Heart, MoreHorizontal, MapPin, Bed, Bath, Square } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";

// Mockup of the fmr.fyi badge
export function ExtensionBadgeMockup({ mode }: { mode: "cashflow" | "fmr" }) {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      key={mode} // Re-animate on mode change
      className="bg-white rounded border border-zinc-200 shadow-sm inline-flex items-center gap-2 px-2 py-1 text-xs font-medium select-none"
    >
      <span className="font-bold text-zinc-500 tracking-tight">fmr.fyi</span>
      
      {/* Status Dot */}
      <span className={cn(
        "w-1.5 h-1.5 rounded-full",
        mode === "cashflow" ? "bg-emerald-500" : "bg-blue-500"
      )} />

      {/* Value */}
      <div className="flex items-baseline gap-1">
        <span className={cn(
          "font-bold text-sm",
          mode === "cashflow" ? "text-emerald-600" : "text-blue-600"
        )}>
          {mode === "cashflow" ? "+$593" : "$1,300"}
        </span>
        <span className="text-zinc-400 text-[10px]">/mo</span>
      </div>

      <div className="w-3.5 h-3.5 rounded-full border border-zinc-200 text-zinc-400 flex items-center justify-center text-[8px] font-serif ml-0.5">
        ?
      </div>
    </motion.div>
  );
}

// Mockup of a real estate listing card
export function ListingCardMockup({ mode }: { mode: "cashflow" | "fmr" }) {
  return (
    <div className="bg-white rounded-xl overflow-hidden shadow-lg border border-zinc-100 max-w-sm mx-auto select-none transform transition-all duration-500">
      {/* Image Area */}
      <div className="relative h-48 bg-zinc-100 overflow-hidden group flex items-center justify-center">
        {/* Placeholder House Image - using a gradient/pattern to look like a loaded image */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-indigo-50">
             <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px]" />
        </div>
        
        {/* SVG House Illustration */}
        <div className="relative z-10 w-32 h-32 opacity-80 text-primary/40">
          <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full drop-shadow-sm">
            <path d="M100 20L20 90H40V180H80V130H120V180H160V90H180L100 20Z" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinejoin="round"/>
            <rect x="85" y="50" width="30" height="30" rx="4" fill="white" fillOpacity="0.6"/>
            <path d="M90 65H110" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            <path d="M100 55V75" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/>
            
            {/* Windows */}
            <rect x="45" y="100" width="25" height="30" rx="2" fill="white" fillOpacity="0.6" stroke="currentColor" strokeWidth="2"/>
            <rect x="130" y="100" width="25" height="30" rx="2" fill="white" fillOpacity="0.6" stroke="currentColor" strokeWidth="2"/>
            
            {/* Tree */}
            <path d="M170 180V140" stroke="currentColor" strokeWidth="4" strokeLinecap="round"/>
            <circle cx="170" cy="130" r="20" fill="#22c55e" fillOpacity="0.2" stroke="currentColor" strokeWidth="2"/>
          </svg>
        </div>
        
        {/* Tags */}
        <div className="absolute top-2 left-2 bg-zinc-900/80 text-white text-[10px] font-bold px-1.5 py-0.5 rounded backdrop-blur-md">
          New Construction
        </div>
        <div className="absolute top-2 right-2 text-white">
          <Heart className="w-5 h-5 drop-shadow-md" />
        </div>
        
        {/* Carousel Dots */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-white shadow-sm" />
            <div className="w-1.5 h-1.5 rounded-full bg-white/50 shadow-sm" />
            <div className="w-1.5 h-1.5 rounded-full bg-white/50 shadow-sm" />
        </div>
      </div>

      {/* Content Area */}
      <div className="p-4 space-y-3 relative">
        <div className="flex justify-between items-start">
          <div>
            <div className="text-2xl font-bold text-zinc-900">$425,000</div>
            <div className="flex items-center gap-3 text-zinc-600 text-sm mt-1">
              <span className="flex items-center gap-1"><Bed className="w-3 h-3" /> 3 bds</span>
              <span className="bg-zinc-200 w-px h-3" />
              <span className="flex items-center gap-1"><Bath className="w-3 h-3" /> 2 ba</span>
              <span className="bg-zinc-200 w-px h-3" />
              <span className="flex items-center gap-1"><Square className="w-3 h-3" /> 1,850 sqft</span>
            </div>
          </div>
          <MoreHorizontal className="w-5 h-5 text-zinc-400" />
        </div>

        <div className="text-sm text-zinc-500 flex items-center gap-1 truncate">
          <MapPin className="w-3 h-3 flex-shrink-0" />
          123 Investment Lane, Austin, TX 78701
        </div>

        {/* The Extension Injection Point */}
        <div className="pt-2 border-t border-zinc-50 flex items-center justify-between">
           <div className="text-[10px] text-zinc-400 font-medium uppercase tracking-wider">Realty Corp</div>
           
           {/* This is where our badge lives in the "DOM" */}
           <div className="relative z-10 scale-110 origin-right shadow-sm rounded">
              <ExtensionBadgeMockup mode={mode} />
           </div>
        </div>

      </div>
    </div>
  );
}
