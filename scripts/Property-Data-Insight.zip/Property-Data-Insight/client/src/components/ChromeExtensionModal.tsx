import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Check, ArrowRight, Chrome, Settings, Sliders, DollarSign, Percent } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ListingCardMockup } from "@/components/ListingCardMockup";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

// Assets
import miniViewImg from "@assets/fmr-fyi-mini-view_1769502519682.png";

const STORAGE_KEY = "fmr_extension_modal_last_seen";
const DONT_SHOW_KEY = "fmr_extension_modal_hidden";

export function ChromeExtensionModal() {
  const [isOpen, setIsOpen] = useState(false);
  // Toggle between modes for the mockup
  const [activeMode, setActiveMode] = useState<"cashflow" | "fmr">("cashflow");

  useEffect(() => {
    // Logic:
    // 1. Check if user permanently dismissed
    const isHidden = localStorage.getItem(DONT_SHOW_KEY);
    if (isHidden) return;

    // 2. Check last seen (7 days cooldown)
    const lastSeen = localStorage.getItem(STORAGE_KEY);
    if (lastSeen) {
      const daysSince = (Date.now() - parseInt(lastSeen)) / (1000 * 60 * 60 * 24);
      if (daysSince < 7) return;
    }

    // 3. Mock checks for Chrome/Desktop (assuming true for prototype)
    const isDesktop = window.innerWidth >= 768;
    
    if (isDesktop) {
      const timer = setTimeout(() => {
        setIsOpen(true);
        localStorage.setItem(STORAGE_KEY, Date.now().toString());
      }, 900); // 900ms delay
      return () => clearTimeout(timer);
    }
  }, []);

  const handleClose = (permanent = false) => {
    setIsOpen(false);
    if (permanent) {
      localStorage.setItem(DONT_SHOW_KEY, "true");
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end md:items-center justify-center md:p-4"
            onClick={() => handleClose(false)}
          >
            {/* Modal Content */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              transition={{ duration: 0.3, type: "spring", bounce: 0.3 }}
              className="bg-white dark:bg-zinc-900 w-full max-w-4xl h-full md:h-[650px] md:max-h-[90vh] md:rounded-2xl shadow-2xl overflow-hidden flex flex-col md:flex-row"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Mobile Close Button (Fixed on top right for mobile) */}
              <button 
                onClick={() => handleClose(false)}
                className="absolute top-4 right-4 z-50 p-2 bg-white/80 backdrop-blur rounded-full text-zinc-500 hover:text-zinc-900 md:hidden shadow-sm"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Left Column: Content */}
              <div className="w-full md:w-2/5 flex flex-col relative bg-white dark:bg-zinc-900 z-10 border-b md:border-b-0 md:border-r border-zinc-100 order-2 md:order-1 flex-shrink-0">
                <ScrollArea className="flex-1">
                  <div className="p-6 md:p-8 pt-8 md:pt-8">
                    <div>
                      <div className="flex items-center gap-2 mb-4 md:mb-6">
                        <span className="bg-primary/10 text-primary px-2 py-1 rounded text-xs font-bold uppercase tracking-wider">
                          Free Chrome Extension
                        </span>
                      </div>

                      <h2 className="text-2xl md:text-3xl font-heading font-bold text-zinc-900 dark:text-white leading-tight mb-3 md:mb-4">
                        Real estate data, <br/>
                        <span className="text-primary">right where you look.</span>
                      </h2>

                      <p className="text-zinc-500 dark:text-zinc-400 mb-6 text-sm leading-relaxed">
                        Stop switching tabs. Get Cash Flow estimates and Fair Market Rent data overlaid directly on Zillow, Redfin, and Realtor.com.
                      </p>

                      <div className="space-y-6">
                        <div>
                          <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2 mb-3">
                            <Check className="w-4 h-4 text-primary" />
                            Key Features
                          </h3>
                          <ul className="space-y-2.5">
                            {[
                              "Instant Cash Flow calculation",
                              "Fair Market Rent (FMR) data",
                              "Works on Map & List views",
                              "One-click deep dive analysis"
                            ].map((item, i) => (
                              <li key={i} className="flex items-start gap-2.5 text-xs font-medium text-zinc-600 dark:text-zinc-400">
                                <div className="w-4 h-4 rounded-full bg-zinc-100 flex items-center justify-center flex-shrink-0 mt-0.5">
                                  <div className="w-1.5 h-1.5 rounded-full bg-zinc-400" />
                                </div>
                                {item}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                           <h3 className="text-sm font-bold text-zinc-900 flex items-center gap-2 mb-3">
                            <Settings className="w-4 h-4 text-primary" />
                            Fully Customizable
                          </h3>
                           <p className="text-xs text-zinc-500 leading-relaxed mb-2">
                             Tailor the extension to your strategy. Adjust down payments, management fees, and expense assumptions in the settings panel.
                           </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </ScrollArea>

                <div className="p-4 md:p-6 border-t border-zinc-100 bg-zinc-50/50 mt-auto">
                  <Button 
                    size="lg" 
                    className="w-full bg-primary hover:bg-primary/90 text-white font-semibold h-11 rounded-lg shadow-md shadow-primary/10 mb-3"
                  >
                    <Chrome className="w-4 h-4 mr-2" />
                    Add to Chrome
                  </Button>
                  
                  <button 
                    onClick={() => handleClose(true)}
                    className="w-full text-xs text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300 transition-colors"
                  >
                    Don't show this again
                  </button>
                </div>
              </div>

              {/* Right Column: Visuals */}
              <div className="w-full md:w-3/5 bg-zinc-50 dark:bg-zinc-800/50 relative flex flex-col order-1 md:order-2">
                <ScrollArea className="flex-1 h-[300px] md:h-auto">
                  <div className="p-8 md:p-12 pb-12 md:pb-24 min-h-full flex flex-col items-center justify-center md:justify-start">
                    
                    {/* Background decorative elements */}
                    <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />
                    <div className="absolute top-[40%] left-0 w-64 h-64 bg-green-500/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2 pointer-events-none" />
                    
                    {/* Grid Pattern */}
                    <div className="absolute inset-0 opacity-[0.03] bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

                    {/* Close Button Desktop */}
                    <button 
                      onClick={() => handleClose(false)}
                      className="hidden md:flex absolute top-6 right-6 p-2 rounded-full bg-white/50 hover:bg-white backdrop-blur-sm text-zinc-500 hover:text-zinc-800 transition-all z-20"
                    >
                      <X className="w-5 h-5" />
                    </button>

                    {/* Live Mockup Section */}
                    <div className="relative w-full max-w-[320px] md:max-w-[380px] perspective-1000 z-10 mb-8 md:mb-12 mt-8 md:mt-0">
                      
                      <div className="mb-6 flex justify-center gap-3">
                        <button 
                          onClick={() => setActiveMode("cashflow")}
                          className={cn(
                            "flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-full text-xs md:text-sm font-semibold transition-all shadow-sm border",
                            activeMode === "cashflow"
                              ? "bg-white border-emerald-200 text-emerald-700 ring-2 ring-emerald-500/20"
                              : "bg-white/50 border-transparent text-zinc-500 hover:bg-white hover:text-zinc-700"
                          )}
                        >
                          <DollarSign className="w-3 h-3 md:w-4 md:h-4" />
                          Cash Flow Mode
                        </button>
                         <button 
                          onClick={() => setActiveMode("fmr")}
                          className={cn(
                            "flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 rounded-full text-xs md:text-sm font-semibold transition-all shadow-sm border",
                            activeMode === "fmr"
                              ? "bg-white border-blue-200 text-blue-700 ring-2 ring-blue-500/20"
                              : "bg-white/50 border-transparent text-zinc-500 hover:bg-white hover:text-zinc-700"
                          )}
                        >
                          <Percent className="w-3 h-3 md:w-4 md:h-4" />
                          FMR Mode
                        </button>
                      </div>

                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2, duration: 0.6 }}
                        className="relative"
                      >
                         <ListingCardMockup mode={activeMode} />
                         
                         {/* Annotation Line (Desktop only) */}
                         <div className="absolute -right-4 bottom-8 translate-x-full hidden md:flex items-center gap-2">
                            <div className="w-12 h-px bg-zinc-400" />
                            <span className="text-xs font-medium text-zinc-500 whitespace-nowrap bg-white/80 backdrop-blur px-2 py-1 rounded shadow-sm border border-zinc-100">
                              Updates live on page
                            </span>
                         </div>
                      </motion.div>
                    </div>

                    {/* Detailed Analysis Section (Hidden on small mobile) */}
                    <div className="w-full max-w-[420px] z-10 animate-in fade-in slide-in-from-bottom-8 duration-700 delay-300 hidden sm:block">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="h-px bg-zinc-200 flex-1" />
                        <span className="text-xs font-bold uppercase tracking-widest text-zinc-400">Detailed Analysis</span>
                        <div className="h-px bg-zinc-200 flex-1" />
                      </div>
                      
                      <div className="bg-white rounded-xl shadow-xl border border-zinc-200/50 overflow-hidden ring-1 ring-black/5 hover:ring-primary/20 transition-all duration-500 group">
                        <div className="relative">
                           <img 
                              src={miniViewImg} 
                              alt="Detailed FMR Analysis" 
                              className="w-full h-auto object-cover opacity-90 transition-opacity group-hover:opacity-100"
                           />
                           <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center p-6">
                              <p className="text-white font-medium text-sm drop-shadow-md">Click any badge to open detailed view</p>
                           </div>
                        </div>
                        <div className="p-4 bg-zinc-50/50 border-t border-zinc-100">
                          <h4 className="font-bold text-zinc-900 text-sm mb-1">Deep Dive Data</h4>
                          <p className="text-xs text-zinc-500">View complete breakdown by bedroom count, investment scores, and historical trends.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </ScrollArea>
              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

