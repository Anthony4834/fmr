import { ChromeExtensionModal } from "@/components/ChromeExtensionModal";
import { Button } from "@/components/ui/button";
import { ArrowRight, BarChart2, Map, ShieldCheck } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background font-sans selection:bg-primary/20">
      <ChromeExtensionModal />
      
      {/* Debug Controls */}
      <div className="fixed bottom-4 left-4 z-50">
        <Button 
          variant="outline" 
          size="sm" 
          className="bg-white/80 backdrop-blur text-xs"
          onClick={() => {
            localStorage.removeItem("fmr_extension_modal_hidden");
            localStorage.removeItem("fmr_extension_modal_last_seen");
            window.location.reload();
          }}
        >
          Reset Modal Demo
        </Button>
      </div>

      {/* Navigation */}
      <nav className="border-b border-border/40 backdrop-blur-sm sticky top-0 z-40 bg-background/80">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 font-heading font-bold text-xl text-primary">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white">
              <BarChart2 className="w-5 h-5" />
            </div>
            fmr.fyi
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">Market Data</a>
            <a href="#" className="hover:text-foreground transition-colors">Calculators</a>
            <a href="#" className="hover:text-foreground transition-colors">Pricing</a>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="hidden sm:flex">Log in</Button>
            <Button>Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-24 pb-20 md:pt-32 md:pb-32 container mx-auto px-4 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-secondary text-secondary-foreground text-xs font-medium mb-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse"/>
          Live Market Data Updated Daily
        </div>
        
        <h1 className="text-5xl md:text-7xl font-heading font-bold tracking-tight text-foreground mb-6 max-w-4xl mx-auto leading-[1.1] animate-in fade-in slide-in-from-bottom-6 duration-700 delay-100">
          Real Estate Investing, <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-emerald-600">Simplified.</span>
        </h1>
        
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed animate-in fade-in slide-in-from-bottom-6 duration-700 delay-200">
          Access comprehensive Fair Market Rent data, analyze cash flow potential, and make confident investment decisions in seconds.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-in fade-in slide-in-from-bottom-6 duration-700 delay-300">
          <Button size="lg" className="h-12 px-8 text-base shadow-lg shadow-primary/20">
            Start Analyzing Free
            <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
          <Button size="lg" variant="outline" className="h-12 px-8 text-base bg-background/50 backdrop-blur-sm">
            View Sample Report
          </Button>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-secondary/30 border-y border-border/50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: Map,
                title: "Nationwide Coverage",
                desc: "Data for every zip code in the US, updated with the latest HUD releases."
              },
              {
                icon: BarChart2,
                title: "Instant Cash Flow",
                desc: "Calculate potential returns instantly with our smart mortgage & expense estimator."
              },
              {
                icon: ShieldCheck,
                title: "Reliable Data",
                desc: "Sources directly from federal databases and verified market listings."
              }
            ].map((feature, i) => (
              <div key={i} className="bg-background p-8 rounded-2xl border border-border/50 shadow-sm hover:shadow-md transition-all hover:-translate-y-1">
                <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary mb-6">
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-heading font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 container mx-auto px-4 text-center text-muted-foreground text-sm">
        <p>&copy; 2026 fmr.fyi. All rights reserved.</p>
      </footer>
    </div>
  );
}
